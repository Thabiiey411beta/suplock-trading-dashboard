import asyncio
import json
import logging
from typing import Dict, Any, Optional

try:
    import websockets
except ImportError:
    logging.warning("websockets library not found. Run pip install websockets")

logger = logging.getLogger(__name__)

class LiveMarketState:
    """
    Thread-safe state container for asynchronous loops.
    Pre-formats data for Financial Chain-of-Thought (F-CoT) reasoning.
    """
    def __init__(self):
        self.lock = asyncio.Lock()
        self.state: Dict[str, Dict[str, Any]] = {}

    async def update_ticker(self, symbol: str, price: float, volume: float, timestamp: int, source: str) -> None:
        async with self.lock:
            if symbol not in self.state:
                self.state[symbol] = {
                    "symbol": symbol,
                    "latest_price": price,
                    "24h_volume": volume,
                    "last_updated": timestamp,
                    "source": source,
                    "price_history": []
                }
            else:
                self.state[symbol]["latest_price"] = price
                self.state[symbol]["24h_volume"] = volume
                self.state[symbol]["last_updated"] = timestamp
                self.state[symbol]["source"] = source
                
                # Keep a brief rolling history for F-CoT context (e.g., recent volatility)
                self.state[symbol]["price_history"].append(price)
                if len(self.state[symbol]["price_history"]) > 50:
                    self.state[symbol]["price_history"].pop(0)

    async def get_fcot_context(self, symbol: str) -> Optional[Dict[str, Any]]:
        """
        Retrieves pre-formatted state optimally structured for our LangGraph multi-agent triad.
        """
        async with self.lock:
            data = self.state.get(symbol)
            if not data:
                return None
            
            history = data["price_history"]
            recent_trend = "FLAT"
            if len(history) > 1:
                recent_trend = "UP" if history[-1] > history[0] else "DOWN"

            return {
                "asset": symbol,
                "current_price": data["latest_price"],
                "recent_trend": recent_trend,
                "volatility_context": "Provides immediate raw pricing context for Grok/Gemini/GPT-4o reasoning.",
                "raw_history": history[-10:], # Last 10 ticks for rapid micro-structure analysis
                "timestamp": data["last_updated"]
            }

async def alpaca_stream_worker(state: LiveMarketState, api_key: str, api_secret: str) -> None:
    """
    Asynchronous background worker for Alpaca real-time stock streams.
    """
    uri = "wss://stream.data.alpaca.markets/v2/iex"
    backoff = 1.0

    while True:
        try:
            async with websockets.connect(uri) as ws:
                logger.info("Connected to Alpaca WebSocket")
                
                # Auth payload
                auth_payload = {
                    "action": "auth",
                    "key": api_key,
                    "secret": api_secret
                }
                await ws.send(json.dumps(auth_payload))
                
                # Subscribe payload
                sub_payload = {
                    "action": "subscribe",
                    "trades": ["AAPL", "TSLA", "SPY"],
                }
                await ws.send(json.dumps(sub_payload))

                backoff = 1.0 # Reset backoff on successful connection

                async for message in ws:
                    data = json.loads(message)
                    for event in data:
                        if event.get("T") == "t":
                            symbol = event.get("S")
                            price = event.get("p")
                            size = event.get("s")
                            timestamp = event.get("t", 0)
                            
                            if symbol and price is not None:
                                await state.update_ticker(symbol, float(price), float(size or 0), timestamp, "Alpaca")

        except Exception as e:
            logger.error(f"Alpaca WebSocket error: {e}. Reconnecting in {backoff} seconds...")
            await asyncio.sleep(backoff)
            backoff = min(backoff * 2, 60.0)

async def finnhub_crypto_worker(state: LiveMarketState, api_key: str) -> None:
    """
    Asynchronous background worker for Finnhub real-time crypto streams.
    """
    uri = f"wss://ws.finnhub.io?token={api_key}"
    backoff = 1.0

    while True:
        try:
            async with websockets.connect(uri) as ws:
                logger.info("Connected to Finnhub Crypto WebSocket")
                
                # Subscribe payloads
                subscribe_msgs = [
                    {"type": "subscribe", "symbol": "BINANCE:BTCUSDT"},
                    {"type": "subscribe", "symbol": "BINANCE:ETHUSDT"}
                ]
                for msg in subscribe_msgs:
                    await ws.send(json.dumps(msg))

                backoff = 1.0

                async for message in ws:
                    data = json.loads(message)
                    if data.get("type") == "trade":
                        for trade in data.get("data", []):
                            symbol = trade.get("s")
                            price = trade.get("p")
                            volume = trade.get("v")
                            timestamp = trade.get("t", 0)
                            
                            if symbol and price is not None:
                                await state.update_ticker(symbol, float(price), float(volume or 0), timestamp, "Finnhub")

        except Exception as e:
            logger.error(f"Finnhub WebSocket error: {e}. Reconnecting in {backoff} seconds...")
            await asyncio.sleep(backoff)
            backoff = min(backoff * 2, 60.0)
