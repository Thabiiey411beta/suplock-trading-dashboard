import os
import sqlite3
import logging
from typing import Optional
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)
router = APIRouter(tags=["Execution"])

try:
    from alpaca.trading.client import TradingClient
    from alpaca.trading.requests import LimitOrderRequest, TakeProfitRequest, StopLossRequest
    from alpaca.trading.enums import OrderSide, TimeInForce, OrderClass
    ALPACA_IMPORTED = True
except ImportError:
    logger.warning("alpaca-py library not found. Running in mock mode. Run `pip install alpaca-py` to enable live paper trading.")
    ALPACA_IMPORTED = False

DB_PATH = "trade_ledger.db"

def _init_db():
    with sqlite3.connect(DB_PATH) as conn:
        cursor = conn.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS ledger (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                order_id TEXT,
                symbol TEXT,
                side TEXT,
                quantity REAL,
                ai_signature TEXT,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        """)
        conn.commit()

_init_db()

class ManualBindRequest(BaseModel):
    symbol: str = Field(..., description="The asset ticker (e.g., AAPL)")
    side: str = Field(..., description="BUY or SELL")
    quantity: float = Field(..., description="Quantity of shares/coins")
    entry_price: float = Field(..., description="Target limit entry price")
    take_profit: float = Field(..., description="Take profit reference price")
    stop_loss: float = Field(..., description="Stop loss reference price")
    ai_signature: str = Field(..., description="Cryptographic signature from LangGraph")

@router.post("/api/v1/execute/manual_bind")
async def execute_manual_bind(payload: ManualBindRequest):
    """
    Consumes a manual verification payload from the frontend, 
    enforces the 1.5% max portfolio risk limit, 
    and binds the trade to Alpaca Paper Trading.
    """
    api_key = os.getenv("ALPACA_API_KEY", "MOCK_KEY")
    api_secret = os.getenv("ALPACA_SECRET_KEY", "MOCK_SECRET")

    # Mock variables for fallback
    equity = 100000.0
    order_id = "mock_alpaca_order_id_123"
    
    absolute_risk = abs(payload.entry_price - payload.stop_loss) * payload.quantity
    
    if ALPACA_IMPORTED and api_key != "MOCK_KEY":
        # 1. Initialize Client
        try:
            trading_client = TradingClient(api_key, api_secret, paper=True)
        except Exception as e:
            logger.error(f"Alpaca client init error: {e}")
            raise HTTPException(status_code=500, detail="Internal brokerage connection error.")

        # 2. Strict Risk Validation (1.5% Rule)
        try:
            account = trading_client.get_account()
            equity = float(account.equity)
        except Exception as e:
            logger.error(f"Could not fetch Alpaca account: {e}")
            raise HTTPException(status_code=500, detail="Failed to retrieve portfolio equity for risk validation.")
            
        max_risk_allowed = equity * 0.015

        if absolute_risk > max_risk_allowed:
            error_msg = (
                f"RISK BREACH: Proposed absolute risk (${absolute_risk:.2f}) "
                f"exceeds the 1.5% max portfolio limit (${max_risk_allowed:.2f})."
            )
            logger.warning(error_msg)
            raise HTTPException(status_code=400, detail=error_msg)

        # 3. Construct Limit Order Request with Bracket
        side_enum = OrderSide.BUY if payload.side.upper() == "BUY" else OrderSide.SELL

        try:
            order_request = LimitOrderRequest(
                symbol=payload.symbol,
                qty=payload.quantity,
                side=side_enum,
                time_in_force=TimeInForce.GTC,
                limit_price=payload.entry_price,
                order_class=OrderClass.BRACKET,
                take_profit=TakeProfitRequest(limit_price=payload.take_profit),
                stop_loss=StopLossRequest(stop_price=payload.stop_loss)
            )

            # 4. Submit Order
            order = trading_client.submit_order(order_data=order_request)
            order_id = str(order.id)
                
        except Exception as e:
            logger.error(f"Alpaca order execution failed: {e}")
            raise HTTPException(status_code=500, detail=f"Order execution failed at brokerage layer: {str(e)}")
    else:
        # MOCK MODE
        logger.info("Executing in MOCK mode due to missing Alpaca credentials or library.")
        max_risk_allowed = equity * 0.015
        if absolute_risk > max_risk_allowed:
            error_msg = (
                f"RISK BREACH: Proposed absolute risk (${absolute_risk:.2f}) "
                f"exceeds the 1.5% max portfolio limit (${max_risk_allowed:.2f})."
            )
            logger.warning(error_msg)
            raise HTTPException(status_code=400, detail=error_msg)

    # 5. Freeze Context (Ledger Write)
    try:
        with sqlite3.connect(DB_PATH) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO ledger (order_id, symbol, side, quantity, ai_signature)
                VALUES (?, ?, ?, ?, ?)
            """, (order_id, payload.symbol, payload.side.upper(), payload.quantity, payload.ai_signature))
            conn.commit()
    except Exception as e:
        logger.error(f"Failed to record state to SQLite ledger: {e}")

    return {
        "status": "SUCCESS",
        "message": "Manual trade executed. Context frozen.",
        "order_id": order_id,
        "absolute_risk_usd": absolute_risk,
        "portfolio_equity_usd": equity
    }
