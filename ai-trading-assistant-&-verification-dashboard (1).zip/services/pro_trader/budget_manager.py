import sqlite3
import datetime
import threading
from typing import Optional

class BudgetOrchestrator:
    """
    Enforces a strict global daily operational budget limit of $25.00 USD 
    across all AI API providers (Grok, Gemini, GPT-4o).
    """
    def __init__(self, db_path: str = "budget.db"):
        self.daily_limit_usd: float = 25.00
        self.db_path: str = db_path
        self._lock = threading.Lock()
        self._init_db()

    def _init_db(self) -> None:
        with self._lock:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS daily_usage (
                        date TEXT PRIMARY KEY,
                        usd_spent REAL
                    )
                """)
                conn.commit()

    def _get_today_date_str(self) -> str:
        return datetime.date.today().isoformat()

    def _get_current_usage(self) -> float:
        today = self._get_today_date_str()
        with self._lock:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute("SELECT usd_spent FROM daily_usage WHERE date = ?", (today,))
                row = cursor.fetchone()
                if row:
                    return float(row[0])
                else:
                    return 0.0

    def increment_usage(self, usd_cost: float) -> None:
        """
        Increments the daily API usage tally.
        Call this after computing the token cost of a generation.
        """
        today = self._get_today_date_str()
        with self._lock:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    INSERT INTO daily_usage (date, usd_spent) 
                    VALUES (?, ?) 
                    ON CONFLICT(date) DO UPDATE SET usd_spent = usd_spent + ?
                """, (today, usd_cost, usd_cost))
                conn.commit()

    def is_budget_exhausted(self) -> bool:
        """
        Circuit-breaker method. Returns True if the daily budget is met or exceeded.
        """
        current_usage = self._get_current_usage()
        return current_usage >= self.daily_limit_usd

    def get_remaining_budget(self) -> float:
        """
        Returns the remaining daily budget in USD.
        """
        return max(0.0, self.daily_limit_usd - self._get_current_usage())
