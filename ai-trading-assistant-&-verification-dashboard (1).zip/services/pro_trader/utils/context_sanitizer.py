import asyncio
import json
import logging
from typing import Dict, Any

try:
    import aiohttp
except ImportError:
    logging.warning("aiohttp library not found. Run pip install aiohttp")

# Ensure we can import BudgetOrchestrator if this is run as a module
try:
    from services.pro_trader.budget_manager import BudgetOrchestrator
except ImportError:
    # Fallback for relative imports or testing
    import sys
    import os
    sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..', '..'))
    from services.pro_trader.budget_manager import BudgetOrchestrator

logger = logging.getLogger(__name__)

async def _fallback_local_clipper(raw_news_json: Dict[str, Any]) -> Dict[str, Any]:
    """
    Local token-clipping script to compress data without external AI.
    Used as an emergency fallback if the free Puter API fails or times out.
    """
    logger.warning("Using local token-clipping fallback for macro context.")
    # Extract text from raw_news_json and simply clip it
    raw_text = json.dumps(raw_news_json)
    
    # Simple clip to ~500 chars to save tokens for downstream LangGraph agents
    clipped_text = raw_text[:500] + "..." if len(raw_text) > 500 else raw_text
    
    return {
        "asset": raw_news_json.get("symbol", "UNKNOWN"),
        "current_price": raw_news_json.get("price", 0.0),
        "recent_trend": "UNKNOWN",
        "volatility_context": clipped_text,
        "raw_history": [],
        "timestamp": raw_news_json.get("timestamp", 0)
    }

async def sanitize_macro_context(raw_news_json: Dict[str, Any], budget_manager: BudgetOrchestrator) -> Dict[str, Any]:
    """
    Instructs Puter's free AI to strip out fluff, normalize conflicting timestamps, 
    and format the market text into a tightly compressed, structured JSON payload 
    (F-CoT template).
    
    If Puter API fails or times out, falls back to local token clipping.
    """
    # Defensive check: if overall budget is exhausted, we might want to skip even free calls 
    # if they imply downstream execution, but strictly this call is free.
    # We log it via the budget manager for visibility.
    if budget_manager.is_budget_exhausted():
        logger.warning("Global budget exhausted. Proceeding with caution in pre-processing.")
        
    prompt = f"""
    You are a financial data pre-processor.
    Take the following raw macro sentiment data, strip out fluff, normalize timestamps, 
    and output a strictly formatted JSON payload adhering to the Financial Chain-of-Thought (F-CoT) template.
    Template keys required: 'asset', 'current_price', 'recent_trend', 'volatility_context', 'raw_history', 'timestamp'.
    
    Raw Data:
    {json.dumps(raw_news_json)}
    """

    try:
        # Utilizing Puter's free AI endpoint (Standard OpenAI-compatible REST API structure)
        # Puter offers free/unlimited tiers per docs.puter.com/llms.txt
        headers = {
            "Content-Type": "application/json",
            "Authorization": "Bearer free-puter-token"
        }
        
        payload = {
            "model": "claude-3-haiku-20240307", # Example lightweight/free model mapped in Puter
            "messages": [
                {"role": "system", "content": "You output only valid JSON matching the F-CoT template."},
                {"role": "user", "content": prompt}
            ],
            "response_format": {"type": "json_object"}
        }

        async with aiohttp.ClientSession() as session:
            # 5-second aggressive timeout to prevent pipeline blocking
            async with session.post(
                "https://api.puter.com/v1/chat/completions", 
                headers=headers, 
                json=payload, 
                timeout=5.0
            ) as response:
                if response.status == 200:
                    data = await response.json()
                    content = data["choices"][0]["message"]["content"]
                    
                    # Since this is a free endpoint, the USD cost is 0, but we log visibility
                    budget_manager.increment_usage(0.0) 
                    
                    return json.loads(content)
                else:
                    logger.error(f"Puter API returned status {response.status}. Triggering fallback.")
                    return await _fallback_local_clipper(raw_news_json)
                    
    except asyncio.TimeoutError:
        logger.error("Puter API request timed out. Triggering fallback.")
        return await _fallback_local_clipper(raw_news_json)
    except Exception as e:
        logger.error(f"Puter API request failed: {str(e)}. Triggering fallback.")
        return await _fallback_local_clipper(raw_news_json)
