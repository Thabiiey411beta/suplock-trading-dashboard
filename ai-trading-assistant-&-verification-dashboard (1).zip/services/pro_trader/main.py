from fastapi import FastAPI, WebSocket, WebSocketDisconnect
import asyncio
import json
from typing import List

app = FastAPI(title="ProTrader Telemetry Backend", version="1.0.0")

class ConnectionManager:
    def __init__(self):
        self.active_connections: List[WebSocket] = []

    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        self.active_connections.append(websocket)

    def disconnect(self, websocket: WebSocket):
        if websocket in self.active_connections:
            self.active_connections.remove(websocket)

    async def broadcast(self, message: dict):
        for connection in self.active_connections:
            try:
                await connection.send_json(message)
            except Exception:
                pass

manager = ConnectionManager()

@app.websocket("/ws/telemetry")
async def websocket_endpoint(websocket: WebSocket):
    await manager.connect(websocket)
    try:
        while True:
            # We don't expect inbound messages from the dashboard in this architecture
            # except perhaps ping/pong, but we wait to hold the connection open.
            data = await websocket.receive_text()
    except WebSocketDisconnect:
        manager.disconnect(websocket)
    except Exception as e:
        manager.disconnect(websocket)

# Mock function to simulate LangGraph state machine completion over time
async def simulate_langgraph_pipeline():
    while True:
        await asyncio.sleep(15) # Broadcast a new signal every 15 seconds
        
        # Mock final Contract C payload (ProTraderSignedExecutionOrder)
        payload = {
            "signalId": f"sig_btc_usd_{int(asyncio.get_event_loop().time())}",
            "action": "LONG",
            "entryZone": 65000.0,
            "takeProfit": 68000.0,
            "stopLoss": 63000.0,
            "maxSlippage": 0.005,
            "positionSizing": {
                "portfolioSizeUsd": 100000.0,
                "allocatedRiskPercent": 1.5,
                "computedMarginUsd": 48750.0
            },
            "justification": "Automated risk gate reconciled LONG setup with exact 1.5% portfolio parameters based on high catalyst scores.",
            "riskManagerVerificationSignature": "abc123def456hashsignature890123456789abcdef",
            "agent_telemetry": {
                "grok_bull": {
                    "bullish_catalyst_strength": 85,
                    "catalyst_factors": ["On-chain activity spike", "Strong social sentiment accumulation phase"],
                    "bullish_target": 68000.0,
                    "bullish_justification": "Breakout above standard accumulation boundaries."
                },
                "gemini_bear": {
                    "bearish_risk_level": 40,
                    "risk_factors": ["Macro funding rates spike", "Slight volume divergence"],
                    "bearish_boundary": 63000.0,
                    "bearish_justification": "Minor risk factors present but overall structure remains bullish."
                }
            }
        }
        await manager.broadcast(payload)

@app.on_event("startup")
async def startup_event():
    # Start the simulation loop when the FastAPI server boots up
    asyncio.create_task(simulate_langgraph_pipeline())

if __name__ == "__main__":
    import uvicorn
    # In production, this would be executed via uvicorn services.pro_trader.main:app
    uvicorn.run(app, host="0.0.0.0", port=8000)
