import { useState, useEffect, useRef } from 'react';

export interface AgentTelemetry {
  grok_bull: {
    bullish_catalyst_strength: number;
    catalyst_factors: string[];
    bullish_target: number;
    bullish_justification: string;
  };
  gemini_bear: {
    bearish_risk_level: number;
    risk_factors: string[];
    bearish_boundary: number;
    bearish_justification: string;
  };
}

export interface ProTraderSignedExecutionOrder {
  signalId: string;
  action: 'LONG' | 'SHORT';
  entryZone: number;
  takeProfit: number;
  stopLoss: number;
  maxSlippage: number;
  positionSizing: {
    portfolioSizeUsd: number;
    allocatedRiskPercent: number;
    computedMarginUsd: number;
  };
  justification: string;
  riskManagerVerificationSignature: string;
  agent_telemetry: AgentTelemetry;
  status: 'STAGED / AWAITING VERIFICATION' | 'APPROVED';
}

export function useTelemetryStream(url: string) {
  const [signals, setSignals] = useState<ProTraderSignedExecutionOrder[]>([]);
  const [isConnected, setIsConnected] = useState(false);
  const wsRef = useRef<WebSocket | null>(null);
  const reconnectTimeoutRef = useRef<NodeJS.Timeout>();
  const backoffRef = useRef(1000);

  useEffect(() => {
    const connect = () => {
      try {
        const ws = new WebSocket(url);
        wsRef.current = ws;

        ws.onopen = () => {
          setIsConnected(true);
          backoffRef.current = 1000; // Reset backoff
          console.log('[TelemetryStream] Connected');
        };

        ws.onmessage = (event) => {
          try {
            const data = JSON.parse(event.data);
            const order: ProTraderSignedExecutionOrder = {
              ...data,
              status: 'STAGED / AWAITING VERIFICATION', // Initial state
            };
            setSignals((prev) => [order, ...prev].slice(0, 50)); // Keep last 50
          } catch (e) {
            console.error('[TelemetryStream] Parse error', e);
          }
        };

        ws.onclose = () => {
          setIsConnected(false);
          console.log(`[TelemetryStream] Disconnected. Reconnecting in ${backoffRef.current}ms...`);
          reconnectTimeoutRef.current = setTimeout(() => {
            backoffRef.current = Math.min(backoffRef.current * 1.5, 30000);
            connect();
          }, backoffRef.current);
        };

        ws.onerror = (error) => {
          console.error('[TelemetryStream] WebSocket error', error);
          ws.close();
        };
      } catch (error) {
        console.error('[TelemetryStream] Connection error', error);
      }
    };

    connect();

    return () => {
      if (reconnectTimeoutRef.current) clearTimeout(reconnectTimeoutRef.current);
      if (wsRef.current) {
        wsRef.current.onclose = null;
        wsRef.current.close();
      }
    };
  }, [url]);

  return { signals, isConnected, setSignals };
}
