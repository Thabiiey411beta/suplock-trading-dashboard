import { useState, useEffect } from 'react';

export interface HistoricalDataPoint {
  time: string;
  price: number;
}

export function useHistoricalData(symbol: string, currentPrice: number, timeframe: string = '24h') {
  const [data, setData] = useState<HistoricalDataPoint[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let isMounted = true;
    setIsLoading(true);
    setError(null);

    // Simulate backend proxy API fetch to Twelve Data or Alpha Vantage
    setTimeout(() => {
      if (!isMounted) return;
      try {
        const mockData = [];
        const basePrice = currentPrice;
        // Start lower or higher based on asset
        let simPrice = basePrice * 0.95; 
        const now = Date.now();
        
        let msOffset = 24 * 60 * 60 * 1000;
        let points = 24;
        
        if (timeframe === '1h') {
          msOffset = 60 * 60 * 1000;
          points = 60;
        } else if (timeframe === '7d') {
          msOffset = 7 * 24 * 60 * 60 * 1000;
          points = 28;
        }

        const startTime = now - msOffset;

        for (let i = 0; i <= points; i++) {
          const time = startTime + (i * (msOffset / points));
          // Add some random walk volatility
          const change = (Math.random() - 0.45) * (basePrice * 0.02);
          simPrice += change;
          
          // Force the last point to be near the entry zone
          if (i === points) simPrice = basePrice;

          mockData.push({
            time: new Date(time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            price: simPrice
          });
        }
        setData(mockData);
      } catch (err) {
        setError('Failed to fetch historical data');
      } finally {
        setIsLoading(false);
      }
    }, 1200);

    return () => {
      isMounted = false;
    };
  }, [symbol, currentPrice, timeframe]);

  return { data, isLoading, error };
}
