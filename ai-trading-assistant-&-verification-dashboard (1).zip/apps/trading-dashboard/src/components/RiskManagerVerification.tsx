import React from 'react';
import { ProTraderSignedExecutionOrder } from '../hooks/useTelemetryStream';
import { ShieldCheck, Lock } from 'lucide-react';

interface RiskManagerProps {
  order: ProTraderSignedExecutionOrder;
}

export const RiskManagerVerification: React.FC<RiskManagerProps> = ({ order }) => {
  return (
    <div className="bg-gray-900 border border-blue-900/50 rounded-lg p-5 shadow-lg mb-4">
      <div className="flex items-center space-x-2 mb-4 border-b border-gray-800 pb-3">
        <ShieldCheck className="w-5 h-5 text-blue-400" />
        <h3 className="text-lg font-bold text-blue-400 font-mono">GPT-4o RISK MANAGER</h3>
      </div>
      
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
        <div>
          <span className="block text-xs text-gray-500 uppercase">Action</span>
          <span className={`text-lg font-bold font-mono ${order.action === 'LONG' ? 'text-emerald-400' : 'text-rose-400'}`}>
            {order.action}
          </span>
        </div>
        <div>
          <span className="block text-xs text-gray-500 uppercase">Entry Zone</span>
          <span className="text-lg font-bold font-mono text-gray-200">${order.entryZone.toLocaleString()}</span>
        </div>
        <div>
          <span className="block text-xs text-gray-500 uppercase">Take Profit</span>
          <span className="text-lg font-bold font-mono text-emerald-400">${order.takeProfit.toLocaleString()}</span>
        </div>
        <div>
          <span className="block text-xs text-gray-500 uppercase">Stop Loss</span>
          <span className="text-lg font-bold font-mono text-rose-400">${order.stopLoss.toLocaleString()}</span>
        </div>
      </div>

      <div className="bg-gray-800 rounded p-3 mb-4">
        <h4 className="text-xs text-gray-400 uppercase mb-2">Portfolio Sizing (Max 1.5% Drawdown)</h4>
        <div className="grid grid-cols-3 gap-4">
          <div>
            <span className="block text-xs text-gray-500">Portfolio</span>
            <span className="text-sm font-mono text-gray-300">${order.positionSizing.portfolioSizeUsd.toLocaleString()}</span>
          </div>
          <div>
            <span className="block text-xs text-gray-500">Allocated Risk</span>
            <span className="text-sm font-mono text-blue-400">{order.positionSizing.allocatedRiskPercent}%</span>
          </div>
          <div>
            <span className="block text-xs text-gray-500">Computed Margin</span>
            <span className="text-sm font-mono text-yellow-400">${order.positionSizing.computedMarginUsd.toLocaleString()}</span>
          </div>
        </div>
      </div>

      <div className="flex items-start space-x-2 bg-black/50 p-3 rounded border border-gray-800">
        <Lock className="w-4 h-4 text-gray-500 mt-1 flex-shrink-0" />
        <div className="overflow-hidden">
          <span className="block text-xs text-gray-500 uppercase mb-1">Cryptographic Signature Payload</span>
          <code className="text-xs text-gray-400 break-all font-mono">
            {order.riskManagerVerificationSignature}
          </code>
        </div>
      </div>
    </div>
  );
};
