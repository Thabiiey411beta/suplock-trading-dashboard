import React, { useState } from 'react';
import { Wallet, Activity, Hexagon } from 'lucide-react';

export const CockpitHeader: React.FC = () => {
  const [walletConnected, setWalletConnected] = useState(false);
  
  return (
    <div className="flex items-center justify-between p-4 bg-gray-900 border-b border-gray-800 text-white">
      <div className="flex items-center space-x-4">
        <h1 className="text-xl font-bold tracking-wider text-emerald-400">AURA-24 COCKPIT</h1>
        <div className="flex items-center space-x-2 px-3 py-1 bg-gray-800 rounded-full border border-gray-700">
          <Hexagon className="w-4 h-4 text-purple-400" />
          <span className="text-sm font-medium text-gray-300">Genesis NFT Tier: </span>
          <span className="text-sm font-bold text-purple-400 animate-pulse">Evolving (Tier 1)</span>
        </div>
      </div>
      
      <div className="flex items-center space-x-6">
        <div className="flex items-center space-x-2">
          <Activity className="w-5 h-5 text-blue-400" />
          <div className="flex flex-col">
            <span className="text-xs text-gray-400 uppercase tracking-wider">Evolution Points</span>
            <span className="text-sm font-bold font-mono text-blue-400">14,285 EP</span>
          </div>
        </div>
        
        <button 
          onClick={() => setWalletConnected(!walletConnected)}
          className={`flex items-center space-x-2 px-4 py-2 rounded-md font-medium transition-colors ${
            walletConnected 
              ? 'bg-emerald-900/50 text-emerald-400 border border-emerald-800' 
              : 'bg-blue-600 text-white hover:bg-blue-700'
          }`}
        >
          <Wallet className="w-4 h-4" />
          <span>{walletConnected ? 'Starkey Connected' : 'Connect Starkey'}</span>
        </button>
      </div>
    </div>
  );
};
