import React, { useState } from 'react';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, ReferenceLine } from 'recharts';
import { ProTraderSignedExecutionOrder } from '../hooks/useTelemetryStream';
import { useHistoricalData } from '../hooks/useHistoricalData';
import { Activity, TrendingUp, TrendingDown } from 'lucide-react';

interface SignalPriceChartProps {
  order: ProTraderSignedExecutionOrder;
}

export const SignalPriceChart: React.FC<SignalPriceChartProps> = ({ order }) => {
  const [timeframe, setTimeframe] = useState('24h');
  
  // order.signalId normally implies symbol (e.g., sig_btc_usd_123), mock extracting it
  const symbol = order.signalId.split('_').slice(1, 3).join('').toUpperCase() || 'ASSET';
  
  const { data: chartData, isLoading, error } = useHistoricalData(symbol, order.entryZone, timeframe);

  if (isLoading) {
    return (
      <div className="bg-gray-900 border border-gray-800 rounded-lg p-5 shadow-lg mb-4 h-[420px] flex flex-col items-center justify-center space-y-4">
        <div className="w-8 h-8 border-4 border-indigo-500 border-t-transparent rounded-full animate-spin"></div>
        <p className="text-gray-500 font-mono text-sm animate-pulse">AGGREGATING LIVE MACRO-TREND DATA...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-gray-900 border border-rose-900/50 rounded-lg p-5 shadow-lg mb-4 h-[420px] flex flex-col items-center justify-center">
        <p className="text-rose-400 font-mono text-sm">Error: {error}</p>
        <p className="text-gray-500 text-xs mt-2">Check network connection to data proxy.</p>
      </div>
    );
  }

  const minPrice = Math.min(...chartData.map(d => d.price));
  const maxPrice = Math.max(...chartData.map(d => d.price));
  const isBullish = order.action === 'LONG';
  
  const yDomain = [
    minPrice - (maxPrice - minPrice) * 0.1, 
    maxPrice + (maxPrice - minPrice) * 0.1
  ];

  const strokeColor = isBullish ? "#10b981" : "#f43f5e"; // emerald-500 : rose-500

  return (
    <div className="bg-gray-900 border border-gray-800 rounded-lg p-5 shadow-lg mb-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-6 border-b border-gray-800 pb-3 gap-4">
        <div className="flex items-center space-x-2">
          <Activity className="w-5 h-5 text-indigo-400" />
          <h3 className="text-lg font-bold text-indigo-400 font-mono">MACRO-TREND CHECKPOINTS</h3>
        </div>
        <div className="flex items-center space-x-4">
          <div className="flex items-center bg-black rounded-lg border border-gray-800 p-1">
            <button className={`px-2 py-1 text-xs font-mono font-bold rounded transition-colors ${timeframe === '1h' ? 'bg-gray-800 text-white' : 'text-gray-500 hover:text-gray-300'}`} onClick={() => setTimeframe('1h')}>1H</button>
            <button className={`px-2 py-1 text-xs font-mono font-bold rounded transition-colors ${timeframe === '24h' ? 'bg-gray-800 text-white' : 'text-gray-500 hover:text-gray-300'}`} onClick={() => setTimeframe('24h')}>24H</button>
            <button className={`px-2 py-1 text-xs font-mono font-bold rounded transition-colors ${timeframe === '7d' ? 'bg-gray-800 text-white' : 'text-gray-500 hover:text-gray-300'}`} onClick={() => setTimeframe('7d')}>7D</button>
          </div>
        </div>
      </div>
      
      <div className="grid grid-cols-3 gap-4 mb-6">
        <div className="bg-black/40 border border-gray-800 p-3 rounded-lg">
          <span className="block text-xs text-gray-500 uppercase font-mono">24H High</span>
          <span className="text-sm font-bold text-gray-200 font-mono">${maxPrice.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
        </div>
        <div className="bg-black/40 border border-gray-800 p-3 rounded-lg">
          <span className="block text-xs text-gray-500 uppercase font-mono">24H Low</span>
          <span className="text-sm font-bold text-gray-200 font-mono">${minPrice.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
        </div>
        <div className="bg-black/40 border border-gray-800 p-3 rounded-lg relative overflow-hidden">
          <span className="block text-xs text-gray-500 uppercase font-mono relative z-10">Risk Threshold (1.5%)</span>
          <div className="flex items-center space-x-1 relative z-10 mt-1">
            {isBullish ? <TrendingUp className="w-3 h-3 text-emerald-400" /> : <TrendingDown className="w-3 h-3 text-rose-400" />}
            <span className={`text-sm font-bold font-mono ${isBullish ? 'text-emerald-400' : 'text-rose-400'}`}>
              ${order.stopLoss.toLocaleString()}
            </span>
          </div>
          <div className="absolute inset-0 bg-gradient-to-r from-transparent to-red-900/20" />
        </div>
      </div>

      <div className="h-64 w-full">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={chartData} margin={{ top: 5, right: 0, left: 0, bottom: 0 }}>
            <defs>
              <linearGradient id="colorPrice" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor={strokeColor} stopOpacity={0.3}/>
                <stop offset="95%" stopColor={strokeColor} stopOpacity={0}/>
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="#1f2937" vertical={false} />
            <XAxis 
              dataKey="time" 
              stroke="#4b5563" 
              fontSize={11} 
              tickMargin={10}
              tickLine={false}
              axisLine={false}
            />
            <YAxis 
              domain={yDomain} 
              stroke="#4b5563" 
              fontSize={11} 
              tickFormatter={(val) => `$${val.toLocaleString()}`}
              orientation="right"
              tickLine={false}
              axisLine={false}
              width={80}
            />
            <Tooltip 
              contentStyle={{ backgroundColor: '#000000', borderColor: '#1f2937', color: '#f3f4f6', fontFamily: 'monospace' }}
              itemStyle={{ color: strokeColor }}
              labelStyle={{ color: '#9ca3af', marginBottom: '4px' }}
              formatter={(value: number) => [`$${value.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`, symbol]}
            />
            <ReferenceLine y={order.stopLoss} stroke="#f43f5e" strokeDasharray="3 3" label={{ position: 'insideBottomLeft', value: 'STOP LOSS', fill: '#f43f5e', fontSize: 10, fontFamily: 'monospace' }} />
            <ReferenceLine y={order.takeProfit} stroke="#10b981" strokeDasharray="3 3" label={{ position: 'insideTopLeft', value: 'TAKE PROFIT', fill: '#10b981', fontSize: 10, fontFamily: 'monospace' }} />
            
            <Area 
              type="monotone" 
              dataKey="price" 
              stroke={strokeColor} 
              strokeWidth={2}
              fillOpacity={1} 
              fill="url(#colorPrice)" 
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};
