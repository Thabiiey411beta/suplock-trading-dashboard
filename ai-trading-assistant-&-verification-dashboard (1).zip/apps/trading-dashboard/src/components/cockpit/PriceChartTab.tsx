import React, { useState } from 'react';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, ReferenceLine } from 'recharts';
import { useHistoricalData } from '../../hooks/useHistoricalData';
import { Activity, TrendingUp, TrendingDown, AlertTriangle } from 'lucide-react';

export interface SelectedSignal {
  symbol: string;
  currentPrice: number;
  timestamp: string;
  sentiment?: 'BULLISH' | 'BEARISH' | 'NEUTRAL';
}

interface PriceChartTabProps {
  selectedSignal: SelectedSignal;
}

export const PriceChartTab: React.FC<PriceChartTabProps> = ({ selectedSignal }) => {
  const [timeframe, setTimeframe] = useState<'1h' | '24h' | '7d'>('24h');
  
  const { data: chartData, isLoading, error } = useHistoricalData(
    selectedSignal.symbol, 
    selectedSignal.currentPrice, 
    timeframe
  );

  // Fallback for missing sentiment
  const isBullish = selectedSignal.sentiment !== 'BEARISH'; 
  const strokeColor = isBullish ? "#10b981" : "#f43f5e"; // emerald-500 : rose-500
  
  // Calculate thresholds based on the 1.5% risk rule
  const riskThreshold = isBullish 
    ? selectedSignal.currentPrice * 0.985 
    : selectedSignal.currentPrice * 1.015;

  if (isLoading) {
    return (
      <div className="bg-gray-950 border border-gray-800 rounded-xl p-6 shadow-xl h-[500px] flex flex-col items-center justify-center space-y-4">
        <div className="w-10 h-10 border-4 border-indigo-500 border-t-transparent rounded-full animate-spin"></div>
        <p className="text-gray-500 font-mono text-sm animate-pulse tracking-wider">AGGREGATING LIVE MACRO-TREND DATA...</p>
      </div>
    );
  }

  if (error || !chartData || chartData.length === 0) {
    return (
      <div className="bg-gray-950 border border-rose-900/50 rounded-xl p-6 shadow-xl h-[500px] flex flex-col items-center justify-center space-y-3">
        <AlertTriangle className="w-10 h-10 text-rose-500" />
        <p className="text-rose-400 font-mono font-bold text-lg">Stream Interrupted</p>
        <p className="text-gray-500 text-sm font-mono">{error || "Failed to fetch historical data."}</p>
        <button onClick={() => setTimeframe(timeframe)} className="px-4 py-2 mt-2 border border-rose-800 text-rose-400 hover:bg-rose-900/30 rounded font-mono text-xs transition-colors">
          RETRY CONNECTION
        </button>
      </div>
    );
  }

  const minPrice = Math.min(...chartData.map(d => d.price));
  const maxPrice = Math.max(...chartData.map(d => d.price));
  
  // Create a little buffer around the min/max for the Y-Axis
  const yDomain = [
    Math.min(minPrice, isBullish ? riskThreshold : minPrice) * 0.995, 
    Math.max(maxPrice, !isBullish ? riskThreshold : maxPrice) * 1.005
  ];

  const proximityToRisk = Math.abs(selectedSignal.currentPrice - riskThreshold) / selectedSignal.currentPrice * 100;

  return (
    <div className="bg-gray-950 border border-gray-800 rounded-xl p-6 shadow-2xl flex flex-col">
      {/* Header and Controls */}
      <div className="flex flex-col md:flex-row md:items-center justify-between mb-6 border-b border-gray-800/80 pb-4 gap-4">
        <div className="flex items-center space-x-3">
          <div className={`p-2 rounded-lg ${isBullish ? 'bg-emerald-900/30 text-emerald-400' : 'bg-rose-900/30 text-rose-400'}`}>
            <Activity className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-white font-mono tracking-wide">{selectedSignal.symbol} MACRO-TREND</h3>
            <p className="text-xs text-gray-500 font-mono tracking-wider">
              {new Date(selectedSignal.timestamp).toLocaleString()}
            </p>
          </div>
        </div>
        
        <div className="flex items-center bg-black rounded-lg border border-gray-800 p-1">
          {(['1h', '24h', '7d'] as const).map(tf => (
            <button 
              key={tf}
              className={`px-3 py-1.5 text-xs font-mono font-bold rounded-md transition-all ${
                timeframe === tf 
                  ? 'bg-gray-800 text-white shadow-sm' 
                  : 'text-gray-500 hover:text-gray-300 hover:bg-gray-900/50'
              }`} 
              onClick={() => setTimeframe(tf)}
            >
              {tf.toUpperCase()}
            </button>
          ))}
        </div>
      </div>
      
      {/* Key Checkpoints Row */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div className="bg-black/50 border border-gray-800/60 p-4 rounded-xl flex flex-col justify-between hover:border-gray-700 transition-colors">
          <span className="block text-xs text-gray-500 uppercase font-mono tracking-widest mb-1">{timeframe} High</span>
          <span className="text-lg font-bold text-gray-200 font-mono">
            ${maxPrice.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </span>
        </div>
        
        <div className="bg-black/50 border border-gray-800/60 p-4 rounded-xl flex flex-col justify-between hover:border-gray-700 transition-colors">
          <span className="block text-xs text-gray-500 uppercase font-mono tracking-widest mb-1">{timeframe} Low</span>
          <span className="text-lg font-bold text-gray-200 font-mono">
            ${minPrice.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </span>
        </div>
        
        <div className="bg-black/50 border border-gray-800/60 p-4 rounded-xl relative overflow-hidden flex flex-col justify-between hover:border-gray-700 transition-colors">
          <div className="relative z-10 flex justify-between items-start">
            <span className="block text-xs text-gray-500 uppercase font-mono tracking-widest mb-1">1.5% Risk Threshold</span>
            <span className={`text-[10px] font-mono px-2 py-0.5 rounded-full ${proximityToRisk < 0.5 ? 'bg-rose-900/50 text-rose-400' : 'bg-emerald-900/50 text-emerald-400'}`}>
              {proximityToRisk.toFixed(2)}% Away
            </span>
          </div>
          <div className="flex items-center space-x-2 relative z-10">
            {isBullish ? <TrendingDown className="w-4 h-4 text-rose-500" /> : <TrendingUp className="w-4 h-4 text-emerald-500" />}
            <span className={`text-lg font-bold font-mono ${isBullish ? 'text-rose-400' : 'text-emerald-400'}`}>
              ${riskThreshold.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </span>
          </div>
          <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-transparent to-red-900/10 pointer-events-none" />
        </div>
      </div>

      {/* Recharts Area */}
      <div className="h-[300px] w-full bg-black/20 rounded-xl p-4 border border-gray-800/50">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={chartData} margin={{ top: 10, right: 0, left: 0, bottom: 0 }}>
            <defs>
              <linearGradient id="colorPriceGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor={strokeColor} stopOpacity={0.35}/>
                <stop offset="95%" stopColor={strokeColor} stopOpacity={0}/>
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="#1f2937" vertical={false} opacity={0.5} />
            <XAxis 
              dataKey="time" 
              stroke="#4b5563" 
              fontSize={11} 
              tickMargin={12}
              tickLine={false}
              axisLine={false}
              fontFamily="monospace"
              minTickGap={30}
            />
            <YAxis 
              domain={yDomain} 
              stroke="#4b5563" 
              fontSize={11} 
              tickFormatter={(val) => `$${val.toLocaleString(undefined, { minimumFractionDigits: 0 })}`}
              orientation="right"
              tickLine={false}
              axisLine={false}
              width={70}
              fontFamily="monospace"
            />
            <Tooltip 
              contentStyle={{ 
                backgroundColor: '#09090b', // zinc-950
                borderColor: '#27272a', // zinc-800
                color: '#f4f4f5', 
                fontFamily: 'monospace',
                borderRadius: '8px',
                boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.5)'
              }}
              itemStyle={{ color: strokeColor, fontWeight: 'bold' }}
              labelStyle={{ color: '#a1a1aa', marginBottom: '6px', fontSize: '12px' }}
              formatter={(value: number) => [`$${value.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`, 'Price']}
            />
            
            <ReferenceLine 
              y={riskThreshold} 
              stroke={isBullish ? "#f43f5e" : "#10b981"} 
              strokeDasharray="4 4" 
              label={{ 
                position: 'insideBottomLeft', 
                value: 'RISK LIMIT (1.5%)', 
                fill: isBullish ? '#f43f5e' : '#10b981', 
                fontSize: 10, 
                fontFamily: 'monospace',
                opacity: 0.8
              }} 
            />
            
            <Area 
              type="monotone" 
              dataKey="price" 
              stroke={strokeColor} 
              strokeWidth={2}
              fillOpacity={1} 
              fill="url(#colorPriceGradient)" 
              activeDot={{ r: 5, strokeWidth: 0, fill: strokeColor }}
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};
