import React, { useState } from 'react';
import { ProTraderSignedExecutionOrder } from '../hooks/useTelemetryStream';
import { DebateDeck } from './DebateDeck';
import { RiskManagerVerification } from './RiskManagerVerification';
import { SignalPriceChart } from './SignalPriceChart';
import { Fingerprint, CheckCircle2, Clock, Activity, Cpu } from 'lucide-react';

interface ExecutionPanelProps {
  order: ProTraderSignedExecutionOrder;
  onApprove: (id: string) => void;
}

export const ExecutionPanel: React.FC<ExecutionPanelProps> = ({ order, onApprove }) => {
  const [isProcessing, setIsProcessing] = useState(false);
  const [activeTab, setActiveTab] = useState<'analysis' | 'chart'>('analysis');

  const handleVerify = async () => {
    setIsProcessing(true);
    // Simulate REST post to services/dgclaw-skill
    try {
      await new Promise(resolve => setTimeout(resolve, 1500));
      // In a real app we'd fetch('/api/services/dgclaw-skill', { method: 'POST', body: JSON.stringify(order) })
      onApprove(order.signalId);
    } catch (e) {
      console.error('Failed to bind manual execution', e);
    } finally {
      setIsProcessing(false);
    }
  };

  const isStaged = order.status === 'STAGED / AWAITING VERIFICATION';

  return (
    <div className={`mb-8 p-6 rounded-xl border ${isStaged ? 'border-yellow-900/50 bg-gray-950' : 'border-emerald-900/50 bg-gray-900'}`}>
      <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-6 border-b border-gray-800 pb-4 gap-4">
        <div className="flex items-center space-x-3">
          <h2 className="text-xl font-bold text-white font-mono">{order.signalId}</h2>
          <div className={`flex items-center space-x-1 px-3 py-1 rounded-full text-xs font-bold font-mono ${
            isStaged ? 'bg-yellow-900/30 text-yellow-500 border border-yellow-800' : 'bg-emerald-900/30 text-emerald-400 border border-emerald-800'
          }`}>
            {isStaged ? <Clock className="w-3 h-3" /> : <CheckCircle2 className="w-3 h-3" />}
            <span>{order.status}</span>
          </div>
        </div>
        
        <div className="flex items-center bg-gray-900 rounded-lg border border-gray-800 p-1">
          <button
            onClick={() => setActiveTab('analysis')}
            className={`flex items-center space-x-2 px-3 py-1.5 rounded-md text-xs font-bold transition-colors ${
              activeTab === 'analysis' ? 'bg-gray-800 text-white' : 'text-gray-500 hover:text-gray-300'
            }`}
          >
            <Cpu className="w-3.5 h-3.5" />
            <span>AI DEBATE DECK</span>
          </button>
          <button
            onClick={() => setActiveTab('chart')}
            className={`flex items-center space-x-2 px-3 py-1.5 rounded-md text-xs font-bold transition-colors ${
              activeTab === 'chart' ? 'bg-gray-800 text-white' : 'text-gray-500 hover:text-gray-300'
            }`}
          >
            <Activity className="w-3.5 h-3.5" />
            <span>MACRO CHART</span>
          </button>
        </div>
      </div>

      {activeTab === 'analysis' ? (
        <DebateDeck telemetry={order.agent_telemetry} />
      ) : (
        <SignalPriceChart order={order} />
      )}
      
      <RiskManagerVerification order={order} />

      {isStaged && (
        <button
          onClick={handleVerify}
          disabled={isProcessing}
          className="w-full relative overflow-hidden group bg-gradient-to-r from-yellow-600 to-yellow-500 hover:from-yellow-500 hover:to-yellow-400 text-black font-black text-lg py-4 rounded-lg transition-all disabled:opacity-50"
        >
          <div className="flex items-center justify-center space-x-2">
            <Fingerprint className={`w-6 h-6 ${isProcessing ? 'animate-pulse' : ''}`} />
            <span>{isProcessing ? 'BINDING SIGNATURE...' : '[ VERIFY & MANUAL BIND ]'}</span>
          </div>
        </button>
      )}
    </div>
  );
};
