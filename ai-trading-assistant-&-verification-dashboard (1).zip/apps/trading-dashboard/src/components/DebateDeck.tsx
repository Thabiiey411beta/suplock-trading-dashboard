import React from 'react';
import { AgentTelemetry } from '../hooks/useTelemetryStream';
import { TrendingUp, TrendingDown, Target, AlertTriangle } from 'lucide-react';

interface DebateDeckProps {
  telemetry: AgentTelemetry;
}

export const DebateDeck: React.FC<DebateDeckProps> = ({ telemetry }) => {
  const bull = telemetry.grok_bull;
  const bear = telemetry.gemini_bear;

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 my-4">
      {/* Grok 4.5 Bull Card */}
      <div className="bg-gray-900 border border-emerald-900/50 rounded-lg p-5 shadow-lg">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-2">
            <TrendingUp className="w-5 h-5 text-emerald-400" />
            <h3 className="text-lg font-bold text-emerald-400 font-mono">GROK 4.5 (BULL)</h3>
          </div>
          <div className="px-2 py-1 bg-emerald-900/30 rounded text-emerald-400 text-xs font-mono border border-emerald-800">
            STR: {bull.bullish_catalyst_strength}/100
          </div>
        </div>
        
        <div className="space-y-4">
          <div>
            <h4 className="text-xs text-gray-500 uppercase tracking-wider mb-1">Catalyst Factors</h4>
            <ul className="list-disc list-inside text-sm text-gray-300 space-y-1">
              {bull.catalyst_factors.map((f, i) => <li key={i}>{f}</li>)}
            </ul>
          </div>
          
          <div>
            <h4 className="text-xs text-gray-500 uppercase tracking-wider mb-1">Target Boundary</h4>
            <div className="flex items-center space-x-2 text-emerald-400">
              <Target className="w-4 h-4" />
              <span className="font-mono font-bold">${bull.bullish_target.toLocaleString()}</span>
            </div>
          </div>

          <div>
            <h4 className="text-xs text-gray-500 uppercase tracking-wider mb-1">Justification</h4>
            <p className="text-sm text-gray-400 italic">"{bull.bullish_justification}"</p>
          </div>
        </div>
      </div>

      {/* Gemini 2.5 Pro Bear Card */}
      <div className="bg-gray-900 border border-rose-900/50 rounded-lg p-5 shadow-lg">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-2">
            <TrendingDown className="w-5 h-5 text-rose-400" />
            <h3 className="text-lg font-bold text-rose-400 font-mono">GEMINI 2.5 PRO (BEAR)</h3>
          </div>
          <div className="px-2 py-1 bg-rose-900/30 rounded text-rose-400 text-xs font-mono border border-rose-800">
            RSK: {bear.bearish_risk_level}/100
          </div>
        </div>
        
        <div className="space-y-4">
          <div>
            <h4 className="text-xs text-gray-500 uppercase tracking-wider mb-1">Risk Factors</h4>
            <ul className="list-disc list-inside text-sm text-gray-300 space-y-1">
              {bear.risk_factors.map((f, i) => <li key={i}>{f}</li>)}
            </ul>
          </div>
          
          <div>
            <h4 className="text-xs text-gray-500 uppercase tracking-wider mb-1">Price Floor Model</h4>
            <div className="flex items-center space-x-2 text-rose-400">
              <AlertTriangle className="w-4 h-4" />
              <span className="font-mono font-bold">${bear.bearish_boundary.toLocaleString()}</span>
            </div>
          </div>

          <div>
            <h4 className="text-xs text-gray-500 uppercase tracking-wider mb-1">Justification</h4>
            <p className="text-sm text-gray-400 italic">"{bear.bearish_justification}"</p>
          </div>
        </div>
      </div>
    </div>
  );
};
