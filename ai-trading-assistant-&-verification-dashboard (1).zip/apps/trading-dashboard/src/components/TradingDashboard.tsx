import React, { useEffect } from 'react';
import { useTelemetryStream } from '../hooks/useTelemetryStream';
import { CockpitHeader } from './CockpitHeader';
import { ExecutionPanel } from './ExecutionPanel';

export const TradingDashboard: React.FC = () => {
  const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
  const { signals, isConnected, setSignals } = useTelemetryStream(`${protocol}//${window.location.host}/api/ws`);

  // Simulate incoming data if backend isn't running (for UI preview purposes)
  useEffect(() => {
    if (!isConnected) {
      const timer = setTimeout(() => {
        setSignals(prev => {
          if (prev.length > 0) return prev;
          return [{
            signalId: "sig_btc_usd_" + Date.now(),
            action: 'LONG',
            entryZone: 65420.50,
            takeProfit: 68000.00,
            stopLoss: 63000.00,
            maxSlippage: 0.005,
            positionSizing: {
              portfolioSizeUsd: 100000.0,
              allocatedRiskPercent: 1.5,
              computedMarginUsd: 48750.0
            },
            justification: "Automated risk gate reconciled LONG setup with exact 1.5% portfolio parameters based on high catalyst scores.",
            riskManagerVerificationSignature: "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
            agent_telemetry: {
              grok_bull: {
                bullish_catalyst_strength: 88,
                catalyst_factors: ["Record ETF inflows", "Social sentiment ATH"],
                bullish_target: 68500.0,
                bullish_justification: "Massive institutional buying overpowering short-term resistance."
              },
              gemini_bear: {
                bearish_risk_level: 42,
                risk_factors: ["Overleveraged longs on Binance", "Funding rate creeping up"],
                bearish_boundary: 62800.0,
                bearish_justification: "Minor pullback risk due to leverage, but macro trend supports the upside."
              }
            },
            status: 'STAGED / AWAITING VERIFICATION'
          }];
        });
      }, 2000);
      return () => clearTimeout(timer);
    }
  }, [isConnected, setSignals]);

  const handleApprove = (id: string) => {
    setSignals(prev => prev.map(sig => sig.signalId === id ? { ...sig, status: 'APPROVED' } : sig));
  };

  return (
    <div className="min-h-screen bg-black text-gray-200 font-sans">
      <CockpitHeader />
      
      <main className="max-w-6xl mx-auto p-6">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h2 className="text-2xl font-bold text-white mb-1">Live Telemetry Stream</h2>
            <p className="text-sm text-gray-400">Monitoring LangGraph state machine final outputs</p>
          </div>
          <div className="flex items-center space-x-2">
            <div className={`w-3 h-3 rounded-full ${isConnected ? 'bg-emerald-500 animate-pulse' : 'bg-rose-500'}`} />
            <span className="text-sm font-mono text-gray-400">{isConnected ? 'WS CONNECTED' : 'WS DISCONNECTED (MOCK MODE)'}</span>
          </div>
        </div>

        <div className="space-y-6">
          {signals.length === 0 ? (
            <div className="text-center py-20 text-gray-500 border border-gray-800 rounded-xl border-dashed">
              Waiting for LangGraph signals...
            </div>
          ) : (
            signals.map(order => (
              <ExecutionPanel key={order.signalId} order={order} onApprove={handleApprove} />
            ))
          )}
        </div>
      </main>
    </div>
  );
};
