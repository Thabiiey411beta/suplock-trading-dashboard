import React, { useRef, useEffect, useState } from "react";
import * as d3 from "d3";

interface D3MiniChartProps {
  confidence: number;
  asset: string;
}

interface DataPoint {
  day: number;
  label: string;
  signalProb: number;
  benchmarkProb: number;
}

export default function D3MiniChart({ confidence, asset }: D3MiniChartProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [dimensions, setDimensions] = useState({ width: 320, height: 120 });

  // Generate a realistic historical 7-day trend of probability for this specific signal
  const data: DataPoint[] = [
    { day: 1, label: "6d ago", signalProb: Math.max(45, confidence - 15), benchmarkProb: 50 },
    { day: 2, label: "5d ago", signalProb: Math.max(48, confidence - 10), benchmarkProb: 51 },
    { day: 3, label: "4d ago", signalProb: Math.max(52, confidence - 8), benchmarkProb: 49 },
    { day: 4, label: "3d ago", signalProb: Math.max(50, confidence - 5), benchmarkProb: 52 },
    { day: 5, label: "2d ago", signalProb: Math.max(55, confidence - 2), benchmarkProb: 50 },
    { day: 6, label: "1d ago", signalProb: Math.max(58, confidence - 1), benchmarkProb: 48 },
    { day: 7, label: "Current", signalProb: confidence, benchmarkProb: 50 }
  ];

  useEffect(() => {
    if (!containerRef.current) return;

    const resizeObserver = new ResizeObserver((entries) => {
      if (!entries || entries.length === 0) return;
      const { width, height } = entries[0].contentRect;
      setDimensions({
        width: Math.max(100, width),
        height: Math.max(80, height || 120)
      });
    });

    resizeObserver.observe(containerRef.current);
    return () => resizeObserver.disconnect();
  }, []);

  // Compute D3 paths
  const margin = { top: 12, right: 16, bottom: 20, left: 24 };
  const innerWidth = dimensions.width - margin.left - margin.right;
  const innerHeight = dimensions.height - margin.top - margin.bottom;

  // Scales
  const xScale = d3.scaleLinear()
    .domain([1, 7])
    .range([0, innerWidth]);

  const yScale = d3.scaleLinear()
    .domain([0, 100])
    .range([innerHeight, 0]);

  // Generators
  const signalLineGenerator = d3.line<DataPoint>()
    .x(d => xScale(d.day))
    .y(d => yScale(d.signalProb))
    .curve(d3.curveMonotoneX);

  const benchmarkLineGenerator = d3.line<DataPoint>()
    .x(d => xScale(d.day))
    .y(d => yScale(d.benchmarkProb))
    .curve(d3.curveMonotoneX);

  const signalAreaGenerator = d3.area<DataPoint>()
    .x(d => xScale(d.day))
    .y0(innerHeight)
    .y1(d => yScale(d.signalProb))
    .curve(d3.curveMonotoneX);

  const signalPath = signalLineGenerator(data) || "";
  const benchmarkPath = benchmarkLineGenerator(data) || "";
  const signalAreaPath = signalAreaGenerator(data) || "";

  // Gridlines
  const yTicks = [25, 50, 75];

  return (
    <div className="bg-zinc-950 border border-zinc-850 rounded-lg p-3.5 flex flex-col gap-2.5">
      <div className="flex items-center justify-between">
        <div>
          <span className="text-[10px] font-mono text-zinc-500 uppercase font-bold tracking-wider">D3.js Quantitative Audit</span>
          <h4 className="text-[11px] font-bold text-zinc-300 font-sans mt-0.5">
            Probability Benchmarking (7-Day Trend)
          </h4>
        </div>
        <div className="flex gap-3 text-[9px] font-mono font-bold uppercase">
          <span className="flex items-center gap-1 text-emerald-400">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
            Signal ({confidence}%)
          </span>
          <span className="flex items-center gap-1 text-zinc-500">
            <span className="w-1.5 h-1.5 rounded-full bg-zinc-600"></span>
            Benchmark (50%)
          </span>
        </div>
      </div>

      <div ref={containerRef} className="w-full h-28 relative">
        <svg width={dimensions.width} height={dimensions.height} className="overflow-visible">
          {/* Gradient definitions */}
          <defs>
            <linearGradient id="d3AreaGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#10b981" stopOpacity="0.25" />
              <stop offset="100%" stopColor="#10b981" stopOpacity="0.0" />
            </linearGradient>
            <filter id="d3Glow" x="-20%" y="-20%" width="140%" height="140%">
              <feGaussianBlur stdDeviation="3" result="blur" />
              <feComposite in="SourceGraphic" in2="blur" operator="over" />
            </filter>
          </defs>

          <g transform={`translate(${margin.left}, ${margin.top})`}>
            {/* Gridlines */}
            {yTicks.map(t => (
              <g key={t} transform={`translate(0, ${yScale(t)})`}>
                <line 
                  x1={0} 
                  x2={innerWidth} 
                  stroke="#27272a" 
                  strokeWidth={1} 
                  strokeDasharray="2 2" 
                />
                <text 
                  x={-6} 
                  y={3} 
                  fill="#52525b" 
                  fontSize={8} 
                  fontFamily="monospace" 
                  textAnchor="end"
                >
                  {t}%
                </text>
              </g>
            ))}

            {/* Horizontal timeline labels */}
            {data.map((d, index) => {
              if (index % 2 !== 0 && index !== data.length - 1) return null; // skip alternate for spacing
              return (
                <text
                  key={d.day}
                  x={xScale(d.day)}
                  y={innerHeight + 14}
                  fill="#71717a"
                  fontSize={8}
                  fontFamily="monospace"
                  textAnchor="middle"
                >
                  {d.label}
                </text>
              );
            })}

            {/* Area Fill */}
            <path 
              d={signalAreaPath} 
              fill="url(#d3AreaGrad)" 
            />

            {/* Benchmark Path */}
            <path 
              d={benchmarkPath} 
              fill="none" 
              stroke="#52525b" 
              strokeWidth={1.5} 
              strokeDasharray="3 3" 
            />

            {/* Signal Path */}
            <path 
              d={signalPath} 
              fill="none" 
              stroke="#10b981" 
              strokeWidth={2} 
              filter="url(#d3Glow)"
            />

            {/* Endpoint nodes */}
            <circle 
              cx={xScale(7)} 
              cy={yScale(confidence)} 
              r={3.5} 
              fill="#10b981" 
              stroke="#09090b" 
              strokeWidth={1.5} 
            />
          </g>
        </svg>
      </div>
    </div>
  );
}
