import React from "react";
import { MacroContextPayload, MacroEvent, SectorFlow } from "../types";
import { Clock, HelpCircle, Flame, TrendingUp, TrendingDown, RefreshCw } from "lucide-react";

interface MacroWeatherReportProps {
  data: MacroContextPayload;
}

export default function MacroWeatherReport({ data }: MacroWeatherReportProps) {
  const { globalSentimentIndex, liveFundingRate, events, sectors } = data;

  // Format seconds to HH:MM:SS
  const formatCountdown = (secs: number) => {
    if (secs <= 0) return "PROCESSED";
    const h = Math.floor(secs / 3600);
    const m = Math.floor((secs % 3600) / 60);
    const s = secs % 60;
    return `${h.toString().padStart(2, "0")}:${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}`;
  };

  // Determine sentiment descriptor
  const getSentimentLabel = (index: number) => {
    if (index >= 75) return { text: "EXTREME GREED", color: "text-emerald-400", bg: "bg-emerald-950/40" };
    if (index >= 55) return { text: "BULLISH BIAS", color: "text-teal-400", bg: "bg-teal-950/30" };
    if (index >= 45) return { text: "NEUTRAL MEAN", color: "text-zinc-400", bg: "bg-zinc-900" };
    if (index >= 25) return { text: "FEAR CONTEXT", color: "text-amber-400", bg: "bg-amber-950/30" };
    return { text: "PANIC DEVIATION", color: "text-rose-400", bg: "bg-rose-950/40" };
  };

  const sentimentLabel = getSentimentLabel(globalSentimentIndex);

  // SVG Gauge calculations
  const radius = 45;
  const circumference = 2 * Math.PI * radius;
  // Half gauge arc (180 degrees)
  const strokeDashoffset = circumference - (globalSentimentIndex / 100) * (circumference / 2);

  return (
    <div id="macro-weather-panel" className="bg-zinc-900 border border-zinc-850 p-5 rounded-xl flex flex-col gap-6 h-full shadow-lg">
      
      {/* Panel Header */}
      <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <h2 className="text-xs font-mono font-bold uppercase text-zinc-400 tracking-wider">
            I. MACRO CONTEXT
          </h2>
        </div>
        <span className="text-[10px] font-mono font-bold text-zinc-500 bg-zinc-850 px-2 py-0.5 rounded">
          LIVE STREAM
        </span>
      </div>

      {/* 1. Global Sentiment Index (Visual Gauge) */}
      <div className="flex flex-col gap-3">
        <div className="flex items-center justify-between">
          <span className="text-xs font-mono font-bold text-zinc-400 flex items-center gap-1.5">
            Global Sentiment
            <HelpCircle className="w-3.5 h-3.5 text-zinc-600 hover:text-zinc-400 cursor-help" />
          </span>
          <span className={`text-[10px] font-mono font-bold px-2.5 py-0.5 rounded ${sentimentLabel.bg} ${sentimentLabel.color}`}>
            {sentimentLabel.text}
          </span>
        </div>

        <div className="relative flex flex-col items-center pt-2">
          {/* Half arc gauge SVG */}
          <svg className="w-36 h-20 transform -rotate-180" viewBox="0 0 100 55">
            {/* Background semi-circle */}
            <path
              d="M 5 50 A 45 45 0 0 1 95 50"
              fill="none"
              stroke="#27272a"
              strokeWidth="8"
              strokeLinecap="round"
            />
            {/* Value indicator semi-circle */}
            <path
              d="M 5 50 A 45 45 0 0 1 95 50"
              fill="none"
              stroke="url(#sentiment-gradient)"
              strokeWidth="8"
              strokeLinecap="round"
              strokeDasharray={circumference / 2}
              strokeDashoffset={strokeDashoffset}
              className="transition-all duration-1000 ease-out"
            />
            {/* Gradient definition */}
            <defs>
              <linearGradient id="sentiment-gradient" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="#ef4444" />
                <stop offset="50%" stopColor="#f59e0b" />
                <stop offset="100%" stopColor="#10b981" />
              </linearGradient>
            </defs>
          </svg>

          {/* Centered Value text */}
          <div className="absolute bottom-1 flex flex-col items-center">
            <span className="text-2xl font-bold font-mono tracking-tight text-zinc-100">
              {globalSentimentIndex}
            </span>
            <span className="text-[10px] font-mono font-bold text-zinc-500">
              INDEX SCALE
            </span>
          </div>
        </div>

        {/* Live Funding Rate display */}
        <div className="bg-zinc-950/50 border border-zinc-800/60 p-3 rounded-lg flex justify-between items-center mt-1">
          <span className="text-[11px] font-mono font-bold text-zinc-500">
            Avg Funding Rate
          </span>
          <span className={`text-xs font-bold font-mono ${liveFundingRate >= 0 ? "text-emerald-400" : "text-rose-400"}`}>
            {liveFundingRate >= 0 ? "+" : ""}{(liveFundingRate * 100).toFixed(4)}%
          </span>
        </div>
      </div>

      {/* 2. Event Ticker (Countdowns) */}
      <div className="flex flex-col gap-3">
        <span className="text-xs font-mono font-bold text-zinc-400 flex items-center gap-1.5 border-t border-zinc-800/80 pt-4">
          Upcoming Catalyst Events
        </span>

        <div className="flex flex-col gap-2">
          {events.map((evt) => (
            <div
              key={evt.id}
              className="bg-zinc-950/40 border border-zinc-850 p-2.5 rounded-lg flex items-center justify-between hover:border-zinc-800 transition-colors"
            >
              <div className="flex flex-col min-w-0">
                <span className="text-xs font-bold text-zinc-200 truncate pr-1">
                  {evt.title}
                </span>
                <span className="text-[9px] font-mono font-bold text-zinc-500 mt-0.5">
                  {evt.dateStr}
                </span>
              </div>

              <div className="flex flex-col items-end shrink-0">
                <span className={`text-[10px] font-mono font-bold flex items-center gap-1 p-1 rounded ${
                  evt.secondsRemaining > 0 
                    ? "text-amber-400 bg-amber-950/20" 
                    : "text-zinc-500 bg-zinc-900"
                }`}>
                  <Clock className="w-3 h-3 shrink-0" />
                  {formatCountdown(evt.secondsRemaining)}
                </span>
                <span className={`text-[8px] font-mono font-bold mt-1 ${
                  evt.importance === "HIGH" ? "text-rose-400" : "text-amber-500"
                }`}>
                  {evt.importance} IMPACT
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 3. Sector Heatmap (Volume Flows) */}
      <div className="flex flex-col gap-3">
        <span className="text-xs font-mono font-bold text-zinc-400 flex items-center gap-1.5 border-t border-zinc-800/80 pt-4">
          Sector Capital Flows
        </span>

        <div className="flex flex-wrap gap-2">
          {sectors.map((sec) => (
            <div
              key={sec.name}
              className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-mono font-bold border transition-colors ${
                sec.volumeFlow === "INFLOW"
                  ? "bg-emerald-950/20 border-emerald-900/40 text-emerald-400 hover:border-emerald-800/50"
                  : sec.volumeFlow === "OUTFLOW"
                  ? "bg-rose-950/20 border-rose-900/40 text-rose-400 hover:border-rose-800/50"
                  : "bg-zinc-950 border-zinc-850 text-zinc-400 hover:border-zinc-800"
              }`}
            >
              {sec.volumeFlow === "INFLOW" ? (
                <TrendingUp className="w-3.5 h-3.5" />
              ) : sec.volumeFlow === "OUTFLOW" ? (
                <TrendingDown className="w-3.5 h-3.5" />
              ) : (
                <Flame className="w-3.5 h-3.5" />
              )}
              <span>{sec.name}</span>
              <span className="opacity-80">
                {sec.percentageChange >= 0 ? "+" : ""}{sec.percentageChange}%
              </span>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
}
