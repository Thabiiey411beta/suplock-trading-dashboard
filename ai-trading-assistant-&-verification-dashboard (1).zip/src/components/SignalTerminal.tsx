import React from "react";
import { Signal } from "../types";
import { ShieldCheck, AlertTriangle, ArrowRight, TrendingUp, TrendingDown, Clock, Layers } from "lucide-react";

interface SignalTerminalProps {
  signals: Signal[];
  selectedSignal: Signal | null;
  onSelectSignal: (sig: Signal) => void;
  verifiedSignals: Record<string, boolean>;
  discardedSignals: Record<string, boolean>;
  activeVolatilityAlert?: any;
  onDismissVolatilityAlert?: () => void;
}

export default function SignalTerminal({ 
  signals, 
  selectedSignal, 
  onSelectSignal,
  verifiedSignals,
  discardedSignals,
  activeVolatilityAlert,
  onDismissVolatilityAlert
}: SignalTerminalProps) {
  
  const getRiskColor = (level: string) => {
    switch (level) {
      case "LOW": return "bg-emerald-950/50 text-emerald-400 border-emerald-900/30";
      case "MEDIUM": return "bg-amber-950/50 text-amber-400 border-amber-900/30";
      case "HIGH": return "bg-rose-950/50 text-rose-400 border-rose-900/30";
      default: return "bg-zinc-950 text-zinc-400 border-zinc-800";
    }
  };

  return (
    <div className="w-full bg-zinc-900 border border-zinc-850 rounded-lg p-5 font-sans shadow-lg flex flex-col gap-4">
      <div className="flex items-center justify-between border-b border-zinc-800 pb-3.5">
        <div className="flex items-center gap-2">
          <Layers className="w-5 h-5 text-emerald-400" />
          <h2 className="text-sm font-bold tracking-wider text-zinc-100 uppercase">AI Signal Terminal Feed</h2>
        </div>
        <span className="text-xs text-zinc-400 font-mono">
          {signals.length} Signals Generated
        </span>
      </div>

      {activeVolatilityAlert && (
        <div id="volatility-warning-overlay" className="bg-gradient-to-r from-amber-950/70 via-rose-950/70 to-amber-950/70 border border-amber-500/40 rounded-lg p-4 font-sans relative overflow-hidden animate-pulse shadow-lg">
          <div className="absolute inset-0 bg-amber-500/5 mix-blend-overlay pointer-events-none"></div>
          <div className="flex items-start gap-3.5">
            <div className="p-2.5 rounded bg-amber-500/20 text-amber-400 border border-amber-500/30 shrink-0">
              <AlertTriangle className="w-5 h-5 text-amber-400 animate-bounce" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <span className="inline-block w-2 h-2 rounded-full bg-rose-500 animate-ping"></span>
                <h4 className="text-xs font-bold text-amber-300 uppercase tracking-widest font-mono">
                  VOLATILITY ANOMALY ALERT
                </h4>
              </div>
              <p className="text-[11px] text-zinc-100 font-bold mt-1.5 font-sans leading-tight">
                {activeVolatilityAlert.asset} is experiencing a critical volatility breakout of{" "}
                <span className="text-rose-400 font-extrabold">+{activeVolatilityAlert.deviationPercent}%</span> relative to its 24-hour baseline.
              </p>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 my-2.5 font-mono text-[9px] bg-zinc-950/60 p-2 rounded border border-zinc-850/60">
                <div>
                  <span className="text-zinc-500 block uppercase font-bold text-[8px]">Live Volatility</span>
                  <span className="text-rose-400 font-extrabold">{activeVolatilityAlert.currentVol.toFixed(3)}%</span>
                </div>
                <div>
                  <span className="text-zinc-500 block uppercase font-bold text-[8px]">24h Rolling Avg</span>
                  <span className="text-zinc-400 font-semibold">{activeVolatilityAlert.baselineVol.toFixed(3)}%</span>
                </div>
                <div className="col-span-2 sm:col-span-1">
                  <span className="text-zinc-500 block uppercase font-bold text-[8px]">Protection Advisory</span>
                  <span className="text-amber-400 font-bold uppercase text-[8px]">Widening spreads</span>
                </div>
              </div>
              <p className="text-[10px] text-zinc-400 leading-relaxed max-w-xl">
                ⚠️ <span className="font-bold text-zinc-300">Advice:</span> High-frequency volatility anomalies introduce extreme bid/ask slippage risks. Standard stop-losses may fail. Tighten position size or use 1.5% streak blockers to safeguard capital.
              </p>
            </div>
            {onDismissVolatilityAlert && (
              <button
                onClick={onDismissVolatilityAlert}
                className="text-[10px] uppercase font-mono bg-zinc-900 hover:bg-zinc-800 text-zinc-400 px-2.5 py-1 rounded border border-zinc-800 transition-all hover:text-zinc-200 cursor-pointer self-start shrink-0"
              >
                Acknowledge
              </button>
            )}
          </div>
        </div>
      )}

      <div className="flex flex-col gap-4">
        {signals.map((sig) => {
          const isSelected = selectedSignal?.id === sig.id;
          const isBuy = sig.action === "BUY";
          const isVerified = !!verifiedSignals[sig.id];
          const isDiscarded = !!discardedSignals[sig.id];

          return (
            <div
              key={sig.id}
              className={`border rounded-lg p-4 transition-all relative overflow-hidden ${
                isSelected
                  ? "bg-zinc-950/80 border-emerald-500 shadow-emerald-950/10 shadow-md scale-[1.01]"
                  : isVerified
                  ? "bg-zinc-950/40 border-emerald-900/30 opacity-70"
                  : isDiscarded
                  ? "bg-zinc-950/40 border-rose-950/30 opacity-50"
                  : "bg-zinc-950/60 hover:bg-zinc-950 border-zinc-850 hover:border-zinc-750"
              }`}
            >
              {/* Top Accent Bar based on Action */}
              <div className={`absolute top-0 left-0 right-0 h-1 ${isBuy ? "bg-emerald-500" : "bg-rose-500"}`}></div>

              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                {/* Left Side: Identity */}
                <div className="flex items-center gap-3.5">
                  <div className={`p-2.5 rounded-md font-mono text-center font-bold text-sm w-16 h-12 flex flex-col justify-center items-center ${
                    isBuy 
                      ? "bg-emerald-950/60 text-emerald-400 border border-emerald-900/40" 
                      : "bg-rose-950/60 text-rose-400 border border-rose-900/40"
                  }`}>
                    {isBuy ? (
                      <>
                        <TrendingUp className="w-3.5 h-3.5" />
                        <span className="text-[10px] mt-0.5 tracking-wider">BUY</span>
                      </>
                    ) : (
                      <>
                        <TrendingDown className="w-3.5 h-3.5" />
                        <span className="text-[10px] mt-0.5 tracking-wider">SELL</span>
                      </>
                    )}
                  </div>

                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="text-base font-bold text-zinc-100">{sig.asset}</h3>
                      <span className="text-xs bg-zinc-850 text-zinc-300 font-mono px-2 py-0.5 rounded-sm border border-zinc-800">
                        {sig.timeframe}
                      </span>
                    </div>
                    <div className="flex items-center gap-3 text-xs text-zinc-400 mt-1 font-mono">
                      <span className="flex items-center gap-1">
                        <Clock className="w-3.5 h-3.5 text-zinc-500" />
                        {new Date(sig.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                      </span>
                      <span>&bull;</span>
                      <span className={`px-2 py-0.5 rounded-full border text-[10px] font-bold tracking-wider ${getRiskColor(sig.riskLevel)}`}>
                        {sig.riskLevel} RISK
                      </span>
                    </div>
                  </div>
                </div>

                {/* Center: Details */}
                <div className="grid grid-cols-3 gap-4 border-t border-b sm:border-t-0 sm:border-b-0 border-zinc-900 py-3 sm:py-0 font-mono text-xs text-center">
                  <div>
                    <p className="text-[10px] text-zinc-500 uppercase tracking-wider font-semibold">Entry price</p>
                    <p className="text-zinc-200 font-semibold mt-0.5 text-sm">
                      {sig.price.toLocaleString(undefined, { minimumFractionDigits: sig.asset.includes("JPY") ? 2 : sig.asset === "USD/ZAR" ? 4 : 2 })}
                    </p>
                  </div>
                  <div>
                    <p className="text-[10px] text-zinc-500 uppercase tracking-wider font-semibold">Stop loss</p>
                    <p className="text-rose-400 font-semibold mt-0.5 text-sm">
                      {sig.stopLoss.toLocaleString(undefined, { minimumFractionDigits: sig.asset.includes("JPY") ? 2 : sig.asset === "USD/ZAR" ? 4 : 2 })}
                    </p>
                  </div>
                  <div>
                    <p className="text-[10px] text-zinc-500 uppercase tracking-wider font-semibold">Take profit</p>
                    <p className="text-emerald-400 font-semibold mt-0.5 text-sm">
                      {sig.takeProfit.toLocaleString(undefined, { minimumFractionDigits: sig.asset.includes("JPY") ? 2 : sig.asset === "USD/ZAR" ? 4 : 2 })}
                    </p>
                  </div>
                </div>

                {/* Right Side: Action Trigger */}
                <div className="flex items-center justify-between sm:justify-end gap-3.5">
                  <div className="text-right font-mono">
                    <p className="text-[10px] text-zinc-500 uppercase tracking-wider font-semibold">Confidence</p>
                    <div className="flex items-center gap-1.5 justify-end">
                      <div className="w-12 bg-zinc-800 h-1.5 rounded-full overflow-hidden">
                        <div 
                          className={`h-full ${sig.confidence > 80 ? 'bg-emerald-500' : 'bg-amber-500'}`}
                          style={{ width: `${sig.confidence}%` }}
                        ></div>
                      </div>
                      <span className="text-zinc-200 font-bold text-xs">{sig.confidence}%</span>
                    </div>
                  </div>

                  <button
                    onClick={() => onSelectSignal(sig)}
                    disabled={isDiscarded}
                    className={`flex items-center justify-center gap-1.5 px-4 py-2 rounded font-semibold text-xs tracking-wide transition-all border cursor-pointer ${
                      isSelected
                        ? "bg-emerald-500 text-zinc-950 border-emerald-400 font-bold shadow-sm shadow-emerald-500/20"
                        : isVerified
                        ? "bg-emerald-950/30 hover:bg-emerald-900/20 text-emerald-400 border-emerald-900/30 hover:border-emerald-700/40"
                        : isDiscarded
                        ? "bg-rose-950/10 text-rose-500 border-rose-950/20 opacity-30 cursor-not-allowed"
                        : "bg-zinc-900 hover:bg-zinc-850 active:bg-zinc-950 text-zinc-100 border-zinc-800 hover:border-zinc-700"
                    }`}
                  >
                    {isVerified ? (
                      <>
                        <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                        <span>Verified</span>
                      </>
                    ) : isDiscarded ? (
                      <>
                        <AlertTriangle className="w-3.5 h-3.5 text-rose-500" />
                        <span>Discarded</span>
                      </>
                    ) : (
                      <>
                        <span>Verify Signal</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </>
                    )}
                  </button>
                </div>
              </div>

              {/* Mini technical reasons collapsed inside signal item preview */}
              <div className="mt-3.5 pt-3 border-t border-zinc-900/70 flex flex-wrap gap-2 items-center justify-between">
                <p className="text-xs text-zinc-400 font-sans italic line-clamp-1 max-w-[85%]">
                  &ldquo;{sig.reasoning[0]}&rdquo;
                </p>
                <div className="flex items-center gap-1.5 text-[10px] font-mono text-zinc-500">
                  <span>Macro:</span>
                  <span className={`font-bold ${sig.macroSentiment === "BULLISH" ? "text-emerald-400" : sig.macroSentiment === "BEARISH" ? "text-rose-400" : "text-zinc-400"}`}>
                    {sig.macroSentiment}
                  </span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
