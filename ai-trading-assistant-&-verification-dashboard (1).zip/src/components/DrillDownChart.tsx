import React from "react";
import { TrendingUp, ShieldAlert, CheckCircle, Percent } from "lucide-react";

interface DrillDownChartProps {
  asset: string;
  entryZone: number;
  takeProfit: number;
  stopLoss: number;
  action: "LONG" | "SHORT";
}

export default function DrillDownChart({ asset, entryZone, takeProfit, stopLoss, action }: DrillDownChartProps) {
  // Calculate risk and reward dimensions
  const risk = Math.abs(entryZone - stopLoss);
  const reward = Math.abs(takeProfit - entryZone);
  const rrRatio = risk > 0 ? (reward / risk).toFixed(2) : "N/A";

  // Calculate percentage levels for visual rendering
  const minVal = Math.min(entryZone, takeProfit, stopLoss);
  const maxVal = Math.max(entryZone, takeProfit, stopLoss);
  const span = maxVal - minVal || 1;

  // Pad the bounds slightly
  const chartMin = minVal - span * 0.15;
  const chartMax = maxVal + span * 0.15;
  const chartSpan = chartMax - chartMin;

  const getPct = (val: number) => {
    return ((val - chartMin) / chartSpan) * 100;
  };

  const slPct = getPct(stopLoss);
  const entryPct = getPct(entryZone);
  const tpPct = getPct(takeProfit);

  // Determine colors and directions based on action
  const isLong = action === "LONG";
  const rewardColor = "text-emerald-400 bg-emerald-950/40 border-emerald-900/50";
  const riskColor = "text-rose-400 bg-rose-950/40 border-rose-900/50";

  return (
    <div className="bg-zinc-950 border border-zinc-850 p-4 rounded-lg flex flex-col gap-4">
      {/* Chart Header */}
      <div className="flex justify-between items-center">
        <div>
          <span className="text-[10px] font-mono font-bold text-zinc-500 uppercase tracking-wider block">
            SUPERVISOR RISK DRILLDOWN
          </span>
          <h4 className="text-sm font-bold text-zinc-200 mt-0.5">
            {asset} &middot; Risk-Reward Profile
          </h4>
        </div>

        <div className="text-right">
          <span className="text-[10px] font-mono font-bold text-zinc-500 uppercase block">
            R:R RATIO
          </span>
          <span className="text-sm font-extrabold font-mono text-teal-400">
            1 : {rrRatio}
          </span>
        </div>
      </div>

      {/* Visual Chart - High-Fidelity SVG Diagram */}
      <div className="relative h-44 bg-zinc-900/60 border border-zinc-850/80 rounded-lg p-4 flex flex-col justify-between overflow-hidden">
        
        {/* Background Grid Lines */}
        <div className="absolute inset-0 flex flex-col justify-between pointer-events-none p-4">
          <div className="border-t border-dashed border-zinc-800/40 w-full" />
          <div className="border-t border-dashed border-zinc-800/40 w-full" />
          <div className="border-t border-dashed border-zinc-800/40 w-full" />
        </div>

        {/* Take Profit Zone (Green overlay) */}
        <div 
          className="absolute left-0 right-0 bg-emerald-500/[0.03] border-y border-emerald-500/[0.07] pointer-events-none transition-all"
          style={{
            bottom: `${isLong ? entryPct : tpPct}%`,
            top: `${100 - (isLong ? tpPct : entryPct)}%`
          }}
        />

        {/* Stop Loss Zone (Red overlay) */}
        <div 
          className="absolute left-0 right-0 bg-rose-500/[0.03] border-y border-rose-500/[0.07] pointer-events-none transition-all"
          style={{
            bottom: `${isLong ? slPct : entryPct}%`,
            top: `${100 - (isLong ? entryPct : slPct)}%`
          }}
        />

        {/* Level lines & labels */}
        
        {/* 1. Take Profit Level */}
        <div 
          className="absolute left-4 right-4 flex items-center justify-between group transition-all"
          style={{ bottom: `${tpPct}%` }}
        >
          <div className="h-[1px] bg-emerald-500/40 flex-1 border-t border-emerald-500/20" />
          <div className="flex items-center gap-1.5 bg-emerald-950/80 border border-emerald-800/60 px-2 py-0.5 rounded text-[10px] font-mono font-bold text-emerald-400 ml-3 shrink-0 shadow-lg">
            <CheckCircle className="w-3 h-3 text-emerald-400" />
            <span>TP Level: {takeProfit.toLocaleString()}</span>
          </div>
        </div>

        {/* 2. Entry Zone Level */}
        <div 
          className="absolute left-4 right-4 flex items-center justify-between group transition-all"
          style={{ bottom: `${entryPct}%` }}
        >
          <div className="h-[1px] bg-zinc-400/40 flex-1 border-t border-zinc-500/20" />
          <div className="flex items-center gap-1.5 bg-zinc-900 border border-zinc-700 px-2 py-0.5 rounded text-[10px] font-mono font-bold text-zinc-200 ml-3 shrink-0 shadow-lg">
            <div className="w-1.5 h-1.5 rounded-full bg-zinc-100 animate-ping" />
            <span>Entry Zone: {entryZone.toLocaleString()}</span>
          </div>
        </div>

        {/* 3. Stop Loss Level */}
        <div 
          className="absolute left-4 right-4 flex items-center justify-between group transition-all"
          style={{ bottom: `${slPct}%` }}
        >
          <div className="h-[1px] bg-rose-500/40 flex-1 border-t border-rose-500/20" />
          <div className="flex items-center gap-1.5 bg-rose-950/80 border border-rose-800/60 px-2 py-0.5 rounded text-[10px] font-mono font-bold text-rose-400 ml-3 shrink-0 shadow-lg">
            <ShieldAlert className="w-3 h-3 text-rose-400" />
            <span>SL Level: {stopLoss.toLocaleString()}</span>
          </div>
        </div>

      </div>

      {/* Metrics Footer */}
      <div className="grid grid-cols-2 gap-3 text-xs font-mono font-bold">
        <div className={`p-2.5 rounded-lg border flex flex-col justify-between ${isLong ? rewardColor : riskColor}`}>
          <span className="text-[9px] text-zinc-500 block uppercase">Target Reward</span>
          <span className="text-sm font-bold mt-1">
            {reward.toLocaleString()} pts ({((reward / entryZone) * 100).toFixed(2)}%)
          </span>
        </div>

        <div className={`p-2.5 rounded-lg border flex flex-col justify-between ${isLong ? riskColor : rewardColor}`}>
          <span className="text-[9px] text-zinc-500 block uppercase">Protective Risk</span>
          <span className="text-sm font-bold mt-1">
            {risk.toLocaleString()} pts ({((risk / entryZone) * 100).toFixed(2)}%)
          </span>
        </div>
      </div>
    </div>
  );
}
