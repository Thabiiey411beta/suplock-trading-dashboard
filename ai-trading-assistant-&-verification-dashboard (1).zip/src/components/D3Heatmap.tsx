import React, { useRef, useEffect, useState } from "react";
import * as d3 from "d3";
import { Signal, MarketQuote } from "../types";
import { Grid, Flame, Info, Cpu, CheckCircle } from "lucide-react";

interface D3HeatmapProps {
  signals: Signal[];
  quotes: MarketQuote[];
}

interface HeatmapCell {
  asset: string;
  timeframe: string;
  type: "signal" | "indicator" | "neutral";
  action: "BUY" | "SELL" | "NEUTRAL";
  score: number; // confidence score (50-100) or momentum intensity
  label: string;
  details: string;
  rsi?: number;
  volatility?: number;
}

const ASSETS = ["GBP/JPY", "USD/ZAR", "Gold (XAU/USD)", "Bitcoin", "Ethereum"];
const TIMEFRAMES = ["M15", "H1", "H4", "D1"];

// Helper to map UI Asset names to Quote symbols
const getQuoteSymbol = (asset: string): string => {
  if (asset === "GBP/JPY") return "GBPJPY=X";
  if (asset === "USD/ZAR") return "USDZAR=X";
  if (asset.includes("Gold") || asset === "Gold") return "GC=F";
  if (asset === "Bitcoin" || asset === "BTC") return "BTC-USD";
  if (asset === "Ethereum" || asset === "ETH") return "ETH-USD";
  return asset;
};

export default function D3Heatmap({ signals, quotes }: D3HeatmapProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const svgRef = useRef<SVGSVGElement>(null);
  const [dimensions, setDimensions] = useState({ width: 600, height: 260 });
  const [hoveredCell, setHoveredCell] = useState<HeatmapCell | null>(null);
  const [tooltipPos, setTooltipPos] = useState({ x: 0, y: 0 });

  // 1. Resize observer for fluid layout
  useEffect(() => {
    if (!containerRef.current) return;

    const resizeObserver = new ResizeObserver((entries) => {
      if (!entries || entries.length === 0) return;
      const { width } = entries[0].contentRect;
      setDimensions({
        width: Math.max(280, width),
        height: 260
      });
    });

    resizeObserver.observe(containerRef.current);
    return () => resizeObserver.disconnect();
  }, []);

  // 2. Generate and calculate cell data dynamically
  const getCellData = (asset: string, timeframe: string): HeatmapCell => {
    // Check if an active AI signal matches
    const activeSignal = signals.find(
      s => s.asset === asset && s.timeframe === timeframe
    );

    const quoteSymbol = getQuoteSymbol(asset);
    const quote = quotes.find(q => q.symbol === quoteSymbol);

    if (activeSignal) {
      return {
        asset,
        timeframe,
        type: "signal",
        action: activeSignal.action,
        score: activeSignal.confidence,
        label: `${activeSignal.action} ${activeSignal.confidence}%`,
        details: activeSignal.reasoning[0] || "Active high-confluence AI signal entry.",
        rsi: quote?.rsi,
        volatility: quote?.volatility
      };
    }

    // Otherwise, simulate a quantitative indicators baseline
    if (quote) {
      const rsiVal = quote.rsi || 50;
      const price = quote.price || 1;
      const sma5Val = quote.sma5 || price;
      const sma10Val = quote.sma10 || price;

      const isSmaBullish = sma5Val > sma10Val;
      let score = 0;

      if (isSmaBullish) score += 20;
      else score -= 20;

      if (rsiVal < 40) score += 30; // Oversold -> BUY confluence
      else if (rsiVal > 60) score -= 30; // Overbought -> SELL confluence

      // Timeframe-specific variation (stable hash)
      const tfHash = timeframe.charCodeAt(0) + (timeframe.charCodeAt(1) || 0);
      score += (tfHash % 16) - 8;

      // Clamp score
      score = Math.max(-90, Math.min(90, score));

      let action: "BUY" | "SELL" | "NEUTRAL" = "NEUTRAL";
      if (score > 12) action = "BUY";
      else if (score < -12) action = "SELL";

      const confidenceLevel = Math.round(50 + Math.abs(score) * 0.5);

      return {
        asset,
        timeframe,
        type: "indicator",
        action,
        score: confidenceLevel,
        label: action === "NEUTRAL" ? "NEUTRAL" : `${action} ${confidenceLevel}%`,
        details: `Technical consensus. RSI: ${rsiVal.toFixed(1)}, Trend: ${isSmaBullish ? "Bullish" : "Bearish"} (SMA Cross)`,
        rsi: rsiVal,
        volatility: quote.volatility
      };
    }

    return {
      asset,
      timeframe,
      type: "neutral",
      action: "NEUTRAL",
      score: 50,
      label: "NEUTRAL",
      details: "Awaiting incoming quantitative stream data."
    };
  };

  const cellsData: HeatmapCell[] = [];
  ASSETS.forEach(asset => {
    TIMEFRAMES.forEach(tf => {
      cellsData.push(getCellData(asset, tf));
    });
  });

  // 3. Render Heatmap using D3 Selection
  useEffect(() => {
    if (!svgRef.current || cellsData.length === 0) return;

    const svg = d3.select(svgRef.current);
    svg.selectAll("*").remove(); // Fresh render

    const margin = { top: 35, right: 15, bottom: 15, left: 110 };
    const innerWidth = dimensions.width - margin.left - margin.right;
    const innerHeight = dimensions.height - margin.top - margin.bottom;

    // Define main drawing group
    const g = svg.append("g")
      .attr("transform", `translate(${margin.left}, ${margin.top})`);

    // D3 Scales
    const xScale = d3.scaleBand()
      .domain(TIMEFRAMES)
      .range([0, innerWidth])
      .padding(0.06);

    const yScale = d3.scaleBand()
      .domain(ASSETS)
      .range([0, innerHeight])
      .padding(0.06);

    // Color mapper for intensity
    // Red diverges to Gray then to Green
    const getCellColor = (cell: HeatmapCell) => {
      if (cell.action === "BUY") {
        // map score (50-100) to green intensity
        const t = (cell.score - 50) / 50; // 0.0 to 1.0
        return d3.interpolateRgb("#064e3b", "#10b981")(t); // deep emerald to bright green
      } else if (cell.action === "SELL") {
        const t = (cell.score - 50) / 50;
        return d3.interpolateRgb("#4c0519", "#f43f5e")(t); // deep maroon to rose
      } else {
        return "#1c1917"; // Neutral gray background
      }
    };

    // Render cells (rectangles)
    g.selectAll(".cell")
      .data(cellsData)
      .enter()
      .append("rect")
      .attr("class", "cell")
      .attr("x", d => xScale(d.timeframe) || 0)
      .attr("y", d => yScale(d.asset) || 0)
      .attr("width", xScale.bandwidth())
      .attr("height", yScale.bandwidth())
      .attr("rx", 4) // Pill style corners
      .attr("ry", 4)
      .style("fill", d => getCellColor(d))
      .style("stroke", d => d.type === "signal" ? "#34d399" : "#27272a")
      .style("stroke-width", d => d.type === "signal" ? 1.5 : 1)
      .style("cursor", "pointer")
      .style("transition", "opacity 0.15s ease")
      .on("mouseover", function (event, d) {
        d3.select(this)
          .style("opacity", 0.85)
          .style("stroke", "#10b981")
          .style("stroke-width", 2);
        
        setHoveredCell(d);
        
        // Compute tooltip coordinates relative to parent container
        const [mx, my] = d3.pointer(event, containerRef.current);
        setTooltipPos({ x: mx + 15, y: my - 30 });
      })
      .on("mousemove", function (event) {
        const [mx, my] = d3.pointer(event, containerRef.current);
        setTooltipPos({ x: mx + 15, y: my - 30 });
      })
      .on("mouseleave", function (event, d) {
        d3.select(this)
          .style("opacity", 1.0)
          .style("stroke", d.type === "signal" ? "#34d399" : "#27272a")
          .style("stroke-width", d.type === "signal" ? 1.5 : 1);
        setHoveredCell(null);
      });

    // Render text overlay inside each cell (e.g. "BUY 85%")
    g.selectAll(".cell-text")
      .data(cellsData)
      .enter()
      .append("text")
      .attr("class", "cell-text")
      .attr("x", d => (xScale(d.timeframe) || 0) + xScale.bandwidth() / 2)
      .attr("y", d => (yScale(d.asset) || 0) + yScale.bandwidth() / 2 + 3)
      .attr("text-anchor", "middle")
      .style("fill", d => d.action === "NEUTRAL" ? "#71717a" : "#ffffff")
      .style("font-size", "9px")
      .style("font-family", "monospace")
      .style("font-weight", d => d.type === "signal" ? "900" : "500")
      .style("pointer-events", "none")
      .text(d => d.action === "NEUTRAL" ? "NEUTRAL" : d.label);

    // Render left axis labels (Assets)
    g.selectAll(".asset-label")
      .data(ASSETS)
      .enter()
      .append("text")
      .attr("class", "asset-label")
      .attr("x", -10)
      .attr("y", d => (yScale(d) || 0) + yScale.bandwidth() / 2 + 4)
      .attr("text-anchor", "end")
      .style("fill", "#a1a1aa")
      .style("font-size", "10px")
      .style("font-family", "sans-serif")
      .style("font-weight", "600")
      .text(d => d);

    // Render top axis labels (Timeframes)
    g.selectAll(".timeframe-label")
      .data(TIMEFRAMES)
      .enter()
      .append("text")
      .attr("class", "timeframe-label")
      .attr("x", d => (xScale(d) || 0) + xScale.bandwidth() / 2)
      .attr("y", -12)
      .attr("text-anchor", "middle")
      .style("fill", "#a1a1aa")
      .style("font-size", "10px")
      .style("font-family", "monospace")
      .style("font-weight", "700")
      .text(d => d);

  }, [cellsData, dimensions]);

  return (
    <div id="d3-confluence-heatmap" className="bg-zinc-900 border border-zinc-850 rounded-lg p-5 font-sans shadow-lg relative flex flex-col gap-3">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
        <div className="flex items-center gap-2">
          <Grid className="w-5 h-5 text-emerald-400" />
          <h2 className="text-sm font-bold tracking-wider text-zinc-100 uppercase">
            D3 Multi-Timeframe Signal Heatmap
          </h2>
        </div>
        <div className="flex items-center gap-1.5 bg-emerald-950/40 px-2 py-0.5 rounded border border-emerald-900/30 text-[9px] font-mono font-bold text-emerald-400 uppercase select-none">
          <Flame className="w-3 h-3 text-amber-500 animate-pulse" />
          Confluence Analyzer
        </div>
      </div>

      <p className="text-[11px] text-zinc-400 leading-relaxed font-sans">
        This heatmap processes active AI boundaries combined with real-time technical momentum indicators (RSI + SMA crossovers) to highlight confluence clusters. Green signals bullish momentum, red signals bearish pressure.
      </p>

      {/* SVG Canvas Container */}
      <div ref={containerRef} className="w-full relative h-[260px] bg-zinc-950/30 border border-zinc-900 rounded p-1">
        <svg ref={svgRef} width={dimensions.width} height={dimensions.height} className="overflow-visible" />

        {/* Dynamic Tooltip Overlay */}
        {hoveredCell && (
          <div
            className="absolute z-50 bg-zinc-950 border border-zinc-800 rounded-lg p-3 w-64 shadow-2xl pointer-events-none text-xs font-mono select-none flex flex-col gap-1.5 backdrop-blur-md"
            style={{
              left: `${tooltipPos.x}px`,
              top: `${tooltipPos.y}px`,
              transform: `translateX(${tooltipPos.x > dimensions.width - 200 ? "-105%" : "0%"})`
            }}
          >
            <div className="flex items-center justify-between border-b border-zinc-850 pb-1.5">
              <span className="font-bold text-zinc-200">{hoveredCell.asset}</span>
              <span className="bg-zinc-800 text-zinc-300 px-1.5 py-0.5 rounded text-[9px] uppercase font-bold">
                {hoveredCell.timeframe}
              </span>
            </div>
            
            <div className="flex justify-between items-center mt-1">
              <span className="text-zinc-500 text-[10px]">CONCENSUS:</span>
              <span className={`font-extrabold text-[10px] uppercase ${
                hoveredCell.action === "BUY" ? "text-emerald-400" : hoveredCell.action === "SELL" ? "text-rose-400" : "text-zinc-400"
              }`}>
                {hoveredCell.action} {hoveredCell.action !== "NEUTRAL" && `(${hoveredCell.score}%)`}
              </span>
            </div>

            <div className="flex justify-between items-center">
              <span className="text-zinc-500 text-[10px]">SOURCE:</span>
              <span className={`text-[10px] font-bold flex items-center gap-1 ${
                hoveredCell.type === "signal" ? "text-emerald-400" : "text-amber-500"
              }`}>
                {hoveredCell.type === "signal" ? (
                  <>
                    <Cpu className="w-3 h-3 text-emerald-400" />
                    AI AGENT
                  </>
                ) : (
                  <>
                    <Info className="w-3 h-3 text-amber-500" />
                    QUANT RUNTIME
                  </>
                )}
              </span>
            </div>

            {hoveredCell.rsi !== undefined && (
              <div className="flex justify-between items-center text-[10px]">
                <span className="text-zinc-500">RSI Indicator:</span>
                <span className="text-zinc-300 font-bold">{hoveredCell.rsi.toFixed(1)}</span>
              </div>
            )}

            {hoveredCell.volatility !== undefined && (
              <div className="flex justify-between items-center text-[10px]">
                <span className="text-zinc-500">Volatility Index:</span>
                <span className="text-zinc-300 font-bold">{hoveredCell.volatility.toFixed(3)}%</span>
              </div>
            )}

            <div className="border-t border-zinc-900 mt-1 pt-1.5">
              <p className="text-[9px] text-zinc-400 leading-relaxed font-sans italic">
                &ldquo;{hoveredCell.details}&rdquo;
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Grid Legend */}
      <div className="flex flex-wrap items-center justify-between text-[10px] font-mono text-zinc-500 pt-1 border-t border-zinc-900">
        <div className="flex items-center gap-2">
          <span>Legend:</span>
          <span className="flex items-center gap-1">
            <span className="w-2.5 h-2.5 rounded bg-rose-500 inline-block border border-rose-400/30"></span>
            SELL
          </span>
          <span className="flex items-center gap-1">
            <span className="w-2.5 h-2.5 rounded bg-zinc-800 inline-block"></span>
            NEUTRAL
          </span>
          <span className="flex items-center gap-1">
            <span className="w-2.5 h-2.5 rounded bg-emerald-500 inline-block border border-emerald-400/30"></span>
            BUY
          </span>
        </div>
        <div className="flex items-center gap-1 text-[9px] text-zinc-400 font-sans mt-1 sm:mt-0">
          <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
          Highlighted cells indicate active AI boundaries.
        </div>
      </div>
    </div>
  );
}
