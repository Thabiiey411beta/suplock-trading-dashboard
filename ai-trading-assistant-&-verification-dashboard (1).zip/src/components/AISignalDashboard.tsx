import React, { useState } from "react";
import { useAISignals } from "../hooks/useAISignals";
import MacroWeatherReport from "./MacroWeatherReport";
import ConsensusFeed from "./ConsensusFeed";
import RiskManager from "./RiskManager";
import { AIConsensusSignal } from "../types";
import { Cpu, AlertTriangle, HelpCircle, ArrowRight, Shield, RefreshCw } from "lucide-react";

export default function AISignalDashboard() {
  const { signals, macroContext, setSignals } = useAISignals();
  const [selectedSignal, setSelectedSignal] = useState<AIConsensusSignal | null>(signals[0] || null);

  const handleSelectSignalForRisk = (signal: AIConsensusSignal) => {
    setSelectedSignal(signal);
  };

  const handleConfirmTrade = (trade: any) => {
    console.log("[AISignalDashboard] Executing safe trade projection:", trade);
    // Optionally trigger a local flash alert or notify parent
  };

  return (
    <div className="flex flex-col gap-6 w-full animate-fadeIn">
      {/* Dashboard Mini-Header with stats */}
      <div className="bg-zinc-900 border border-zinc-850 p-4 rounded-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex gap-3.5 items-center">
          <div className="bg-emerald-950/60 border border-emerald-900/30 p-2.5 rounded text-emerald-400 shrink-0">
            <Cpu className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-sm font-bold text-zinc-100 uppercase tracking-wide">
                AI Signal Command Center
              </h2>
              <span className="bg-emerald-950 text-emerald-400 border border-emerald-900/30 text-[9px] font-mono font-bold px-2 py-0.5 rounded">
                Consensus Route Active
              </span>
            </div>
            <p className="text-xs text-zinc-400 mt-1 max-w-xl leading-relaxed">
              Consolidated real-time signals from the Multi-Model (Gemini/OpenAI) Supervisor Router. Prioritizing pure execution, safety restrictions, and protective risk parameter checks.
            </p>
          </div>
        </div>

        {/* Dynamic Connected stats for Context */}
        <div className="flex items-center gap-4 border-l border-zinc-800 pl-4 py-1 self-start md:self-auto shrink-0 font-mono text-[11px]">
          <div>
            <span className="text-zinc-500 block uppercase font-bold text-[9px]">WALLET CONNECTED</span>
            <span className="text-zinc-200 font-bold block mt-0.5">0x71C...89e2</span>
          </div>
          <div className="border-l border-zinc-800 pl-4">
            <span className="text-zinc-500 block uppercase font-bold text-[9px]">ACCUMULATED POINTS</span>
            <span className="text-emerald-400 font-bold block mt-0.5">4,250 PTS</span>
          </div>
        </div>
      </div>

      {/* Main 3-Panel Layout Grid/Flexbox matching target width boundaries */}
      <div className="flex flex-col lg:flex-row gap-6 w-full items-start">
        
        {/* Panel 1: Macro Context (Left Column, Target 20% width) */}
        <div className="w-full lg:w-[22%] shrink-0">
          <MacroWeatherReport data={macroContext} />
        </div>

        {/* Panel 2: Signal Command Center (Center Column, Target 55% width) */}
        <div className="w-full lg:w-[53%] shrink-0">
          <ConsensusFeed 
            signals={signals} 
            onSelectSignalForRisk={handleSelectSignalForRisk}
            selectedSignalId={selectedSignal?.id}
          />
        </div>

        {/* Panel 3: Safety Layer (Right Column, Target 25% width) */}
        <div className="w-full lg:w-[25%] shrink-0">
          <RiskManager 
            selectedSignal={selectedSignal} 
            onConfirmTrade={handleConfirmTrade}
          />
        </div>

      </div>

      {/* Quick guide notes on risk bounds */}
      <div className="border border-dashed border-zinc-850 bg-zinc-950/20 p-4 rounded-xl flex items-center justify-between flex-wrap gap-4 text-xs font-mono text-zinc-500">
        <div className="flex items-center gap-2">
          <Shield className="w-4 h-4 text-zinc-600 shrink-0" />
          <span>Risk Rule #1: Never exceed 1.5% capital exposure per single setup.</span>
        </div>
        <div className="flex items-center gap-1">
          <span>Supervisor Nodes Status:</span>
          <span className="text-emerald-400 font-bold">100% ONLINE</span>
        </div>
      </div>

    </div>
  );
}
