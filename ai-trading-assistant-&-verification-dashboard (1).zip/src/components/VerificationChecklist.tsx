import React, { useState, useEffect } from "react";
import { Signal, VerificationState } from "../types";
import RealTimeSentimentNews from "./RealTimeSentimentNews";
import D3MiniChart from "./D3MiniChart";
import { useSubscription } from "../SubscriptionContext";
import { 
  ResponsiveContainer, 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  Tooltip, 
  CartesianGrid, 
  AreaChart, 
  Area,
  ReferenceLine
} from "recharts";
import { 
  ShieldCheck, 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  CheckSquare, 
  Square, 
  HelpCircle, 
  AlertTriangle,
  Scale,
  Percent,
  TrendingUp as TrendUpIcon,
  Globe,
  Coins,
  ChevronRight,
  RefreshCw,
  Lock,
  Unlock
} from "lucide-react";

interface VerificationChecklistProps {
  signal: Signal;
  verification: VerificationState;
  onUpdateVerification: (state: Partial<VerificationState>) => void;
}

export default function VerificationChecklist({
  signal,
  verification,
  onUpdateVerification
}: VerificationChecklistProps) {
  const { isFeatureUnlocked, upgradeTier, tenantId } = useSubscription();
  const [balanceInput, setBalanceInput] = useState<string>("10000");
  const [activeStep, setActiveStep] = useState<number>(1);
  const [backtestLoading, setBacktestLoading] = useState<boolean>(false);
  const [backtestData, setBacktestData] = useState<any | null>(null);
  const [showBacktest, setShowBacktest] = useState<boolean>(false);

  // Reset backtest state if signal changes
  useEffect(() => {
    setShowBacktest(false);
    setBacktestData(null);
  }, [signal.id]);

  const handleRunBacktest = async () => {
    setBacktestLoading(true);
    setShowBacktest(true);
    try {
      const res = await fetch("/api/backtest", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-tenant-id": tenantId
        },
        body: JSON.stringify({ signal })
      });
      const result = await res.json();
      if (res.status === 403 || !result.success) {
        setBacktestData({
          error: result.error || "Upgrade Required",
          isLocked: true,
          requiredTier: result.requiredTier || "pro"
        });
      } else {
        setBacktestData(result);
      }
    } catch (err) {
      console.error("Backtest error:", err);
    } finally {
      setBacktestLoading(false);
    }
  };

  // Distances & Pip Values
  const isJPY = signal.asset.includes("JPY");
  const isZAR = signal.asset === "USD/ZAR";
  const isCrypto = signal.asset === "Bitcoin" || signal.asset === "Ethereum";
  const isGold = signal.asset === "Gold";

  let pipDistance = 0;
  let pipUnitLabel = "Pips";
  let multiplier = 1;

  if (isJPY) {
    pipDistance = Math.abs(signal.price - signal.stopLoss) * 100;
    multiplier = 100;
  } else if (isZAR) {
    pipDistance = Math.abs(signal.price - signal.stopLoss) * 10000;
    pipUnitLabel = "Pips";
    multiplier = 10000;
  } else if (isGold) {
    pipDistance = Math.abs(signal.price - signal.stopLoss);
    pipUnitLabel = "Points";
    multiplier = 1;
  } else if (isCrypto) {
    pipDistance = Math.abs(signal.price - signal.stopLoss);
    pipUnitLabel = "USD Points";
    multiplier = 1;
  }

  const pipsRisked = Number(pipDistance.toFixed(1));

  // Position Sizing Calculation
  useEffect(() => {
    const bal = parseFloat(balanceInput) || 0;
    const riskPct = 1.5; // Strictly hardcoded 1.5% maximum risk
    const riskAmt = bal * (riskPct / 100);

    let positionSize = 0; // standard lots for forex, ounces for gold, coins for crypto
    if (pipsRisked > 0) {
      if (isJPY) {
        // Standard Lot Pip cost is approx $9.00 USD for JPY cross rates
        // Formula: Lot Size = Risk Amount / (Pips * Standard Pip Value)
        // Let's assume standard pip cost of $9 per standard lot (100,000 contract)
        positionSize = riskAmt / (pipsRisked * 9);
      } else if (isZAR) {
        // USD/ZAR pip cost is approx $5.40 USD per standard lot
        positionSize = riskAmt / (pipsRisked * 5.4);
      } else if (isGold) {
        // Gold standard contract is 100 ounces. 1 Point move = $100 per lot.
        // Therefore, 1 Point move = $1.00 per ounce contract.
        positionSize = riskAmt / pipsRisked;
      } else if (isCrypto) {
        // Crypto standard contract is 1 Coin. 1 Point move = $1.00 per coin.
        positionSize = riskAmt / pipsRisked;
      }
    }

    onUpdateVerification({
      accountBalance: bal,
      riskAmount: Number(riskAmt.toFixed(2)),
      riskPercent: riskPct,
      pipsRisked: pipsRisked,
      calculatedPositionSize: Number(positionSize.toFixed(3))
    });
  }, [balanceInput, pipsRisked, signal.price, signal.stopLoss]);

  // Check correlation warning
  const isUSDZAR = signal.asset === "USD/ZAR";
  const isBuyAction = signal.action === "BUY";
  // South Africa is gold-reliant, so Gold rises -> ZAR strengthens -> USD/ZAR falls.
  // Inverse correlation check:
  // If Gold is rising and USD/ZAR is SELL, that matches logic.
  // If Gold is rising and USD/ZAR is BUY, that is an INVERSE CORRELATION WARNING!
  const hasCorrelationWarning = isUSDZAR && isBuyAction;

  const toggleStep = (step: number) => {
    if (step === 1) {
      onUpdateVerification({ sentimentChecked: !verification.sentimentChecked });
    } else if (step === 2) {
      onUpdateVerification({ correlationChecked: !verification.correlationChecked });
    } else if (step === 3) {
      onUpdateVerification({ probabilityChecked: !verification.probabilityChecked });
    } else if (step === 4) {
      onUpdateVerification({ riskCalculated: !verification.riskCalculated });
    }
  };

  const steps = [
    { id: 1, name: "Sentiment Check", checked: verification.sentimentChecked },
    { id: 2, name: "Correlation Analysis", checked: verification.correlationChecked },
    { id: 3, name: "Probability Boundary", checked: verification.probabilityChecked },
    { id: 4, name: "Manual Risk Model", checked: verification.riskCalculated }
  ];

  return (
    <div className="w-full bg-zinc-900 border border-zinc-850 rounded-lg p-5 font-sans shadow-lg">
      <div className="flex items-center justify-between border-b border-zinc-800 pb-3.5 mb-5">
        <div className="flex items-center gap-2">
          <Scale className="w-5 h-5 text-emerald-400" />
          <h2 className="text-sm font-bold tracking-wider text-zinc-100 uppercase">Interactive Verification Checklist</h2>
        </div>
        <div className="flex items-center gap-1.5 bg-rose-950/40 px-2.5 py-1 border border-rose-900/30 rounded text-[11px] font-mono font-bold text-rose-400">
          STREAK BLOCKER: ACTIVE
        </div>
      </div>

      {/* Progress Wizard Header */}
      <div className="flex justify-between items-center bg-zinc-950 border border-zinc-850 p-3 rounded-lg mb-6">
        {steps.map((s) => (
          <button
            key={s.id}
            onClick={() => setActiveStep(s.id)}
            className={`flex flex-1 items-center justify-center gap-2 py-1.5 px-2 rounded font-semibold text-xs transition-all cursor-pointer ${
              activeStep === s.id
                ? "bg-zinc-850 text-emerald-400 border border-zinc-700"
                : "text-zinc-400 hover:text-zinc-200"
            }`}
          >
            <span className={`w-4 h-4 rounded-full flex items-center justify-center text-[9px] font-bold ${
              s.checked ? "bg-emerald-500 text-zinc-950" : "bg-zinc-800 text-zinc-400"
            }`}>
              {s.id}
            </span>
            <span className="hidden md:inline">{s.name}</span>
          </button>
        ))}
      </div>

      {/* Confidence Heatmap Visualization */}
      <div id="confidence-heatmap" className="bg-zinc-950 border border-zinc-850 p-4.5 rounded-lg mb-6 shadow-inner">
        <div className="flex items-center justify-between mb-2.5">
          <span className="text-[11px] font-mono text-zinc-400 font-bold uppercase tracking-wider flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
            AI Confidence Heatmap
          </span>
          <div className="flex items-center gap-1.5">
            <span className="text-[10px] font-mono text-zinc-500 uppercase font-bold">Probability:</span>
            <span className="text-xs font-mono font-extrabold text-emerald-400 bg-emerald-950/50 px-2.5 py-0.5 rounded border border-emerald-900/40 shadow-sm">
              {signal.confidence}%
            </span>
          </div>
        </div>
        
        {/* Gradient Track */}
        <div className="relative w-full h-3.5 rounded-full bg-gradient-to-r from-rose-500 via-amber-500 to-emerald-500 border border-zinc-900 shadow-inner">
          {/* Glass-stripes indicator overlay */}
          <div className="absolute inset-0 rounded-full bg-[linear-gradient(45deg,rgba(255,255,255,0.1)_25%,transparent_25%,transparent_50%,rgba(255,255,255,0.1)_50%,rgba(255,255,255,0.1)_75%,transparent_75%,transparent)] bg-[length:8px_8px] opacity-20"></div>
          
          {/* Sliding indicator pin */}
          <div 
            className="absolute top-1/2 -translate-y-1/2 -ml-2.5 w-5 h-5 rounded-full bg-zinc-100 border-2 border-zinc-950 flex items-center justify-center shadow-[0_0_12px_rgba(255,255,255,0.4)] transition-all duration-700 ease-out z-10"
            style={{ left: `${signal.confidence}%` }}
          >
            <div className="w-1.5 h-1.5 rounded-full bg-zinc-900"></div>
          </div>
          
          {/* Glow shadow mapping the position */}
          <div 
            className="absolute top-1/2 -translate-y-1/2 -ml-4 w-8 h-8 rounded-full bg-zinc-400/10 blur-md transition-all duration-700 ease-out"
            style={{ left: `${signal.confidence}%` }}
          ></div>
        </div>
        
        {/* Labels */}
        <div className="flex justify-between items-center text-[9px] font-mono text-zinc-500 mt-2.5 font-bold tracking-tight">
          <span className="text-rose-500/90 flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-rose-500"></span>
            HIGH RISK (0-40%)
          </span>
          <span className="text-amber-500/90 flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-amber-500"></span>
            CONSOLIDATION (40-70%)
          </span>
          <span className="text-emerald-500/90 flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
            STABLE BOUNDS (70-100%)
          </span>
        </div>
      </div>

      {/* D3.js Mini Historical Performance Chart */}
      <div className="mb-6">
        <D3MiniChart confidence={signal.confidence} asset={signal.asset} />
      </div>

      {/* Backtest Historical Panel */}
      <div className="mb-6 bg-zinc-950 border border-zinc-850 p-4 rounded-lg">
        <div className="flex items-center justify-between gap-4">
          <div>
            <h3 className="text-xs font-mono font-bold text-zinc-400 uppercase tracking-wider flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full"></span>
              Historical Backtester
            </h3>
            <p className="text-[10px] text-zinc-500 mt-0.5 font-sans">Simulate setup over last 30 days using FinRL agent models.</p>
          </div>
          <button
            onClick={handleRunBacktest}
            disabled={backtestLoading}
            className="bg-emerald-950/60 hover:bg-emerald-900 text-emerald-400 font-bold text-[11px] px-3 py-1.5 rounded border border-emerald-900/40 transition-all disabled:opacity-50 cursor-pointer flex items-center gap-1.5 shrink-0"
          >
            {backtestLoading ? (
              <RefreshCw className="w-3 h-3 animate-spin" />
            ) : (
              <TrendingUp className="w-3 h-3" />
            )}
            <span>Backtest Historical</span>
          </button>
        </div>

        {showBacktest && (
          <div className="mt-4 border-t border-zinc-900 pt-4 flex flex-col gap-4">
            {backtestLoading ? (
              <div className="py-8 text-center flex flex-col items-center justify-center gap-2">
                <RefreshCw className="w-6 h-6 text-emerald-400 animate-spin" />
                <p className="text-xs text-zinc-400 font-mono">Running 30-day FinRL backtest and alpha optimization...</p>
              </div>
            ) : backtestData && backtestData.isLocked ? (
              <div className="bg-zinc-950 border border-zinc-850 p-6 rounded-lg text-center flex flex-col items-center gap-3">
                <div className="bg-emerald-950/40 border border-emerald-900/30 p-2.5 rounded-full text-emerald-400">
                  <Lock className="w-5 h-5 animate-pulse" />
                </div>
                <div className="text-xs font-bold text-zinc-200">Historical Backtester Gated</div>
                <p className="text-[10px] text-zinc-500 font-sans leading-relaxed max-w-xs">
                  SaaS backend returned a <code className="text-rose-400 font-mono font-bold">403 Forbidden</code> response. To access this high-fidelity 30-day quantitative FinRL backtest, please upgrade this tenant to the **Quant Pro** plan.
                </p>
                <button
                  onClick={() => upgradeTier("pro")}
                  className="bg-emerald-950 hover:bg-emerald-900 text-emerald-400 border border-emerald-900/40 text-[10px] px-3.5 py-1.5 rounded transition-all font-bold cursor-pointer"
                >
                  Upgrade to Quant Pro
                </button>
              </div>
            ) : backtestData ? (
              <>
                {/* Stats Grid */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 font-mono text-center">
                  <div className="bg-zinc-900 border border-zinc-850 p-2 rounded">
                    <span className="text-zinc-500 text-[8px] uppercase font-bold block">Net Profit</span>
                    <span className="text-emerald-400 font-extrabold text-xs mt-1 block">
                      +{backtestData.stats.netProfitPercent}%
                    </span>
                    <span className="text-[7px] text-zinc-500 block">vs {backtestData.stats.benchmarkProfitPercent}% BM</span>
                  </div>
                  <div className="bg-zinc-900 border border-zinc-850 p-2 rounded">
                    <span className="text-zinc-500 text-[8px] uppercase font-bold block">Win Rate</span>
                    <span className="text-zinc-300 font-extrabold text-xs mt-1 block">
                      {backtestData.stats.winRate}%
                    </span>
                    <span className="text-[7px] text-zinc-500 block">{backtestData.stats.totalTrades} trades</span>
                  </div>
                  <div className="bg-zinc-900 border border-zinc-850 p-2 rounded">
                    <span className="text-zinc-500 text-[8px] uppercase font-bold block">Profit Factor</span>
                    <span className="text-zinc-300 font-extrabold text-xs mt-1 block">
                      {backtestData.stats.profitFactor}
                    </span>
                    <span className="text-[7px] text-zinc-500 block">Gain / Loss</span>
                  </div>
                  <div className="bg-zinc-900 border border-zinc-850 p-2 rounded">
                    <span className="text-zinc-500 text-[8px] uppercase font-bold block">Drawdown</span>
                    <span className="text-rose-400 font-extrabold text-xs mt-1 block">
                      {backtestData.stats.maxDrawdownPercent}%
                    </span>
                    <span className="text-[7px] text-zinc-500 block">Risk limits ok</span>
                  </div>
                </div>

                {/* Simulated Equity Curve Line Chart */}
                <div className="h-32 bg-zinc-900 border border-zinc-850 p-2.5 rounded">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={backtestData.chartData}>
                      <defs>
                        <linearGradient id="backtestAreaColor" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#10b981" stopOpacity={0.25}/>
                          <stop offset="95%" stopColor="#10b981" stopOpacity={0.0}/>
                        </linearGradient>
                      </defs>
                      <XAxis dataKey="date" stroke="#52525b" fontSize={8} fontFamily="monospace" tickLine={false} />
                      <YAxis stroke="#52525b" fontSize={8} fontFamily="monospace" tickLine={false} domain={['auto', 'auto']} />
                      <Tooltip 
                        contentStyle={{ backgroundColor: "#09090b", borderColor: "#27272a", color: "#e4e4e7", fontSize: 9, fontFamily: "monospace" }}
                        formatter={(value) => [`$${Number(value).toLocaleString()}`, 'Portfolio']}
                      />
                      <CartesianGrid stroke="#18181b" strokeDasharray="3 3" />
                      <Area type="monotone" dataKey="portfolio" stroke="#10b981" fillOpacity={1} fill="url(#backtestAreaColor)" strokeWidth={1.5} name="FinRL Agent" />
                      <Area type="monotone" dataKey="benchmark" stroke="#71717a" fill="none" strokeDasharray="3 3" strokeWidth={1} name="Benchmark" />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </>
            ) : (
              <div className="text-center py-4 text-xs text-zinc-500 font-mono">
                Failed to run backtest simulation. Please retry.
              </div>
            )}
          </div>
        )}
      </div>

      {/* STEP 1: SENTIMENT GAUGE & NOTES */}
      {activeStep === 1 && (
        <div className="flex flex-col gap-5">
          <div className="flex items-center justify-between bg-zinc-950 border border-zinc-850 p-4 rounded-lg">
            <div>
              <p className="text-xs text-zinc-400 font-mono">FinRobot Multi-Agent Framework</p>
              <h3 className="text-sm font-bold text-zinc-200 mt-1">Macro Sentiment Gauge</h3>
            </div>
            <div className={`px-4 py-2 rounded font-bold font-mono text-sm border ${
              signal.macroSentiment === "BULLISH" 
                ? "bg-emerald-950/60 text-emerald-400 border-emerald-900/40"
                : signal.macroSentiment === "BEARISH"
                ? "bg-rose-950/60 text-rose-400 border-rose-900/40"
                : "bg-zinc-800 text-zinc-400 border-zinc-700"
            }`}>
              {signal.macroSentiment}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-zinc-950 border border-zinc-850 p-3.5 rounded-lg">
              <h4 className="text-xs font-bold text-zinc-300 flex items-center gap-1.5 mb-2 font-mono border-b border-zinc-850 pb-2">
                <span className="w-1.5 h-1.5 bg-blue-400 rounded-full"></span>
                Bank of England (BOE)
              </h4>
              <p className="text-xs text-zinc-400 leading-relaxed font-sans">
                {signal.centralBankNotes.boe}
              </p>
            </div>
            <div className="bg-zinc-950 border border-zinc-850 p-3.5 rounded-lg">
              <h4 className="text-xs font-bold text-zinc-300 flex items-center gap-1.5 mb-2 font-mono border-b border-zinc-850 pb-2">
                <span className="w-1.5 h-1.5 bg-rose-400 rounded-full"></span>
                Bank of Japan (BOJ)
              </h4>
              <p className="text-xs text-zinc-400 leading-relaxed font-sans">
                {signal.centralBankNotes.boj}
              </p>
            </div>
            <div className="bg-zinc-950 border border-zinc-850 p-3.5 rounded-lg">
              <h4 className="text-xs font-bold text-zinc-300 flex items-center gap-1.5 mb-2 font-mono border-b border-zinc-850 pb-2">
                <span className="w-1.5 h-1.5 bg-amber-400 rounded-full"></span>
                South African Reserve Bank (SARB)
              </h4>
              <p className="text-xs text-zinc-400 leading-relaxed font-sans">
                {signal.centralBankNotes.sarb}
              </p>
            </div>
            <div className="bg-zinc-950 border border-zinc-850 p-3.5 rounded-lg">
              <h4 className="text-xs font-bold text-zinc-300 flex items-center gap-1.5 mb-2 font-mono border-b border-zinc-850 pb-2">
                <span className="w-1.5 h-1.5 bg-emerald-400 rounded-full"></span>
                Federal Reserve (FED)
              </h4>
              <p className="text-xs text-zinc-400 leading-relaxed font-sans">
                {signal.centralBankNotes.fed}
              </p>
            </div>
          </div>
          
          {/* Real-time Sentiment News Sub-component */}
          <RealTimeSentimentNews signal={signal} />
        </div>
      )}

      {/* STEP 2: CORRELATION ANALYSIS */}
      {activeStep === 2 && (
        !isFeatureUnlocked("correlation") ? (
          <div className="flex flex-col items-center text-center p-8 bg-zinc-950 border border-zinc-850 rounded-lg gap-4 select-none">
            <div className="bg-emerald-950/40 border border-emerald-900/30 p-4 rounded-full text-emerald-400">
              <Lock className="w-8 h-8 animate-pulse" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-zinc-200">Inter-market Correlation Gated</h3>
              <p className="text-xs text-zinc-400 mt-2 max-w-sm leading-relaxed font-sans">
                Access to live cross-commodity currency overlay matrices is restricted to **Quant Pro** and **Sovereign Apex** subscribers. Upgrade this tenant to analyze USD/ZAR inverse commodity dependencies automatically.
              </p>
            </div>
            <button
              onClick={() => upgradeTier("pro")}
              className="bg-emerald-950 hover:bg-emerald-900 text-emerald-400 border border-emerald-900/40 font-bold text-xs px-4 py-2 rounded transition-all cursor-pointer"
            >
              Upgrade Tenant to Quant Pro
            </button>
          </div>
        ) : (
          <div className="flex flex-col gap-4">
            <div className="bg-zinc-950 border border-zinc-850 p-4 rounded-lg">
              <h3 className="text-sm font-bold text-zinc-200">Inter-market Commodity Correlation</h3>
              <p className="text-xs text-zinc-400 mt-1">
                Cross-asset overlay: {signal.asset} and gold fluctuations over the last 18 hours.
              </p>
            </div>

            {/* Conditional Warning Trigger */}
            {hasCorrelationWarning && (
              <div className="bg-rose-950/40 border border-rose-900/40 p-4 rounded-lg flex items-start gap-3.5">
                <AlertTriangle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5 animate-pulse" />
                <div>
                  <h4 className="text-xs font-bold text-rose-400 uppercase tracking-wide">🚨 INVERSE CORRELATION DETECTED</h4>
                  <p className="text-xs text-rose-300 leading-relaxed mt-1">
                    USD/ZAR usually holds a strong **inverse correlation** with Gold. Physical commodity surges strengthen the South African Rand (ZAR), prompting a downwards drop in USD/ZAR rates. 
                    Executing a **BUY (Long)** position on USD/ZAR while Gold is trending bullishly runs contrary to fundamental correlation logic. Exercise extreme caution.
                  </p>
                </div>
              </div>
            )}

            {!hasCorrelationWarning && (
              <div className="bg-zinc-950 border border-zinc-850 p-4 rounded-lg flex items-start gap-3 text-zinc-400 text-xs leading-relaxed">
                <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                <div>
                  <span className="font-semibold text-zinc-200">Correlation Logic Validated:</span> No inverse cross-market contradictions detected for this {signal.asset} signal. The asset movement aligns comfortably with its standard macro anchors.
                </div>
              </div>
            )}

            {/* Correlation Chart */}
            {signal.correlationChart && (
              <div className="bg-zinc-950 border border-zinc-850 p-4 rounded-lg h-60">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={signal.correlationChart}>
                    <XAxis dataKey="time" stroke="#71717a" fontSize={10} fontFamily="monospace" />
                    <YAxis yAxisId="left" stroke="#10b981" fontSize={10} fontFamily="monospace" label={{ value: `${signal.asset}`, angle: -90, position: 'insideLeft', style: { fill: '#10b981', fontSize: 10 } }} />
                    <YAxis yAxisId="right" orientation="right" stroke="#f59e0b" fontSize={10} fontFamily="monospace" label={{ value: 'Gold (XAU/USD)', angle: 90, position: 'insideRight', style: { fill: '#f59e0b', fontSize: 10 } }} />
                    <Tooltip 
                      contentStyle={{ backgroundColor: "#09090b", borderColor: "#27272a", color: "#e4e4e7", fontSize: 11, fontFamily: "monospace" }}
                    />
                    <CartesianGrid stroke="#27272a" strokeDasharray="3 3" />
                    <Line yAxisId="left" type="monotone" dataKey="assetPrice" stroke="#10b981" strokeWidth={2} dot={false} name={signal.asset} />
                    <Line yAxisId="right" type="monotone" dataKey="correlPrice" stroke="#f59e0b" strokeWidth={2} dot={false} name="Gold Price" />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            )}

            {!signal.correlationChart && (
              <div className="bg-zinc-950 border border-zinc-850 p-8 rounded-lg text-center text-xs text-zinc-500 font-mono">
                Correlation tool is fully active for USD/ZAR exotic cross. GBP/JPY, Gold and Cryptos do not require the commodity gold hedge layout.
              </div>
            )}
          </div>
        )
      )}

      {/* STEP 3: PROBABILITY BOUNDARY HEATMAP */}
      {activeStep === 3 && (
        <div className="flex flex-col gap-4">
          <div className="bg-zinc-950 border border-zinc-850 p-4 rounded-lg flex flex-col md:flex-row md:items-center justify-between gap-3">
            <div>
              <h3 className="text-sm font-bold text-zinc-200">FinRL Mathematical Reversal Boundaries</h3>
              <p className="text-xs text-zinc-400 mt-1">
                Gaussian distribution curve plotting standard deviation confidence bands and price boundaries.
              </p>
            </div>
            <div className="bg-emerald-950/60 border border-emerald-900/40 text-emerald-400 px-3.5 py-1.5 rounded text-xs font-mono font-bold">
              Success probability: {signal.probabilityBands.currentProb}%
            </div>
          </div>

          <div className="bg-zinc-950 border border-zinc-850 p-4 rounded-lg h-60">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={signal.probabilityBands.heatmapData}>
                <defs>
                  <linearGradient id="probColor" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.4}/>
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0.0}/>
                  </linearGradient>
                </defs>
                <XAxis dataKey="price" stroke="#71717a" fontSize={10} fontFamily="monospace" />
                <YAxis stroke="#71717a" fontSize={10} fontFamily="monospace" hide />
                <Tooltip 
                  contentStyle={{ backgroundColor: "#09090b", borderColor: "#27272a", color: "#e4e4e7", fontSize: 11, fontFamily: "monospace" }}
                  formatter={(value) => [`${(Number(value) * 100).toFixed(1)}%`, 'Probability Intensity']}
                />
                <CartesianGrid stroke="#27272a" strokeDasharray="2 2" />
                <Area type="monotone" dataKey="probability" stroke="#10b981" fillOpacity={1} fill="url(#probColor)" strokeWidth={2} />
                
                {/* Reference line showing current signal price placement */}
                <ReferenceLine 
                  x={signal.price} 
                  stroke="#ef4444" 
                  strokeDasharray="4 4" 
                  label={{ value: 'Entry', fill: '#ef4444', fontSize: 9, position: 'top', fontFamily: 'monospace' }} 
                />
                <ReferenceLine 
                  x={signal.stopLoss} 
                  stroke="#991b1b" 
                  label={{ value: 'SL Limit', fill: '#991b1b', fontSize: 9, position: 'top', fontFamily: 'monospace' }} 
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>

          <div className="grid grid-cols-3 gap-3 font-mono text-xs">
            <div className="bg-zinc-950 border border-zinc-850 p-3 rounded text-center">
              <span className="text-zinc-500 uppercase block text-[10px] tracking-wide font-semibold">Lower Channel</span>
              <span className="text-zinc-300 font-bold mt-1 block">
                {signal.probabilityBands.lower.toLocaleString(undefined, { minimumFractionDigits: isZAR ? 4 : 2 })}
              </span>
            </div>
            <div className="bg-zinc-950 border border-zinc-850 p-3 rounded text-center">
              <span className="text-zinc-500 uppercase block text-[10px] tracking-wide font-semibold">Channel Mean</span>
              <span className="text-zinc-300 font-bold mt-1 block">
                {signal.probabilityBands.mean.toLocaleString(undefined, { minimumFractionDigits: isZAR ? 4 : 2 })}
              </span>
            </div>
            <div className="bg-zinc-950 border border-zinc-850 p-3 rounded text-center">
              <span className="text-zinc-500 uppercase block text-[10px] tracking-wide font-semibold">Upper Channel</span>
              <span className="text-zinc-300 font-bold mt-1 block">
                {signal.probabilityBands.upper.toLocaleString(undefined, { minimumFractionDigits: isZAR ? 4 : 2 })}
              </span>
            </div>
          </div>
        </div>
      )}

      {/* STEP 4: RISK CALCULATOR */}
      {activeStep === 4 && (
        <div className="flex flex-col gap-4">
          <div className="bg-zinc-950 border border-zinc-850 p-4 rounded-lg">
            <h3 className="text-sm font-bold text-zinc-200">1.5% Strict Account Risk Calculator</h3>
            <p className="text-xs text-zinc-400 mt-1">
              Position size scales dynamically to protect capital. Maximum risk is locked at exactly 1.5% and cannot be altered.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-zinc-950 border border-zinc-850 p-4 rounded-lg flex flex-col justify-between">
              <div>
                <label className="text-xs text-zinc-400 font-mono font-bold block mb-2 uppercase">
                  Account Balance ($ USD)
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-2.5 text-zinc-500 text-sm font-mono font-semibold">$</span>
                  <input
                    type="number"
                    value={balanceInput}
                    onChange={(e) => setBalanceInput(e.target.value)}
                    className="w-full bg-zinc-900 border border-zinc-800 focus:border-emerald-500 rounded p-2 pl-7 text-sm font-mono text-zinc-100 outline-none transition-all"
                    placeholder="Enter total balance"
                  />
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-zinc-900 flex items-center justify-between text-xs font-mono">
                <span className="text-zinc-500">Locked Risk Percent:</span>
                <span className="text-emerald-400 font-bold">1.5% Max</span>
              </div>
            </div>

            <div className="bg-zinc-950 border border-zinc-850 p-4 rounded-lg font-mono text-xs flex flex-col justify-between gap-2.5">
              <div className="flex justify-between items-center">
                <span className="text-zinc-400">Entry Price:</span>
                <span className="text-zinc-100 font-semibold">{signal.price.toLocaleString(undefined, { minimumFractionDigits: isZAR ? 4 : 2 })}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-zinc-400">Stop Loss Target:</span>
                <span className="text-rose-400 font-semibold">{signal.stopLoss.toLocaleString(undefined, { minimumFractionDigits: isZAR ? 4 : 2 })}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-zinc-400">Capital At Risk:</span>
                <span className="text-rose-400 font-bold">${verification.riskAmount.toLocaleString()} USD</span>
              </div>
              <div className="flex justify-between items-center border-t border-zinc-900 pt-2.5">
                <span className="text-zinc-400">Distance to SL:</span>
                <span className="text-zinc-200 font-semibold">{verification.pipsRisked} {pipUnitLabel}</span>
              </div>
              <div className="flex justify-between items-center bg-zinc-900/60 p-2.5 rounded border border-zinc-800 mt-1">
                <span className="text-emerald-400 font-bold uppercase text-[10px]">Recommended Size:</span>
                <span className="text-emerald-400 font-extrabold text-sm">
                  {verification.calculatedPositionSize} {isCrypto ? "Coins" : isGold ? "Ounces" : "Lots"}
                </span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Expand / Close Toggle Button for active step verification check */}
      <div className="mt-6 pt-5 border-t border-zinc-800 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-2">
          <button 
            onClick={() => toggleStep(activeStep)}
            className="text-zinc-400 hover:text-emerald-400 transition-colors focus:outline-none cursor-pointer"
          >
            {steps[activeStep - 1].checked ? (
              <CheckSquare className="w-5 h-5 text-emerald-500 fill-emerald-500/10" />
            ) : (
              <Square className="w-5 h-5 text-zinc-600" />
            )}
          </button>
          <span className="text-xs text-zinc-300 font-semibold">
            I have completed step {activeStep} verification analysis
          </span>
        </div>

        <div className="flex gap-2 w-full sm:w-auto">
          {activeStep < 4 ? (
            <button
              onClick={() => {
                toggleStep(activeStep);
                setActiveStep(activeStep + 1);
              }}
              className="w-full sm:w-auto bg-zinc-800 hover:bg-zinc-700 active:bg-zinc-900 text-zinc-200 font-bold text-xs px-4 py-2 rounded flex items-center justify-center gap-1.5 transition-all border border-zinc-700 cursor-pointer"
            >
              <span>Next Metric</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          ) : (
            <button
              onClick={() => toggleStep(4)}
              className="w-full sm:w-auto bg-emerald-950/80 hover:bg-emerald-900 text-emerald-400 font-bold text-xs px-4 py-2 rounded flex items-center justify-center gap-1.5 transition-all border border-emerald-900/40 cursor-pointer"
            >
              <span>Verify Risk Calculator</span>
              <ShieldCheck className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
