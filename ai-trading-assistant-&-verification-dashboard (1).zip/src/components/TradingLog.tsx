import React, { useState, useEffect } from "react";
import { useSubscription } from "../SubscriptionContext";
import { 
  History, 
  Trash2, 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  AlertCircle,
  CheckCircle,
  FileText,
  Lock,
  LineChart as LineChartIcon
} from "lucide-react";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ReferenceLine
} from "recharts";

export interface TradingLogEntry {
  id: string;
  asset: string;
  action: 'BUY' | 'SELL';
  entryPrice: number;
  exitPricePlaceholder: string;
  timestamp: string;
  positionSize: number;
  riskAmount: number;
  exitPrice?: number;
  notes?: string;
}

interface TradingLogProps {
  entries: TradingLogEntry[];
  onUpdateExitPrice: (id: string, exitPrice: number) => void;
  onUpdateNotes?: (id: string, notes: string) => void;
  onClearLog: () => void;
}

const CustomTooltip = ({ active, payload }: any) => {
  if (active && payload && payload.length) {
    const data = payload[0].payload;
    if (data.tradeNumber === 0) {
      return (
        <div className="bg-zinc-950 border border-zinc-800 p-2.5 rounded shadow-xl font-mono text-[10px] select-none text-zinc-400">
          Baseline (Starting Point)
        </div>
      );
    }
    const isProfit = data.pnl >= 0;
    return (
      <div className="bg-zinc-950 border border-zinc-800 p-2.5 rounded shadow-xl font-mono text-[10px] select-none flex flex-col gap-1">
        <p className="text-zinc-400 font-sans font-bold uppercase tracking-wide">
          Trade #{data.tradeNumber}: {data.asset}
        </p>
        <p className="text-zinc-300">
          Trade P&L: <span className={isProfit ? "text-emerald-400 font-bold" : "text-rose-400 font-bold"}>
            {isProfit ? "+" : ""}${data.pnl.toFixed(2)}
          </span>
        </p>
        <p className="text-zinc-300 border-t border-zinc-900 pt-1 mt-0.5">
          Cumulative: <span className={data.cumulativePnL >= 0 ? "text-emerald-400 font-bold" : "text-rose-400 font-bold"}>
            {data.cumulativePnL >= 0 ? "+" : ""}${data.cumulativePnL.toFixed(2)}
          </span>
        </p>
        {data.timestamp && <p className="text-zinc-500 text-[8px] mt-0.5">{data.timestamp}</p>}
      </div>
    );
  }
  return null;
};

export default function TradingLog({ entries, onUpdateExitPrice, onUpdateNotes, onClearLog }: TradingLogProps) {
  const { isFeatureUnlocked, upgradeTier } = useSubscription();
  const [exitInputs, setExitInputs] = useState<Record<string, string>>({});
  const [notesInputs, setNotesInputs] = useState<Record<string, string>>({});

  const handleSaveNotes = (id: string) => {
    const notesVal = notesInputs[id];
    if (notesVal !== undefined && onUpdateNotes) {
      onUpdateNotes(id, notesVal);
    }
  };

  const handleSaveExit = (id: string, entryPrice: number, action: 'BUY' | 'SELL') => {
    const val = exitInputs[id];
    if (!val) return;
    const num = parseFloat(val);
    if (!isNaN(num)) {
      onUpdateExitPrice(id, num);
    }
  };

  const calculatePnL = (entry: TradingLogEntry) => {
    if (entry.exitPrice === undefined) return null;
    const isBuy = entry.action === "BUY";
    const diff = isBuy ? (entry.exitPrice - entry.entryPrice) : (entry.entryPrice - entry.exitPrice);
    
    // For forex exotics (USDZAR, GBPJPY), let's calculate standard PnL or standard unit point return
    let multiplier = 1;
    if (entry.asset.includes("JPY")) {
      multiplier = 100;
    } else if (entry.asset === "USD/ZAR") {
      multiplier = 10000;
    }
    
    // Return standard dollar return or simulated relative gain
    const pointsGained = diff * multiplier;
    // rough PnL simulation based on risk size
    const profitFactor = pointsGained / (entry.entryPrice * 0.01); 
    const pnlDollars = entry.riskAmount * (pointsGained / 20); // estimate based on pips risked
    return {
      points: Number(pointsGained.toFixed(1)),
      dollars: Number(pnlDollars.toFixed(2)),
      isProfit: diff > 0
    };
  };

  const completedEntries = [...entries]
    .filter((e) => e.exitPrice !== undefined)
    .sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());

  const chartData = [{
    tradeNumber: 0,
    cumulativePnL: 0,
    asset: "Start",
    pnl: 0,
    timestamp: ""
  }];

  let cumulativeSum = 0;
  completedEntries.forEach((entry, index) => {
    const pnl = calculatePnL(entry);
    if (pnl) {
      cumulativeSum += pnl.dollars;
      chartData.push({
        tradeNumber: index + 1,
        cumulativePnL: Number(cumulativeSum.toFixed(2)),
        asset: entry.asset,
        pnl: pnl.dollars,
        timestamp: new Date(entry.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      });
    }
  });

  return (
    <div id="trading-log-panel" className="bg-zinc-900 border border-zinc-850 rounded-lg p-5 font-sans shadow-lg flex flex-col gap-4">
      <div className="flex items-center justify-between border-b border-zinc-800 pb-3.5">
        <div className="flex items-center gap-2">
          <History className="w-5 h-5 text-emerald-400" />
          <h2 className="text-sm font-bold tracking-wider text-zinc-100 uppercase">Live Trading Log</h2>
        </div>
        {entries.length > 0 && (
          <button
            onClick={onClearLog}
            className="text-[10px] font-mono uppercase bg-rose-950/40 hover:bg-rose-900/60 text-rose-400 px-2 py-1 rounded border border-rose-900/30 flex items-center gap-1 transition-colors cursor-pointer"
          >
            <Trash2 className="w-3 h-3" />
            Clear Log
          </button>
        )}
      </div>

      {entries.length > 0 && (
        <div className="bg-zinc-950/40 border border-zinc-850 p-4 rounded-lg flex flex-col gap-3">
          <div className="flex items-center justify-between">
            <div>
              <span className="text-[10px] font-mono text-zinc-500 uppercase font-bold tracking-wider block">Performance Metrics</span>
              <h3 className="text-xs font-bold text-zinc-300 font-sans mt-0.5">Cumulative P&L Curve (Streak Blocker Efficacy)</h3>
            </div>
            <div className="text-right font-mono text-[10px] flex flex-col items-end">
              <span className="text-zinc-500 uppercase font-bold tracking-wider">Net Return</span>
              <span className={`block font-extrabold text-xs sm:text-sm ${cumulativeSum >= 0 ? "text-emerald-400" : "text-rose-400"}`}>
                {cumulativeSum >= 0 ? "+" : ""}${cumulativeSum.toFixed(2)}
              </span>
            </div>
          </div>

          {completedEntries.length === 0 ? (
            <div className="h-28 border border-zinc-850 border-dashed rounded flex flex-col items-center justify-center p-4 bg-zinc-950/20 text-center">
              <LineChartIcon className="w-5 h-5 text-zinc-600 mb-1" />
              <p className="text-[10px] text-zinc-500 font-mono">
                P&L Curve will plot here once you close at least one trade with an Exit Price in the table below.
              </p>
            </div>
          ) : (
            <div className="h-36 w-full font-mono text-xs select-none">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={chartData} margin={{ top: 10, right: 10, left: -25, bottom: 0 }}>
                  <CartesianGrid stroke="#1f1f23" strokeDasharray="3 3" />
                  <XAxis 
                    dataKey="tradeNumber" 
                    stroke="#52525b" 
                    fontSize={9} 
                    tickLine={false} 
                    axisLine={false}
                    tickFormatter={(val) => `T#${val}`}
                  />
                  <YAxis 
                    stroke="#52525b" 
                    fontSize={9} 
                    tickLine={false} 
                    axisLine={false}
                    tickFormatter={(val) => `$${val}`}
                  />
                  <Tooltip content={<CustomTooltip />} />
                  <ReferenceLine y={0} stroke="#3f3f46" strokeWidth={1} strokeDasharray="3 3" />
                  <Line 
                    type="monotone" 
                    dataKey="cumulativePnL" 
                    stroke={cumulativeSum >= 0 ? "#10b981" : "#f43f5e"} 
                    strokeWidth={2} 
                    dot={{ r: 4, strokeWidth: 1.5, fill: "#09090b" }} 
                    activeDot={{ r: 6 }} 
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          )}
        </div>
      )}

      {entries.length === 0 ? (
        <div className="bg-zinc-950 border border-zinc-850 p-8 rounded-lg text-center flex flex-col items-center justify-center gap-2">
          <FileText className="w-8 h-8 text-zinc-600" />
          <p className="text-xs text-zinc-400 font-mono">No trades logged yet.</p>
          <p className="text-[10px] text-zinc-500 max-w-xs leading-relaxed font-sans mt-1">
            Complete the 4-step checklist verification and click the copy execution data button inside the Confirmation Sandbox to automatically log a trade.
          </p>
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse font-mono text-xs">
            <thead>
              <tr className="border-b border-zinc-800 text-zinc-500 text-[10px] uppercase font-bold tracking-wider">
                <th className="pb-2.5">Asset</th>
                <th className="pb-2.5">Action</th>
                <th className="pb-2.5">Entry Price</th>
                <th className="pb-2.5">Exit Price</th>
                <th className="pb-2.5 max-w-[200px]">Trader Sentiment / Notes</th>
                <th className="pb-2.5 text-right">Performance PnL</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-850">
              {entries.map((entry) => {
                const pnl = calculatePnL(entry);
                const isJPY = entry.asset.includes("JPY");
                const isZAR = entry.asset === "USD/ZAR";
                const precision = isZAR ? 4 : isJPY ? 2 : 2;

                return (
                  <tr key={entry.id} className="hover:bg-zinc-900/40 transition-colors">
                    <td className="py-3">
                      <span className="font-bold text-zinc-200 block">{entry.asset}</span>
                      <span className="text-[9px] text-zinc-500 font-sans block mt-0.5">
                        {new Date(entry.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </td>
                    <td className="py-3">
                      <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-extrabold ${
                        entry.action === "BUY" ? "bg-emerald-950/60 text-emerald-400 border border-emerald-900/30" : "bg-rose-950/60 text-rose-400 border border-rose-900/30"
                      }`}>
                        {entry.action}
                      </span>
                    </td>
                    <td className="py-3 text-zinc-300 font-semibold">
                      {entry.entryPrice.toLocaleString(undefined, { minimumFractionDigits: precision })}
                    </td>
                    <td className="py-3">
                      {!isFeatureUnlocked("review") ? (
                        <div className="flex items-center gap-1 text-zinc-600 text-[10px] select-none">
                           <Lock className="w-3 h-3 text-zinc-700 shrink-0" />
                          <span>Gated (Pro)</span>
                        </div>
                      ) : entry.exitPrice !== undefined ? (
                        <div className="flex items-center gap-1.5">
                          <span className="text-zinc-200 font-semibold">
                            {entry.exitPrice.toLocaleString(undefined, { minimumFractionDigits: precision })}
                          </span>
                          <button 
                            onClick={() => {
                              onUpdateExitPrice(entry.id, undefined as any);
                            }}
                            className="text-[9px] text-zinc-500 hover:text-zinc-400 underline font-sans ml-1"
                          >
                            Edit
                          </button>
                        </div>
                      ) : (
                        <div className="flex items-center gap-1.5 max-w-[140px]">
                          <input
                            type="number"
                            step="any"
                            placeholder={entry.exitPricePlaceholder}
                            value={exitInputs[entry.id] || ""}
                            onChange={(e) => setExitInputs(prev => ({ ...prev, [entry.id]: e.target.value }))}
                            className="w-20 bg-zinc-950 border border-zinc-800 rounded px-1.5 py-0.5 text-zinc-300 outline-none focus:border-emerald-500 text-[10px] font-mono"
                          />
                          <button
                            onClick={() => handleSaveExit(entry.id, entry.entryPrice, entry.action)}
                            className="bg-emerald-950/60 hover:bg-emerald-900 text-emerald-400 px-1.5 py-0.5 rounded border border-emerald-900/30 text-[10px] font-bold"
                          >
                            Set
                          </button>
                        </div>
                      )}
                    </td>
                    <td className="py-3">
                      {entry.exitPrice !== undefined ? (
                        <div className="flex items-center gap-1.5">
                          <input
                            type="text"
                            placeholder="Add trader sentiment / notes..."
                            value={notesInputs[entry.id] ?? entry.notes ?? ""}
                            onChange={(e) => {
                              const val = e.target.value;
                              setNotesInputs(prev => ({ ...prev, [entry.id]: val }));
                            }}
                            onBlur={() => handleSaveNotes(entry.id)}
                            onKeyDown={(e) => {
                              if (e.key === "Enter") {
                                handleSaveNotes(entry.id);
                              }
                            }}
                            className="w-full max-w-[200px] bg-zinc-950 border border-zinc-800 focus:border-emerald-500/50 rounded px-2 py-1 text-zinc-300 text-[10px] outline-none transition-all font-sans"
                          />
                        </div>
                      ) : (
                        <span className="text-zinc-600 text-[10px] italic">Locked until exit...</span>
                      )}
                    </td>
                    <td className="py-3 text-right">
                      {!isFeatureUnlocked("review") ? (
                        <div className="flex flex-col items-end gap-0.5 select-none cursor-pointer" onClick={() => upgradeTier("pro")}>
                          <span className="text-[10px] font-extrabold text-zinc-600 flex items-center gap-1">
                            <Lock className="w-3 h-3 text-zinc-700" />
                            Gated
                          </span>
                          <span className="text-[8px] text-emerald-500 font-sans block underline hover:text-emerald-400">Upgrade</span>
                        </div>
                      ) : pnl ? (
                        <div>
                          <span className={`font-bold block ${pnl.isProfit ? "text-emerald-400" : "text-rose-400"}`}>
                            {pnl.isProfit ? "+" : ""}{pnl.dollars >= 0 ? `$${pnl.dollars}` : `-$${Math.abs(pnl.dollars)}`}
                          </span>
                          <span className="text-[9px] text-zinc-500 block mt-0.5">
                            {pnl.points >= 0 ? `+${pnl.points}` : pnl.points} points
                          </span>
                        </div>
                      ) : (
                        <span className="text-zinc-500 text-[10px] italic">Pending exit...</span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
