import React, { useRef, useEffect, useState } from "react";
import * as d3 from "d3";
import { MarketQuote } from "../types";
import { Grid, ShieldAlert, ShieldCheck, HelpCircle } from "lucide-react";

interface CorrelationMatrixProps {
  quotes: MarketQuote[];
}

interface CorrelationCell {
  assetA: string;
  assetB: string;
  correlation: number;
}

const ASSETS = ["GBP/JPY", "USD/ZAR", "Gold (XAU/USD)", "Bitcoin", "Ethereum"];

const getQuoteSymbol = (asset: string): string => {
  if (asset === "GBP/JPY") return "GBPJPY=X";
  if (asset === "USD/ZAR") return "USDZAR=X";
  if (asset.includes("Gold")) return "GC=F";
  if (asset === "Bitcoin") return "BTC-USD";
  if (asset === "Ethereum") return "ETH-USD";
  return asset;
};

// Stable rolling correlation baselines (seeded historically)
const BASELINE_CORRELATIONS: Record<string, Record<string, number>> = {
  "GBP/JPY": {
    "GBP/JPY": 1.0,
    "USD/ZAR": -0.25,
    "Gold (XAU/USD)": -0.45,
    "Bitcoin": 0.35,
    "Ethereum": 0.30,
  },
  "USD/ZAR": {
    "GBP/JPY": -0.25,
    "USD/ZAR": 1.0,
    "Gold (XAU/USD)": -0.55,
    "Bitcoin": -0.15,
    "Ethereum": -0.12,
  },
  "Gold (XAU/USD)": {
    "GBP/JPY": -0.45,
    "USD/ZAR": -0.55,
    "Gold (XAU/USD)": 1.0,
    "Bitcoin": 0.20,
    "Ethereum": 0.15,
  },
  "Bitcoin": {
    "GBP/JPY": 0.35,
    "USD/ZAR": -0.15,
    "Gold (XAU/USD)": 0.20,
    "Bitcoin": 1.0,
    "Ethereum": 0.82,
  },
  "Ethereum": {
    "GBP/JPY": 0.30,
    "USD/ZAR": -0.12,
    "Gold (XAU/USD)": 0.15,
    "Bitcoin": 0.82,
    "Ethereum": 1.0,
  }
};

export default function CorrelationMatrix({ quotes }: CorrelationMatrixProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const svgRef = useRef<SVGSVGElement>(null);
  const [dimensions, setDimensions] = useState({ width: 500, height: 320 });
  const [hoveredCell, setHoveredCell] = useState<CorrelationCell | null>(null);
  const [tooltipPos, setTooltipPos] = useState({ x: 0, y: 0 });

  // Maintain sliding window price buffers for real-time statistical Pearson calculations
  const [priceHistory, setPriceHistory] = useState<Record<string, number[]>>({
    "GBPJPY=X": [],
    "USDZAR=X": [],
    "GC=F": [],
    "BTC-USD": [],
    "ETH-USD": []
  });

  // Track dynamic window points
  const [sampleCount, setSampleCount] = useState(0);

  // 1. Observe parent container size for full responsiveness
  useEffect(() => {
    if (!containerRef.current) return;

    const resizeObserver = new ResizeObserver((entries) => {
      if (!entries || entries.length === 0) return;
      const { width } = entries[0].contentRect;
      setDimensions({
        width: Math.max(280, width),
        height: Math.min(360, Math.max(260, width * 0.6))
      });
    });

    resizeObserver.observe(containerRef.current);
    return () => resizeObserver.disconnect();
  }, []);

  // 2. Synchronize new price ticks to our rolling buffer
  useEffect(() => {
    if (!quotes || quotes.length === 0) return;

    const currentSnapshot: Record<string, number> = {};
    let isComplete = true;

    for (const asset of ASSETS) {
      const sym = getQuoteSymbol(asset);
      const q = quotes.find((quote) => quote.symbol === sym);
      if (q && typeof q.price === "number" && q.price > 0) {
        currentSnapshot[sym] = q.price;
      } else {
        isComplete = false;
      }
    }

    if (!isComplete) return;

    setPriceHistory((prev) => {
      const updated = { ...prev };
      let anyChanged = false;

      for (const sym of Object.keys(updated)) {
        const prices = updated[sym];
        const latestPrice = currentSnapshot[sym];
        const prevPrice = prices[prices.length - 1];

        // Trigger updates if values shift
        if (prices.length === 0 || prevPrice !== latestPrice) {
          anyChanged = true;
          updated[sym] = [...prices, latestPrice].slice(-25); // Cache last 25 ticks
        }
      }

      if (anyChanged) {
        setSampleCount((c) => Math.min(25, c + 1));
      }
      return updated;
    });
  }, [quotes]);

  // Pearson Correlation Coefficient calculation
  const calcPearson = (x: number[], y: number[]): number => {
    const n = Math.min(x.length, y.length);
    if (n < 2) return 0;

    let sumX = 0, sumY = 0, sumXY = 0, sumXX = 0, sumYY = 0;
    for (let i = 0; i < n; i++) {
      sumX += x[i];
      sumY += y[i];
      sumXY += x[i] * y[i];
      sumXX += x[i] * x[i];
      sumYY += y[i] * y[i];
    }

    const numerator = n * sumXY - sumX * sumY;
    const denominator = Math.sqrt((n * sumXX - sumX * sumX) * (n * sumYY - sumY * sumY));

    if (denominator === 0) return 0;
    return numerator / denominator;
  };

  // Get correlation: Blend the real-time calculated coefficients with seeded financial baselines
  const getCorrelation = (assetA: string, assetB: string): number => {
    if (assetA === assetB) return 1.0;

    const symA = getQuoteSymbol(assetA);
    const symB = getQuoteSymbol(assetB);

    const histA = priceHistory[symA] || [];
    const histB = priceHistory[symB] || [];

    const baseline = BASELINE_CORRELATIONS[assetA]?.[assetB] ?? 0.0;
    const commonLength = Math.min(histA.length, histB.length);

    if (commonLength < 5) {
      return baseline;
    }

    const calculated = calcPearson(histA, histB);
    // Slowly blend the computed value in as we gather samples (up to 40% computed weighting for stability)
    const blendWeight = Math.min(0.4, (commonLength - 5) * 0.02);
    return baseline * (1 - blendWeight) + calculated * blendWeight;
  };

  // Build matrix data array
  const matrixData: CorrelationCell[] = [];
  ASSETS.forEach((assetA) => {
    ASSETS.forEach((assetB) => {
      matrixData.push({
        assetA,
        assetB,
        correlation: getCorrelation(assetA, assetB),
      });
    });
  });

  // 3. Draw the interactive matrix with D3
  useEffect(() => {
    if (!svgRef.current || matrixData.length === 0) return;

    const svg = d3.select(svgRef.current);
    svg.selectAll("*").remove(); // Wipe clean

    const margin = { top: 45, right: 15, bottom: 15, left: 95 };
    const innerWidth = dimensions.width - margin.left - margin.right;
    const innerHeight = dimensions.height - margin.top - margin.bottom;

    const g = svg.append("g")
      .attr("transform", `translate(${margin.left}, ${margin.top})`);

    const xScale = d3.scaleBand()
      .domain(ASSETS)
      .range([0, innerWidth])
      .padding(0.05);

    const yScale = d3.scaleBand()
      .domain(ASSETS)
      .range([0, innerHeight])
      .padding(0.05);

    // Color interpolation: Red (-1.0) -> Zinc Gray (0) -> Emerald Green (+1.0)
    const getColor = (val: number) => {
      if (val >= 0) {
        // Map [0, 1] to Zinc Background -> Bright Green
        return d3.interpolateRgb("#18181b", "#10b981")(val);
      } else {
        // Map [-1, 0] to Red -> Zinc Background
        return d3.interpolateRgb("#f43f5e", "#18181b")(val + 1);
      }
    };

    // Draw grid rects
    g.selectAll(".matrix-cell")
      .data(matrixData)
      .enter()
      .append("rect")
      .attr("class", "matrix-cell")
      .attr("x", d => xScale(d.assetA) || 0)
      .attr("y", d => yScale(d.assetB) || 0)
      .attr("width", xScale.bandwidth())
      .attr("height", yScale.bandwidth())
      .attr("rx", 3)
      .attr("ry", 3)
      .style("fill", d => getColor(d.correlation))
      .style("stroke", "#27272a")
      .style("stroke-width", 1)
      .style("cursor", "pointer")
      .on("mouseenter", function (event, d) {
        d3.select(this)
          .style("stroke", "#a1a1aa")
          .style("stroke-width", 1.5);

        // Position tooltip
        const [mx, my] = d3.pointer(event, svgRef.current);
        setTooltipPos({ x: mx + 15, y: my + 15 });
        setHoveredCell(d);
      })
      .on("mousemove", function (event) {
        const [mx, my] = d3.pointer(event, svgRef.current);
        setTooltipPos({ x: mx + 15, y: my + 15 });
      })
      .on("mouseleave", function () {
        d3.select(this)
          .style("stroke", "#27272a")
          .style("stroke-width", 1);
        setHoveredCell(null);
      });

    // Add labels centered inside cells
    // Only display correlation coefficients if bandwidth is large enough
    if (xScale.bandwidth() > 40) {
      g.selectAll(".cell-text")
        .data(matrixData)
        .enter()
        .append("text")
        .attr("class", "cell-text")
        .attr("x", d => (xScale(d.assetA) || 0) + xScale.bandwidth() / 2)
        .attr("y", d => (yScale(d.assetB) || 0) + yScale.bandwidth() / 2 + 3.5)
        .attr("text-anchor", "middle")
        .style("fill", d => Math.abs(d.correlation) > 0.4 ? "#ffffff" : "#a1a1aa")
        .style("font-size", xScale.bandwidth() > 60 ? "10px" : "8px")
        .style("font-family", "monospace")
        .style("font-weight", "bold")
        .style("pointer-events", "none")
        .text(d => d.correlation > 0 ? `+${d.correlation.toFixed(2)}` : d.correlation.toFixed(2));
    }

    // Top X Axis Labels (Tick Names / Icons)
    g.selectAll(".x-axis-label")
      .data(ASSETS)
      .enter()
      .append("text")
      .attr("class", "x-axis-label")
      .attr("x", d => (xScale(d) || 0) + xScale.bandwidth() / 2)
      .attr("y", -12)
      .attr("text-anchor", "middle")
      .style("fill", "#a1a1aa")
      .style("font-size", dimensions.width < 400 ? "7px" : "9px")
      .style("font-weight", "bold")
      .style("font-family", "sans-serif")
      .text(d => d.split(" ")[0]); // shorten labels (e.g. "Gold (XAU/USD)" -> "Gold")

    // Left Y Axis Labels
    g.selectAll(".y-axis-label")
      .data(ASSETS)
      .enter()
      .append("text")
      .attr("class", "y-axis-label")
      .attr("x", -8)
      .attr("y", d => (yScale(d) || 0) + yScale.bandwidth() / 2 + 3.5)
      .attr("text-anchor", "end")
      .style("fill", "#a1a1aa")
      .style("font-size", "9px")
      .style("font-weight", "bold")
      .style("font-family", "sans-serif")
      .text(d => d.split(" ")[0]);

  }, [matrixData, dimensions]);

  // Determine dynamic hedging advisory
  const getAdvisory = (r: number) => {
    if (r === 1.0) return {
      title: "Perfect Positive",
      text: "Same asset comparison. Base baseline metric.",
      risk: "neutral"
    };
    if (r > 0.65) return {
      title: "Strong Positive",
      text: "High alignment. Avoid duplicating long/short exposures simultaneously, as they carry nearly identical directional risks.",
      risk: "warning"
    };
    if (r > 0.3) return {
      title: "Moderate Positive",
      text: "Mild directional synergy. Tends to move in unison but with separate idiosyncratic characteristics.",
      risk: "info"
    };
    if (r > -0.3 && r < 0.3) return {
      title: "Statistically Uncorrelated",
      text: "Highly independent price discovery. Safe choice for macro diversification and portfolio dispersion.",
      risk: "safe"
    };
    if (r < -0.6) return {
      title: "Strong Negative Correlation",
      text: "Outstanding hedging candidate! Perfect for direct risk mitigation. Take opposing positions to hedge systemic volatility.",
      risk: "hedge"
    };
    return {
      title: "Moderate Negative",
      text: "Reliable divergence. Serves as a solid baseline hedge during risk-off global market shifts.",
      risk: "hedge-light"
    };
  };

  return (
    <div id="correlation-matrix-panel" className="bg-zinc-900 border border-zinc-850 rounded-lg p-5 font-sans shadow-lg flex flex-col gap-4 relative">
      <div className="flex items-center justify-between border-b border-zinc-800 pb-3.5">
        <div className="flex items-center gap-2">
          <Grid className="w-5 h-5 text-emerald-400" />
          <div>
            <h2 className="text-sm font-bold tracking-wider text-zinc-100 uppercase flex items-center gap-1.5">
              Multi-Asset Correlation Matrix
            </h2>
            <p className="text-[10px] text-zinc-500 font-sans mt-0.5">
              Live-calculated Pearson coefficients ({sampleCount} sync points)
            </p>
          </div>
        </div>
        <div className="hidden sm:flex items-center gap-1 bg-zinc-950 px-2 py-1 rounded border border-zinc-850 text-[10px] text-zinc-400 font-mono">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
          <span>Adaptive Feed</span>
        </div>
      </div>

      <div ref={containerRef} className="w-full bg-zinc-950/20 rounded p-1 border border-zinc-900/50 flex justify-center items-center relative overflow-visible">
        <svg
          ref={svgRef}
          width={dimensions.width}
          height={dimensions.height}
          className="overflow-visible"
        />

        {/* Dynamic Hover Tooltip Overlay */}
        {hoveredCell && (
          <div
            className="absolute bg-zinc-950 border border-zinc-800 p-3 rounded-lg shadow-2xl pointer-events-none z-50 flex flex-col gap-1.5 max-w-[240px] select-none"
            style={{
              left: `${tooltipPos.x}px`,
              top: `${tooltipPos.y}px`,
              transform: "translate(-50%, -105%)",
            }}
          >
            <div className="flex items-center justify-between border-b border-zinc-900 pb-1">
              <span className="text-[9px] font-bold text-zinc-400 uppercase tracking-wide">
                Asset Relationship
              </span>
              <span className={`text-[10px] font-mono font-extrabold px-1.5 py-0.5 rounded ${
                hoveredCell.correlation >= 0.6
                  ? "bg-emerald-950 text-emerald-400 border border-emerald-900/40"
                  : hoveredCell.correlation <= -0.5
                  ? "bg-rose-950 text-rose-400 border border-rose-900/40"
                  : "bg-zinc-900 text-zinc-400 border border-zinc-800"
              }`}>
                {hoveredCell.correlation > 0 ? `+${hoveredCell.correlation.toFixed(3)}` : hoveredCell.correlation.toFixed(3)}
              </span>
            </div>

            <p className="text-[10px] text-zinc-200 font-bold leading-tight">
              {hoveredCell.assetA.split(" ")[0]} ↔ {hoveredCell.assetB.split(" ")[0]}
            </p>

            <div className="mt-1">
              <div className="flex items-center gap-1.5">
                {getAdvisory(hoveredCell.correlation).risk === "warning" || getAdvisory(hoveredCell.correlation).risk === "hedge" ? (
                  <ShieldAlert className={`w-3.5 h-3.5 shrink-0 ${
                    hoveredCell.correlation >= 0.6 ? "text-amber-400" : "text-emerald-400"
                  }`} />
                ) : (
                  <ShieldCheck className="w-3.5 h-3.5 text-zinc-500 shrink-0" />
                )}
                <span className="text-[9px] font-bold uppercase tracking-wider font-mono text-zinc-300">
                  {getAdvisory(hoveredCell.correlation).title}
                </span>
              </div>
              <p className="text-[9px] text-zinc-400 mt-1 leading-relaxed font-sans">
                {getAdvisory(hoveredCell.correlation).text}
              </p>
            </div>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-1.5 p-3 rounded bg-zinc-950/40 border border-zinc-850/60 font-sans text-[10px] text-zinc-400">
        <div className="flex gap-2 items-start">
          <div className="w-4 h-4 rounded bg-emerald-900 border border-emerald-500/20 shrink-0 mt-0.5"></div>
          <div>
            <span className="text-zinc-200 font-bold block">Positive Correlation (Emerald)</span>
            Assets tend to move together. Useful for confirming trend directions, but duplicate exposure multiplies risk.
          </div>
        </div>
        <div className="flex gap-2 items-start">
          <div className="w-4 h-4 rounded bg-rose-950 border border-rose-500/20 shrink-0 mt-0.5"></div>
          <div>
            <span className="text-zinc-200 font-bold block">Negative Correlation (Rose)</span>
            Assets move in opposite directions. Excellent candidate for direct hedging and strategic risk offsetting.
          </div>
        </div>
      </div>
    </div>
  );
}
