import React, { useState } from "react";
import { Signal, VerificationState } from "../types";
import { XCircle, CheckCircle, Copy, AlertCircle, Sparkles } from "lucide-react";

interface ConfirmationSandboxProps {
  signal: Signal;
  verification: VerificationState;
  onConfirm: () => void;
  onDiscard: () => void;
}

export default function ConfirmationSandbox({
  signal,
  verification,
  onConfirm,
  onDiscard
}: ConfirmationSandboxProps) {
  const [copied, setCopied] = useState<boolean>(false);

  const allChecked = 
    verification.sentimentChecked &&
    verification.correlationChecked &&
    verification.probabilityChecked &&
    verification.riskCalculated;

  const handleCopyAndVerify = () => {
    if (!allChecked) return;

    const sizeUnit = signal.asset === "Bitcoin" || signal.asset === "Ethereum" ? "Coins" : signal.asset === "Gold" ? "Ounces" : "Lots";

    const executionText = `--- QUANTUM QUANT EXECUTION DATA ---
Asset: ${signal.asset}
Direction: ${signal.action}
Entry Price: ${signal.price}
Stop Loss: ${signal.stopLoss}
Take Profit: ${signal.takeProfit}
Timeframe: ${signal.timeframe}
Account Balance: $${verification.accountBalance} USD
Max Risk Level: 1.5% ($${verification.riskAmount} USD)
Target Position Sizing: ${verification.calculatedPositionSize} ${sizeUnit}
Calculated Distance to SL: ${verification.pipsRisked} points/pips
Verification Status: COMPLETED & SIGNED OFF
-------------------------------------`;

    navigator.clipboard.writeText(executionText)
      .then(() => {
        setCopied(true);
        onConfirm();
        setTimeout(() => setCopied(false), 3000);
      })
      .catch((err) => {
        console.error("Failed to copy text: ", err);
      });
  };

  return (
    <div className="w-full bg-zinc-900 border border-zinc-850 rounded-lg p-5 font-sans shadow-lg mt-6">
      <div className="flex items-center gap-2 border-b border-zinc-800 pb-3 mb-4">
        <Sparkles className="w-4 h-4 text-emerald-400" />
        <h3 className="text-sm font-bold tracking-wider text-zinc-100 uppercase">Confirmation Sandbox</h3>
      </div>

      {!allChecked ? (
        <div className="bg-amber-950/20 border border-amber-900/30 text-amber-300 rounded p-4 flex items-start gap-3 text-xs leading-relaxed">
          <AlertCircle className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
          <div>
            <span className="font-semibold text-zinc-200 block mb-0.5">Verification Lock Active</span>
            To stop emotional trading and losing streaks, you are **strictly blocked** from copying or executing this signal until all 4 verification steps are manually completed: Macro Sentiment, Commodity Correlation, Reversal Boundaries, and Position Sizing.
          </div>
        </div>
      ) : (
        <div className="bg-emerald-950/20 border border-emerald-900/40 text-emerald-300 rounded p-4 flex items-start gap-3 text-xs leading-relaxed">
          <CheckCircle className="w-5 h-5 text-emerald-500 shrink-0 mt-0.5" />
          <div>
            <span className="font-semibold text-zinc-100 block mb-0.5">Signal Authenticated</span>
            All quantitative filters and capital management limits have passed. Copy the trade data below to lock in the absolute discipline execution parameters.
          </div>
        </div>
      )}

      {/* Primary Action Panel */}
      <div className="flex flex-col sm:flex-row items-center gap-3.5 mt-5">
        <button
          onClick={onDiscard}
          className="w-full sm:w-auto bg-zinc-950 hover:bg-rose-950/20 text-rose-400 hover:text-rose-300 hover:border-rose-900/40 active:bg-zinc-900 font-bold text-xs tracking-wider px-5 py-3 rounded border border-zinc-850 transition-all flex items-center justify-center gap-2 cursor-pointer"
        >
          <XCircle className="w-4 h-4" />
          <span>Discard Signal</span>
        </button>

        <button
          onClick={handleCopyAndVerify}
          disabled={!allChecked}
          className={`w-full sm:flex-1 font-bold text-xs tracking-wider px-5 py-3 rounded border transition-all flex items-center justify-center gap-2 cursor-pointer ${
            allChecked
              ? "bg-emerald-500 hover:bg-emerald-400 active:bg-emerald-600 text-zinc-950 border-emerald-400 font-extrabold shadow-sm shadow-emerald-500/20"
              : "bg-zinc-950 text-zinc-500 border-zinc-850 opacity-40 cursor-not-allowed"
          }`}
        >
          {copied ? (
            <>
              <CheckCircle className="w-4 h-4 text-zinc-950 animate-bounce" />
              <span>COPIED TO CLIPBOARD!</span>
            </>
          ) : (
            <>
              <Copy className="w-4 h-4" />
              <span>VERIFY AND COPY EXECUTION DATA</span>
            </>
          )}
        </button>
      </div>

      {copied && (
        <div className="mt-3.5 bg-emerald-950/40 border border-emerald-900/30 text-emerald-400 text-xs font-mono text-center p-2.5 rounded">
          SUCCESS: Position sizing of {verification.calculatedPositionSize} logged and clipboard set! Ready for terminal input.
        </div>
      )}
    </div>
  );
}
