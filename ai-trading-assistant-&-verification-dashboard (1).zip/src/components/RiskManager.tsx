import React, { useState, useEffect } from "react";
import { AIConsensusSignal } from "../types";
import { ShieldAlert, Scale, DollarSign, Sliders, AlertTriangle, Coins, Sparkles, Check } from "lucide-react";

interface RiskManagerProps {
  selectedSignal: AIConsensusSignal | null;
  onConfirmTrade?: (trade: {
    asset: string;
    action: string;
    portfolioSize: number;
    riskPercent: number;
    positionSize: number;
    riskAmount: number;
  }) => void;
}

export default function RiskManager({ selectedSignal, onConfirmTrade }: RiskManagerProps) {
  // 1. User inputs for position sizing
  const [portfolioSize, setPortfolioSize] = useState<number>(10000);
  const [riskPercent, setRiskPercent] = useState<number>(1.5);
  const [customSLDistance, setCustomSLDistance] = useState<number>(0);

  // 2. Pre-calculated stopLossDistance prop or fallback to user input
  const stopLossDistance = selectedSignal ? selectedSignal.stopLossDistance : (customSLDistance || 1.5);

  // 3. Mathematical Position Sizing calculations
  const riskAmount = (portfolioSize * (riskPercent / 100));
  // Position size ($) = Risk Amount ($) / (Stop Loss Distance % / 100)
  const positionSize = stopLossDistance > 0 ? (riskAmount / (stopLossDistance / 100)) : 0;

  // 4. Live Exposure states
  const [activeOpenRisk, setActiveOpenRisk] = useState<number>(250); // initial open risk ($)
  const [activeOpenExposure, setActiveOpenExposure] = useState<number>(4500); // initial active exposure ($)
  const [tradeConfirmedStatus, setTradeConfirmedStatus] = useState<boolean>(false);

  // Global safety constraints
  const MAX_GLOBAL_RISK_PERCENT = 5.0; // Max allowed portfolio at risk simultaneously
  const maxRiskAmount = (portfolioSize * (MAX_GLOBAL_RISK_PERCENT / 100));
  const proposedTotalRisk = activeOpenRisk + riskAmount;
  const isOverExposed = proposedTotalRisk > maxRiskAmount;

  // Sync inputs with selected signal
  useEffect(() => {
    if (selectedSignal) {
      setCustomSLDistance(selectedSignal.stopLossDistance);
      setTradeConfirmedStatus(false);
    }
  }, [selectedSignal]);

  const handleExecuteTrade = () => {
    if (!selectedSignal) return;
    
    // Simulate trade confirmation
    setTradeConfirmedStatus(true);
    setActiveOpenRisk(prev => prev + riskAmount);
    setActiveOpenExposure(prev => prev + positionSize);

    if (onConfirmTrade) {
      onConfirmTrade({
        asset: selectedSignal.asset,
        action: selectedSignal.action,
        portfolioSize,
        riskPercent,
        positionSize,
        riskAmount
      });
    }

    // Reset indicator after a short delay
    setTimeout(() => {
      setTradeConfirmedStatus(false);
    }, 3000);
  };

  return (
    <div id="risk-manager-panel" className="bg-zinc-900 border border-zinc-850 p-5 rounded-xl flex flex-col gap-6 h-full shadow-lg">
      
      {/* Panel Header */}
      <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
        <div className="flex items-center gap-2">
          <Scale className="w-4 h-4 text-emerald-400" />
          <h2 className="text-xs font-mono font-bold uppercase text-zinc-400 tracking-wider">
            III. THE SAFETY LAYER
          </h2>
        </div>
        <span className="text-[10px] font-mono font-bold text-zinc-500 bg-zinc-850 px-2 py-0.5 rounded">
          PROTECTION ON
        </span>
      </div>

      {/* 1. Position Sizer Form */}
      <div className="flex flex-col gap-4">
        <span className="text-xs font-mono font-bold text-zinc-400 flex items-center gap-1.5">
          <Sliders className="w-3.5 h-3.5 text-zinc-500" />
          Quant Position Sizer
        </span>

        {/* Inputs row */}
        <div className="flex flex-col gap-3">
          {/* Portfolio Size Input */}
          <div className="flex flex-col gap-1.5">
            <label className="text-[10px] font-mono font-bold text-zinc-500 uppercase">
              Total Portfolio Size (USD)
            </label>
            <div className="relative">
              <DollarSign className="absolute left-3 top-2.5 w-4 h-4 text-zinc-600" />
              <input
                type="number"
                value={portfolioSize}
                onChange={(e) => setPortfolioSize(Math.max(0, Number(e.target.value)))}
                className="w-full bg-zinc-950 border border-zinc-800 focus:border-zinc-700 focus:outline-none p-2 pl-9 rounded-lg text-sm font-mono font-bold text-zinc-200"
                placeholder="10000"
              />
            </div>
          </div>

          {/* Desired Risk Percent Input */}
          <div className="flex flex-col gap-1.5">
            <label className="text-[10px] font-mono font-bold text-zinc-500 uppercase flex justify-between">
              <span>Desired Trade Risk %</span>
              <span className="text-emerald-400 font-mono">Max 1.5% protect</span>
            </label>
            <div className="relative">
              <input
                type="number"
                step="0.1"
                value={riskPercent}
                onChange={(e) => setRiskPercent(Math.max(0.1, Math.min(10, Number(e.target.value))))}
                className="w-full bg-zinc-950 border border-zinc-800 focus:border-zinc-700 focus:outline-none p-2 pr-9 rounded-lg text-sm font-mono font-bold text-zinc-200"
                placeholder="1.5"
              />
              <span className="absolute right-3 top-2.5 text-xs text-zinc-600 font-bold font-mono">
                %
              </span>
            </div>
          </div>
        </div>

        {/* Dynamic calculation display card */}
        <div className="bg-zinc-950/60 border border-zinc-850 p-4 rounded-xl flex flex-col gap-3.5">
          <div className="flex items-center justify-between border-b border-zinc-900 pb-2">
            <span className="text-[10px] font-mono font-bold text-zinc-500">PROPOSED SETTINGS</span>
            {selectedSignal ? (
              <span className="text-[9px] font-mono font-bold text-emerald-400 bg-emerald-950/40 px-2 py-0.5 rounded">
                {selectedSignal.asset.replace("-USD", "")} ACTIVE
              </span>
            ) : (
              <span className="text-[9px] font-mono font-bold text-zinc-500 bg-zinc-900 px-2 py-0.5 rounded">
                NO SIGNAL LOADED
              </span>
            )}
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <span className="text-[10px] font-mono font-bold text-zinc-500 block uppercase">
                Capital at Risk
              </span>
              <span className="text-base font-extrabold font-mono text-zinc-200 mt-0.5 block">
                ${riskAmount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </span>
              <span className="text-[8px] font-mono font-bold text-zinc-500">
                ({riskPercent}% of account)
              </span>
            </div>

            <div>
              <span className="text-[10px] font-mono font-bold text-zinc-500 block uppercase">
                Stop Loss Dist.
              </span>
              <span className="text-base font-extrabold font-mono text-zinc-200 mt-0.5 block">
                {stopLossDistance.toFixed(2)}%
              </span>
              <span className="text-[8px] font-mono font-bold text-zinc-500">
                {selectedSignal ? "Loaded from signal" : "Simulated setting"}
              </span>
            </div>
          </div>

          <div className="border-t border-zinc-900 pt-3 flex flex-col">
            <span className="text-[10px] font-mono font-bold text-zinc-500 block uppercase">
              Calculated Position Size
            </span>
            <span className="text-xl font-black font-mono text-emerald-400 mt-1 block">
              ${positionSize.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </span>
            <span className="text-[8px] font-mono font-bold text-zinc-500 mt-0.5">
              Formula: (Portfolio Size * Risk %) / SL %
            </span>
          </div>
        </div>
      </div>

      {/* 2. Live Exposure Card */}
      <div className="flex flex-col gap-3 border-t border-zinc-800/80 pt-4">
        <span className="text-xs font-mono font-bold text-zinc-400 flex items-center gap-1.5">
          <Coins className="w-3.5 h-3.5 text-zinc-500" />
          Live exposure & Limits
        </span>

        <div className="bg-zinc-950/40 border border-zinc-850 p-3 rounded-lg flex flex-col gap-2">
          <div className="flex justify-between items-center text-xs">
            <span className="font-mono font-bold text-zinc-500">Active Risk In Play</span>
            <span className="font-mono font-extrabold text-zinc-300">
              ${activeOpenRisk.toLocaleString()} ({((activeOpenRisk / portfolioSize) * 100).toFixed(2)}%)
            </span>
          </div>

          <div className="flex justify-between items-center text-xs">
            <span className="font-mono font-bold text-zinc-500">Active Capital Exposed</span>
            <span className="font-mono font-extrabold text-zinc-300">
              ${activeOpenExposure.toLocaleString()}
            </span>
          </div>

          <div className="flex justify-between items-center text-xs border-t border-zinc-900 pt-2 mt-1">
            <span className="font-mono font-bold text-zinc-500">Proposed Total Risk</span>
            <span className={`font-mono font-extrabold ${isOverExposed ? "text-rose-400" : "text-zinc-300"}`}>
              ${proposedTotalRisk.toLocaleString()} ({((proposedTotalRisk / portfolioSize) * 100).toFixed(2)}%)
            </span>
          </div>

          {/* Safety Max Limit Indicator */}
          <div className="w-full h-1 bg-zinc-900 rounded-full overflow-hidden mt-1">
            <div 
              className={`h-full transition-all duration-500 ${isOverExposed ? "bg-rose-500 animate-pulse" : "bg-teal-500"}`}
              style={{ width: `${Math.min(100, (proposedTotalRisk / maxRiskAmount) * 100)}%` }}
            />
          </div>
        </div>

        {/* Live Warning when global risk parameters exceeded */}
        {isOverExposed && (
          <div className="bg-rose-950/30 border border-rose-900/30 p-3 rounded-lg flex gap-2.5 items-start animate-pulse">
            <ShieldAlert className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
            <div className="text-[11px] text-rose-300 leading-relaxed font-sans">
              <strong className="font-mono font-bold uppercase text-rose-400 block mb-0.5">
                MAX EXPOSURE EXCEEDED
              </strong>
              Proposed total risk ({((proposedTotalRisk / portfolioSize) * 100).toFixed(2)}%) exceeds the safe global restriction limit of {MAX_GLOBAL_RISK_PERCENT}%. Trading lock is active.
            </div>
          </div>
        )}
      </div>

      {/* 3. Action Execution Control */}
      {selectedSignal && (
        <button
          onClick={handleExecuteTrade}
          disabled={isOverExposed || tradeConfirmedStatus}
          className={`w-full py-3 px-4 font-mono font-extrabold text-xs uppercase rounded-lg border shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer ${
            tradeConfirmedStatus
              ? "bg-teal-950 border-teal-500/50 text-teal-400"
              : isOverExposed
              ? "bg-zinc-950 border-zinc-900 text-zinc-600 cursor-not-allowed"
              : selectedSignal.action === "LONG"
              ? "bg-emerald-950 hover:bg-emerald-900 border-emerald-500/30 text-emerald-400"
              : "bg-rose-950 hover:bg-rose-900 border-rose-500/30 text-rose-400"
          }`}
        >
          {tradeConfirmedStatus ? (
            <>
              <Check className="w-4 h-4" />
              <span>Trade Propagated to Ledger</span>
            </>
          ) : (
            <>
              <ShieldAlert className="w-4 h-4" />
              <span>
                {isOverExposed ? "Exceeds Safety parameters" : `Execute $${selectedSignal.asset.replace("-USD", "")} Consensus`}
              </span>
            </>
          )}
        </button>
      )}

    </div>
  );
}
