import React, { useState, useEffect } from "react";
import { MarketQuote } from "../types";
import { 
  TrendingUp, 
  TrendingDown, 
  RefreshCw, 
  BarChart2, 
  Coins, 
  Globe, 
  Landmark, 
  Bell, 
  BellOff,
  Activity
} from "lucide-react";

import { wsManager } from "../lib/websocket";

interface MarketTickerProps {
  quotes: MarketQuote[];
  loading: boolean;
  onRefresh: () => void;
  engine: string;
  wsStatus?: 'CONNECTING' | 'CONNECTED' | 'DISCONNECTED';
  latencyMetrics?: {
    cacheHit: boolean;
    timeToFirstTokenMs: number;
    inferenceTimeMs: number;
    endToEndLatencyMs: number;
    pipelineBottlenecks: string[];
  } | null;
}

export default function MarketTicker({ 
  quotes, 
  loading, 
  onRefresh, 
  engine, 
  wsStatus = 'DISCONNECTED',
  latencyMetrics
}: MarketTickerProps) {
  // Notification States
  const [enabledSymbols, setEnabledSymbols] = useState<Record<string, boolean>>(() => {
    try {
      const saved = localStorage.getItem("volatility_notifications");
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });

  const [notifiedSymbols, setNotifiedSymbols] = useState<Record<string, boolean>>({});
  const [toast, setToast] = useState<{ message: string; show: boolean } | null>(null);

  // Categorize quotes
  const coreAssets = quotes.filter(q => 
    ["GBPJPY=X", "USDJPY=X", "USDZAR=X", "GC=F", "BTC-USD", "ETH-USD"].includes(q.symbol)
  );

  const equities = quotes.filter(q => q.category === "equity");
  
  // Sort equities by absolute performance to find top movers
  const topMovers = [...equities]
    .sort((a, b) => Math.abs(b.changePercent) - Math.abs(a.changePercent))
    .slice(0, 5);

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case "forex": return <Globe className="w-3.5 h-3.5 text-blue-400" />;
      case "commodity": return <Landmark className="w-3.5 h-3.5 text-amber-500" />;
      case "crypto": return <Coins className="w-3.5 h-3.5 text-purple-400" />;
      default: return <BarChart2 className="w-3.5 h-3.5 text-zinc-400" />;
    }
  };

  const showToast = (msg: string) => {
    setToast({ message: msg, show: true });
    // Auto-dismiss after 4.5 seconds
    setTimeout(() => {
      setToast(prev => prev ? { ...prev, show: false } : null);
    }, 4500);
  };

  const toggleNotification = (symbol: string, assetName: string) => {
    const isCurrentlyEnabled = !!enabledSymbols[symbol];
    const updated = { ...enabledSymbols, [symbol]: !isCurrentlyEnabled };
    setEnabledSymbols(updated);
    localStorage.setItem("volatility_notifications", JSON.stringify(updated));

    if (!isCurrentlyEnabled) {
      // Prompt standard web notification request
      if ("Notification" in window) {
        Notification.requestPermission().then(permission => {
          if (permission === "granted") {
            showToast(`🔔 Volatility notifications enabled for ${assetName}! Browser will alert you if price swings exceed ±2%.`);
            // Fire an initial system test alert
            new Notification(`🔔 Volatility Monitor Active`, {
              body: `Monitoring ${assetName} for swings exceeding 2.0% threshold.`,
              icon: "https://ai.studio/build/favicon.ico"
            });
          } else if (permission === "denied") {
            showToast(`⚠️ Browser permission denied. Volatility alerts for ${assetName} will show as in-app sandbox toasts.`);
          } else {
            showToast(`🔔 Volatility notifications activated for ${assetName} (using in-app visual toast fallback).`);
          }
        });
      } else {
        showToast(`🔔 Activated in-app volatility alerts for ${assetName}.`);
      }
    } else {
      showToast(`🔕 Volatility notifications disabled for ${assetName}.`);
      // Reset notified record so we can alert again if re-enabled later
      setNotifiedSymbols(prev => ({ ...prev, [symbol]: false }));
    }
  };

  // Volatility Monitoring Engine: Runs on quote changes
  useEffect(() => {
    quotes.forEach((q) => {
      const isEnabled = enabledSymbols[q.symbol];
      const isExtremeVol = Math.abs(q.changePercent) >= 2.0;

      if (isEnabled && isExtremeVol) {
        // Only alert if we haven't already alerted for this specific asset on this cycle
        if (!notifiedSymbols[q.symbol]) {
          const alertMsg = `${q.name} is highly volatile! Swung ${q.changePercent > 0 ? "+" : ""}${q.changePercent.toFixed(2)}% (Current Price: ${q.price.toLocaleString()}).`;
          
          // 1. Native Web Notification
          if ("Notification" in window && Notification.permission === "granted") {
            try {
              new Notification(`⚠️ Extreme Volatility Alert`, {
                body: alertMsg,
                icon: "https://ai.studio/build/favicon.ico"
              });
            } catch (err) {
              console.warn("Native Notification failed in this context:", err);
            }
          }

          // 2. Beautiful In-App Sandbox Toast Fallback (perfect for iframe preview!)
          showToast(`⚠️ VOLATILITY SURGE: ${alertMsg}`);

          // Lock to prevent duplicate alerts
          setNotifiedSymbols(prev => ({ ...prev, [q.symbol]: true }));
        }
      } else if (isEnabled && !isExtremeVol) {
        // Reset notified lock once volatility cools off under 2.0% so next breakout fires again
        if (notifiedSymbols[q.symbol]) {
          setNotifiedSymbols(prev => ({ ...prev, [q.symbol]: false }));
        }
      }
    });
  }, [quotes, enabledSymbols, notifiedSymbols]);

  return (
    <div className="w-full bg-zinc-950 border-b border-zinc-850 p-4 font-sans select-none">
      {/* Header Info Panel */}
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row md:items-center justify-between gap-4 mb-4">
        <div className="flex items-center gap-3">
          <div className="relative">
            <div className="w-3 h-3 bg-emerald-500 rounded-full animate-ping absolute top-0 left-0"></div>
            <div className="w-3 h-3 bg-emerald-600 rounded-full relative"></div>
          </div>
          <div>
            <h1 className="text-lg font-bold text-zinc-100 tracking-tight flex items-center gap-2">
              QUANTUM<span className="text-emerald-500 text-xs px-2 py-0.5 rounded-sm bg-emerald-950/60 border border-emerald-900/40 font-mono">SIGNAL v2.5</span>
            </h1>
            <p className="text-xs text-zinc-400">
              Manual Execution Verification Terminal &bull; <span className="font-mono text-emerald-400">{engine}</span>
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3 text-xs self-start md:self-auto">
          {wsStatus === "CONNECTED" && (
            <div className="bg-zinc-900 px-3 py-1.5 rounded border border-zinc-850 text-zinc-300 font-mono flex flex-col items-end sm:items-start text-[10px] leading-tight select-none">
              <div className="flex items-center gap-1.5 font-bold text-emerald-400">
                <span className="relative flex h-1.5 w-1.5">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-emerald-500"></span>
                </span>
                STREAM ACTIVE (100ms)
              </div>
              <div className="text-[9px] text-zinc-500 uppercase tracking-wider font-semibold mt-0.5">
                Normalization & Indicator Workers Live
              </div>
            </div>
          )}

          {wsStatus === "CONNECTING" && (
            <div className="bg-zinc-900 px-3 py-1.5 rounded border border-zinc-850 text-zinc-300 font-mono flex flex-col items-end sm:items-start text-[10px] leading-tight select-none">
              <div className="flex items-center gap-1.5 font-bold text-amber-500">
                <span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-pulse"></span>
                WS CONNECTING...
              </div>
              <div className="text-[9px] text-zinc-500 uppercase tracking-wider font-semibold mt-0.5">
                Establishing handshake
              </div>
            </div>
          )}

          {wsStatus === "DISCONNECTED" && (
            <div className="flex items-center gap-2">
              <div className="bg-zinc-900 px-3 py-1.5 rounded border border-zinc-850 text-zinc-300 font-mono flex flex-col items-end sm:items-start text-[10px] leading-tight select-none">
                <div className="flex items-center gap-1.5 font-bold text-rose-500">
                  <span className="w-1.5 h-1.5 rounded-full bg-rose-500 animate-pulse"></span>
                  WS OFFLINE
                </div>
                <div className="text-[9px] text-zinc-500 uppercase tracking-wider font-semibold mt-0.5">
                  Streaming disconnected
                </div>
              </div>
              <button
                onClick={() => wsManager.connect()}
                className="bg-rose-950/80 hover:bg-rose-900 text-rose-300 border border-rose-800/60 font-bold px-2.5 py-1 rounded text-[10px] uppercase font-mono tracking-wider cursor-pointer transition-all"
                title="Reconnect to high-frequency WebSocket stream"
              >
                Connect
              </button>
            </div>
          )}

          {latencyMetrics && (
            <div className="bg-zinc-900 px-3.5 py-1 rounded border border-zinc-850 text-zinc-300 font-mono flex items-center gap-3 text-[10px] leading-tight select-none">
              <div className="flex flex-col">
                <span className="text-zinc-500 text-[8px] uppercase font-bold tracking-wider">E2E Latency</span>
                <span className="text-emerald-400 font-extrabold flex items-center gap-1 mt-0.5">
                  <Activity className="w-3 h-3 text-emerald-400 animate-pulse" />
                  {latencyMetrics.endToEndLatencyMs}ms
                </span>
              </div>
              <div className="hidden md:flex flex-col border-l border-zinc-800 pl-3">
                <span className="text-zinc-500 text-[8px] uppercase font-bold tracking-wider">TTFT</span>
                <span className="text-zinc-200 font-bold mt-0.5">
                  {latencyMetrics.timeToFirstTokenMs ? `${latencyMetrics.timeToFirstTokenMs}ms` : "N/A"}
                </span>
              </div>
              <div className="hidden lg:flex flex-col border-l border-zinc-800 pl-3">
                <span className="text-zinc-500 text-[8px] uppercase font-bold tracking-wider">AI Streaming</span>
                <span className="text-zinc-200 font-bold mt-0.5">
                  {latencyMetrics.inferenceTimeMs ? `${latencyMetrics.inferenceTimeMs}ms` : "N/A"}
                </span>
              </div>
              <div className="hidden sm:flex flex-col border-l border-zinc-800 pl-3">
                <span className="text-zinc-500 text-[8px] uppercase font-bold tracking-wider">Cache</span>
                <span className={`font-bold mt-0.5 uppercase ${latencyMetrics.cacheHit ? "text-emerald-400" : "text-amber-500"}`}>
                  {latencyMetrics.cacheHit ? "HIT" : "MISS"}
                </span>
              </div>
              {latencyMetrics.pipelineBottlenecks && latencyMetrics.pipelineBottlenecks.length > 0 && (
                <div className="hidden xl:flex flex-col border-l border-zinc-800 pl-3">
                  <span className="text-rose-400 text-[8px] uppercase font-bold tracking-wider">Alert</span>
                  <span className="text-rose-400 font-bold mt-0.5 truncate max-w-[100px]" title={latencyMetrics.pipelineBottlenecks.join(", ")}>
                    ⚠️ {latencyMetrics.pipelineBottlenecks[0]}
                  </span>
                </div>
              )}
            </div>
          )}

          <button
            onClick={onRefresh}
            disabled={loading}
            className="flex items-center gap-1.5 bg-zinc-900 hover:bg-zinc-800 active:bg-zinc-950 text-zinc-300 font-medium px-3.5 py-1.5 rounded border border-zinc-800 transition-all hover:border-zinc-700 disabled:opacity-50 cursor-pointer"
          >
            <RefreshCw className={`w-3.5 h-3.5 text-zinc-400 ${loading ? "animate-spin text-emerald-400" : ""}`} />
            <span className="hidden sm:inline">Force Refresh</span>
          </button>
        </div>
      </div>

      {/* Main Watchlist Ticker Grid */}
      <div className="max-w-7xl mx-auto grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3.5">
        {coreAssets.map((q) => {
          const isUp = q.changePercent >= 0;
          const isNotifOn = !!enabledSymbols[q.symbol];
          return (
            <div 
              key={q.symbol}
              className="bg-zinc-900/90 hover:bg-zinc-900 border border-zinc-850 hover:border-zinc-750 p-3 rounded transition-all flex flex-col justify-between gap-1 shadow-sm relative group"
            >
              <div className="flex items-center justify-between text-[11px] font-mono text-zinc-400">
                <span className="flex items-center gap-1">
                  {getCategoryIcon(q.category)}
                  {q.name}
                </span>
                
                {/* Volatility Alert Bell Toggle */}
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    toggleNotification(q.symbol, q.name);
                  }}
                  className={`p-1 rounded transition-colors cursor-pointer ${
                    isNotifOn 
                      ? "bg-emerald-950/80 text-emerald-400 border border-emerald-800/60" 
                      : "hover:bg-zinc-800 text-zinc-500 hover:text-zinc-300 border border-transparent"
                  }`}
                  title={isNotifOn ? "Disable volatility alerts for this asset" : "Enable volatility alerts (>2% swing)"}
                >
                  {isNotifOn ? <Bell className="w-3 h-3 fill-emerald-400/20" /> : <BellOff className="w-3 h-3" />}
                </button>
              </div>

              <div className="flex items-baseline justify-between mt-1">
                <span className="font-mono text-sm font-semibold tracking-tight text-zinc-100">
                  {q.price.toLocaleString(undefined, { 
                    minimumFractionDigits: q.symbol.includes("JPY") ? 2 : q.symbol === "USDZAR=X" ? 4 : 2,
                    maximumFractionDigits: q.symbol.includes("JPY") ? 2 : q.symbol === "USDZAR=X" ? 4 : 2,
                  })}
                </span>
                <span className={`font-mono text-xs font-semibold flex items-center gap-0.5 ${isUp ? "text-emerald-400" : "text-rose-400"}`}>
                  {isUp ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
                  {isUp ? "+" : ""}{q.changePercent.toFixed(2)}%
                </span>
              </div>

              {/* Dynamic Technical Indicators from WebSocket-First Pipeline */}
              <div className="grid grid-cols-3 gap-1 mt-2.5 pt-2 border-t border-zinc-800/50 text-[9px] font-mono leading-tight select-none">
                <div className="flex flex-col items-start">
                  <span className="text-zinc-500 text-[8px] uppercase font-semibold">RSI</span>
                  <span className={`font-bold mt-0.5 ${q.rsi ? (q.rsi > 70 ? 'text-rose-400' : q.rsi < 30 ? 'text-emerald-400' : 'text-zinc-300') : 'text-zinc-500'}`}>
                    {q.rsi ? q.rsi.toFixed(1) : "---"}
                  </span>
                </div>
                <div className="flex flex-col items-start">
                  <span className="text-zinc-500 text-[8px] uppercase font-semibold">SMA(5)</span>
                  <span className="text-zinc-300 font-medium mt-0.5 truncate max-w-full">
                    {q.sma5 ? q.sma5.toLocaleString(undefined, { maximumFractionDigits: q.symbol.includes("JPY") ? 1 : 2 }) : "---"}
                  </span>
                </div>
                <div className="flex flex-col items-start">
                  <span className="text-zinc-500 text-[8px] uppercase font-semibold">VOL</span>
                  <span className="text-amber-400 font-medium mt-0.5">
                    {q.volatility ? `${q.volatility.toFixed(2)}%` : "---"}
                  </span>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Top Movers Sector Sub-panel */}
      <div className="max-w-7xl mx-auto mt-4 pt-3.5 border-t border-zinc-900/60 flex flex-col lg:flex-row items-start lg:items-center justify-between gap-3">
        <div className="flex items-center gap-2 text-xs font-semibold text-zinc-400 tracking-wider uppercase font-sans">
          <span className="inline-block w-1.5 h-3 bg-emerald-500 rounded-sm"></span>
          Top Equity Analytics & Movers (Enables Alerts)
        </div>
        <div className="w-full lg:w-auto flex flex-wrap gap-2">
          {topMovers.map((q) => {
            const isUp = q.changePercent >= 0;
            const isNotifOn = !!enabledSymbols[q.symbol];
            return (
              <div 
                key={q.symbol}
                className="bg-zinc-950 border border-zinc-850 hover:border-zinc-800 text-[11px] font-mono px-3 py-1.5 rounded flex items-center gap-3 relative group"
              >
                <span className="text-zinc-300 font-semibold">{q.symbol}</span>
                <span className="text-zinc-400 font-medium">${q.price.toFixed(2)}</span>
                <span className={`font-bold flex items-center gap-0.5 ${isUp ? "text-emerald-400" : "text-rose-400"}`}>
                  {isUp ? "+" : ""}{q.changePercent.toFixed(2)}%
                </span>

                {/* mini bell toggle for mover */}
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    toggleNotification(q.symbol, q.symbol);
                  }}
                  className={`p-0.5 rounded transition-colors cursor-pointer ${
                    isNotifOn 
                      ? "bg-emerald-950 text-emerald-400 border border-emerald-800" 
                      : "text-zinc-600 hover:text-zinc-300"
                  }`}
                  title={isNotifOn ? "Volatility alerts active" : "Enable volatility alerts"}
                >
                  {isNotifOn ? <Bell className="w-2.5 h-2.5 fill-emerald-400/20" /> : <BellOff className="w-2.5 h-2.5" />}
                </button>
              </div>
            );
          })}
        </div>
      </div>

      {/* Persistent Inline Volatility Toast Portal */}
      {toast && toast.show && (
        <div className="fixed bottom-4 right-4 z-50 bg-zinc-950 border border-zinc-800 shadow-2xl p-4 rounded-lg flex items-start gap-3.5 max-w-sm animate-in fade-in slide-in-from-bottom-5 duration-300">
          <div className="p-2 rounded bg-emerald-950/80 text-emerald-400 border border-emerald-900/40">
            <Bell className="w-4 h-4 fill-emerald-400/10 animate-bounce" />
          </div>
          <div>
            <span className="text-[10px] font-mono font-bold text-zinc-500 uppercase tracking-widest block">System Broadcast</span>
            <p className="text-xs text-zinc-200 mt-1 leading-relaxed font-sans">
              {toast.message}
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
