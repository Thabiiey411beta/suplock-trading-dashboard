import React, { useState, useEffect } from "react";
import { Signal } from "../types";
import { Globe, RefreshCw, CheckCircle, AlertCircle, Newspaper, MessageSquare } from "lucide-react";

interface Headline {
  title: string;
  source: string;
  time: string;
  sentiment: "BULLISH" | "BEARISH" | "NEUTRAL";
  summary: string;
}

interface RealTimeSentimentNewsProps {
  signal: Signal;
}

export default function RealTimeSentimentNews({ signal }: RealTimeSentimentNewsProps) {
  const [headlines, setHeadlines] = useState<Headline[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [isAi, setIsAi] = useState<boolean>(false);

  const fetchNews = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch(`/api/sentiment-news?asset=${encodeURIComponent(signal.asset)}`);
      const data = await res.json();
      if (data.success && Array.isArray(data.headlines)) {
        setHeadlines(data.headlines);
        setIsAi(!!data.aiGenerated);
      } else {
        throw new Error(data.error || "Failed to load headlines");
      }
    } catch (err: any) {
      console.error("Error fetching sentiment news:", err);
      setError("Failed to load real-time sentiment headlines.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchNews();
  }, [signal.asset]);

  const getSentimentBadge = (sentiment: string) => {
    switch (sentiment) {
      case "BULLISH":
        return "bg-emerald-950/60 text-emerald-400 border border-emerald-900/40 text-[9px] font-bold tracking-wider";
      case "BEARISH":
        return "bg-rose-950/60 text-rose-400 border border-rose-900/40 text-[9px] font-bold tracking-wider";
      default:
        return "bg-zinc-900 text-zinc-400 border border-zinc-800 text-[9px] font-bold tracking-wider";
    }
  };

  return (
    <div id="sentiment-news-section" className="bg-zinc-950 border border-zinc-850 rounded-lg p-4 mt-5">
      <div className="flex items-center justify-between border-b border-zinc-900 pb-2.5 mb-3.5">
        <div className="flex items-center gap-1.5">
          <Newspaper className="w-4 h-4 text-emerald-400" />
          <h4 className="text-xs font-bold text-zinc-200 uppercase tracking-wider font-mono">
            Real-Time Sentiment News
          </h4>
        </div>
        <div className="flex items-center gap-2">
          {isAi && (
            <span className="text-[9px] font-mono font-semibold text-emerald-400 bg-emerald-950/40 px-1.5 py-0.5 rounded border border-emerald-900/30">
              Gemini Summary
            </span>
          )}
          <button
            onClick={fetchNews}
            disabled={loading}
            className="text-zinc-500 hover:text-zinc-300 disabled:opacity-30 transition-colors p-1"
            title="Reload Headline Summaries"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? "animate-spin text-emerald-400" : ""}`} />
          </button>
        </div>
      </div>

      {loading ? (
        <div className="py-8 flex flex-col items-center justify-center gap-2.5">
          <RefreshCw className="w-5 h-5 text-emerald-400 animate-spin" />
          <p className="text-[11px] text-zinc-500 font-mono">Fetching latest regional economic summaries...</p>
        </div>
      ) : error ? (
        <div className="py-4 text-center text-xs text-rose-400 font-mono flex items-center justify-center gap-2">
          <AlertCircle className="w-4 h-4" />
          {error}
        </div>
      ) : headlines.length === 0 ? (
        <div className="py-4 text-center text-xs text-zinc-500 font-mono">
          No headlines found for this asset category.
        </div>
      ) : (
        <div className="flex flex-col gap-3.5">
          {headlines.map((item, idx) => (
            <div
              key={idx}
              className="bg-zinc-900/30 hover:bg-zinc-900/70 p-3 rounded-md border border-zinc-900/80 hover:border-zinc-850 transition-all flex flex-col gap-2"
            >
              <div className="flex items-start justify-between gap-3">
                <h5 className="text-xs font-semibold text-zinc-200 leading-snug">
                  {item.title}
                </h5>
                <span className={`shrink-0 px-1.5 py-0.5 rounded uppercase ${getSentimentBadge(item.sentiment)}`}>
                  {item.sentiment}
                </span>
              </div>
              
              <p className="text-[11px] text-zinc-400 leading-relaxed font-sans">
                {item.summary}
              </p>

              <div className="flex items-center justify-between text-[10px] font-mono text-zinc-500 pt-1 border-t border-zinc-900/40">
                <span className="font-semibold">{item.source}</span>
                <span>{item.time}</span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
