import React, { useState } from "react";
import { useSubscription } from "../SubscriptionContext";
import { SubscriptionTier } from "../types";
import { 
  CreditCard, 
  Layers, 
  Key, 
  Cpu, 
  CheckCircle2, 
  ArrowRight, 
  RefreshCw, 
  Users, 
  Zap, 
  Lock, 
  Unlock,
  Activity,
  Terminal,
  Code,
  Gauge,
  Sliders,
  CheckCircle,
  HelpCircle,
  TrendingUp,
  Settings2,
  Sparkles,
  BarChart2
} from "lucide-react";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid
} from "recharts";

export default function SubscriptionPanel() {
  const { 
    tenantId, 
    entitlement, 
    setTenantId, 
    upgradeTier, 
    simulateStripeWebhook, 
    isFeatureUnlocked 
  } = useSubscription();

  const [customTenant, setCustomTenant] = useState<string>("default-tenant");
  const [activeTab, setActiveTab] = useState<"billing" | "developer" | "accuracy">("billing");
  
  // Admin Accuracy and AI Model Tuning states
  const [adminAccuracy, setAdminAccuracy] = useState<{
    summary: {
      totalCompleted: number;
      totalProfitable: number;
      totalLosses: number;
      overallAccuracy: number;
    };
    assetStats: Array<{ asset: string; total: number; profitable: number; accuracy: number }>;
    tenantStats: Array<{ tenantId: string; total: number; profitable: number; accuracy: number }>;
    recentTrend: Array<{ tradeIndex: number; tradeId: string; asset: string; action: string; timestamp: string; isProfit: boolean; accuracy: number }>;
  } | null>(null);

  const [modelSettings, setModelSettings] = useState<{
    minConfidenceFilter: number;
    correlationFilter: boolean;
    rsiThreshold: number;
    newsSentimentWeight: number;
    modelSelection: string;
  }>({
    minConfidenceFilter: 65,
    correlationFilter: true,
    rsiThreshold: 30,
    newsSentimentWeight: 40,
    modelSelection: "gemini-1.5-pro"
  });

  const [savingSettings, setSavingSettings] = useState<boolean>(false);
  const [settingsMsg, setSettingsMsg] = useState<string>("");
  
  // Usage Telemetry & Billing Invoice states
  const [telemetry, setTelemetry] = useState<{
    trades_verified: number;
    ai_signals_generated: number;
    backtests_run: number;
    api_calls: number;
  }>({
    trades_verified: 0,
    ai_signals_generated: 0,
    backtests_run: 0,
    api_calls: 0
  });
  const [invoice, setInvoice] = useState<number>(0);

  // Playground interactive API states
  const [playAsset, setPlayAsset] = useState<string>("GBP/JPY");
  const [playAction, setPlayAction] = useState<"BUY" | "SELL">("SELL");
  const [playPrice, setPlayPrice] = useState<number>(204.65);
  const [playSL, setPlaySL] = useState<number>(205.15);
  const [apiResponse, setApiResponse] = useState<string>("// Select parameters above and trigger direct verification API query...");
  const [queryingApi, setQueryingApi] = useState<boolean>(false);

  const [webhookLogs, setWebhookLogs] = useState<Array<{ id: string; time: string; event: string; status: string; detail: string }>>([
    {
      id: "log_01",
      time: new Date().toLocaleTimeString(),
      event: "system.initialized",
      status: "SUCCESS",
      detail: `Multi-tenant subscription engine loaded. Current tenant "${tenantId}" resolved as ${entitlement.tier.toUpperCase()}.`
    }
  ]);
  const [simulating, setSimulating] = useState<boolean>(false);

  // Poll usage telemetry for active tenant context
  const fetchTelemetry = async () => {
    try {
      const res = await fetch(`/api/telemetry/usage?tenantId=${tenantId}`);
      const data = await res.json();
      if (data.success && data.metrics) {
        setTelemetry(data.metrics);
        const cost = 
          data.metrics.trades_verified * 0.15 +
          data.metrics.ai_signals_generated * 0.05 +
          data.metrics.backtests_run * 1.50 +
          data.metrics.api_calls * 0.02;
        setInvoice(cost);
      }
    } catch (err) {
      console.error("Telemetry fetch error:", err);
    }
  };

  const fetchAdminAccuracy = async () => {
    try {
      const res = await fetch("/api/admin/accuracy");
      const data = await res.json();
      if (data.success) {
        setAdminAccuracy(data);
      }
    } catch (err) {
      console.error("Failed to fetch admin accuracy metrics:", err);
    }
  };

  const fetchModelSettings = async () => {
    try {
      const res = await fetch("/api/admin/model-settings");
      const data = await res.json();
      if (data.success && data.settings) {
        setModelSettings(data.settings);
      }
    } catch (err) {
      console.error("Failed to fetch model settings:", err);
    }
  };

  const handleSaveModelSettings = async () => {
    setSavingSettings(true);
    setSettingsMsg("");
    try {
      const res = await fetch("/api/admin/model-settings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(modelSettings)
      });
      const data = await res.json();
      if (data.success) {
        setSettingsMsg("Optimization parameters active in quantitative engine.");
        setTimeout(() => setSettingsMsg(""), 4000);
        addWebhookLog("admin.model_optimized", "SUCCESS", "Backend AI model optimization parameters updated and saved.");
      }
    } catch (err: any) {
      setSettingsMsg("Failed to save: " + err.message);
    } finally {
      setSavingSettings(false);
    }
  };

  React.useEffect(() => {
    fetchTelemetry();
    const interval = setInterval(() => {
      fetchTelemetry();
      if (activeTab === "accuracy") {
        fetchAdminAccuracy();
      }
    }, 10000);

    if (activeTab === "accuracy") {
      fetchAdminAccuracy();
      fetchModelSettings();
    }

    return () => clearInterval(interval);
  }, [tenantId, activeTab]);

  const addWebhookLog = (event: string, status: string, detail: string) => {
    setWebhookLogs(prev => [
      {
        id: `log_${Date.now()}`,
        time: new Date().toLocaleTimeString(),
        event,
        status,
        detail
      },
      ...prev
    ]);
  };

  const handleSwitchTenant = (id: string) => {
    setTenantId(id);
    addWebhookLog("tenant.switched", "INFO", `Active tenant context updated to "${id}". Reloading entitlement records...`);
  };

  const handleCreateTenant = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customTenant.trim()) return;
    const cleanId = customTenant.trim().toLowerCase().replace(/\s+/g, "-");
    handleSwitchTenant(cleanId);
    setCustomTenant("");
  };

  // Simulate purchasing Pro via Stripe Checkout
  const handleSimulateCheckout = async (tier: SubscriptionTier) => {
    setSimulating(true);
    addWebhookLog("stripe.checkout.initiated", "PENDING", `Creating simulated checkout session for ${tier.toUpperCase()} plan (Tenant: "${tenantId}")...`);
    
    // Simulate user completing payment in 1 second
    setTimeout(async () => {
      const success = await upgradeTier(tier);
      if (success) {
        addWebhookLog(
          "stripe.webhook.checkout.session.completed", 
          "SUCCESS", 
          `Received Stripe Webhook for Tenant: "${tenantId}". Stripe invoice paid. Subscription state updated to: ${tier.toUpperCase()}.`
        );
      } else {
        addWebhookLog("stripe.webhook.error", "FAILED", `Failed to apply subscription. Contact SaaS platform admin.`);
      }
      setSimulating(false);
    }, 1200);
  };

  // Simulate standard webhook triggers (like canceled or past_due)
  const handleSimulateWebhookEvent = async (tier: SubscriptionTier, eventType: string) => {
    setSimulating(true);
    addWebhookLog(`stripe.webhook.${eventType}`, "PENDING", `Simulating Stripe incoming webhook for "${tenantId}"...`);
    
    setTimeout(async () => {
      const success = await simulateStripeWebhook(tier, eventType);
      if (success) {
        if (eventType === "customer.subscription.deleted") {
          addWebhookLog(
            "stripe.webhook.customer.subscription.deleted", 
            "SUCCESS", 
            `Received subscription.deleted for Tenant: "${tenantId}". Subscription revoked. Tier downgraded to FREE.`
          );
        } else if (eventType === "customer.subscription.updated") {
          addWebhookLog(
            "stripe.webhook.customer.subscription.updated", 
            "SUCCESS", 
            `Received subscription.updated for Tenant: "${tenantId}". State set to ${tier.toUpperCase()}.`
          );
        }
      } else {
        addWebhookLog("stripe.webhook.error", "FAILED", `Error routing simulation webhook.`);
      }
      setSimulating(false);
    }, 1000);
  };

  const handleQueryPlayground = async () => {
    setQueryingApi(true);
    setApiResponse("// Directing sandbox query to backend /api/v1/verify...");
    try {
      const keysMap: Record<string, string> = {
        "default-tenant": "key_free_default_12345",
        "alpha-funds": "key_pro_alpha_funds_abc987",
        "apex-institutional": "key_apex_institutional_xyz777"
      };
      const apiKey = keysMap[tenantId] || `key_custom_${tenantId.replace(/-/g, "_")}_abc888`;

      const res = await fetch("/api/v1/verify", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-api-key": apiKey
        },
        body: JSON.stringify({
          asset: playAsset,
          action: playAction,
          price: Number(playPrice),
          stopLoss: Number(playSL),
          takeProfit: Number(playPrice) + (Number(playPrice) - Number(playSL)) * 2,
          accountBalance: 10000,
          riskPercent: 1.5
        })
      });

      const data = await res.json();
      setApiResponse(JSON.stringify(data, null, 2));
      fetchTelemetry();
    } catch (err: any) {
      setApiResponse(JSON.stringify({ success: false, error: err.message }, null, 2));
    } finally {
      setQueryingApi(false);
    }
  };

  const handleDownloadCSV = () => {
    window.open(`/api/telemetry/export?tenantId=${tenantId}&format=csv`, "_blank");
  };

  const handleResetTelemetry = async () => {
    try {
      const res = await fetch("/api/telemetry/reset", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ tenantId })
      });
      const data = await res.json();
      if (data.success) {
        setTelemetry({ trades_verified: 0, ai_signals_generated: 0, backtests_run: 0, api_calls: 0 });
        setInvoice(0);
        addWebhookLog("telemetry.reset", "SUCCESS", `SaaS tenant "${tenantId}" usage telemetry counter cleared.`);
      }
    } catch (err: any) {
      console.error("Failed to reset telemetry:", err);
    }
  };

  const planCards = [
    {
      id: "free" as SubscriptionTier,
      name: "Standard Core",
      price: "$0",
      description: "Basic quantitative manual risk guidelines",
      features: [
        "FinRobot Base Watchlist Feed",
        "1.5% Hardcoded Account Protector",
        "Live Market Rate Feed",
        "Limited 30-day FinRL backtester"
      ],
      disabledFeatures: [
        "Inter-market Correlation Analysis",
        "Post-Trade PnL Performance Review",
        "High-Frequency Macro Overrides"
      ],
      color: "border-zinc-800 text-zinc-400 bg-zinc-900/10"
    },
    {
      id: "pro" as SubscriptionTier,
      name: "Quant Pro",
      price: "$79/mo",
      description: "Advanced asset correlation and historic trade reviews",
      features: [
        "Unlock: Inter-market Correlation Matrix",
        "Unlock: Live Post-Trade Review & PnL",
        "Unlimited High-Fidelity FinRL Backtester",
        "Extended Gemini 3.5 Sentiment Engine",
        "Central Bank Macro Policy Ledger"
      ],
      disabledFeatures: [
        "Raw Order Book Heatmap Overrides"
      ],
      color: "border-emerald-900 text-zinc-100 bg-emerald-950/5 shadow-[0_0_15px_rgba(16,185,129,0.03)]"
    },
    {
      id: "institutional" as SubscriptionTier,
      name: "Sovereign Apex",
      price: "$299/mo",
      description: "Dedicated endpoints for multi-tenant trading funds",
      features: [
        "Unlocks All Features & Analytics",
        "Priority Gemini Multi-Agent Core",
        "Pre-configured Multi-Tenant Environments",
        "Raw Order Book Heatmap Overrides",
        "Guaranteed SLA and Webhook uptime loggers"
      ],
      disabledFeatures: [],
      color: "border-blue-900 text-zinc-100 bg-blue-950/5 shadow-[0_0_15px_rgba(59,130,246,0.03)]"
    }
  ];

  return (
    <div id="saas-subscription-portal" className="bg-zinc-900 border border-zinc-850 rounded-lg p-5 font-sans shadow-lg col-span-1 lg:col-span-12 flex flex-col gap-6">
      
      {/* Header Banner */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between border-b border-zinc-800 pb-4 gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Layers className="w-5 h-5 text-emerald-400" />
            <h2 className="text-sm font-bold tracking-wider text-zinc-100 uppercase">Commercial Subscription & Webhook Portal</h2>
          </div>
          <p className="text-xs text-zinc-500 mt-1 max-w-2xl leading-relaxed">
            Multi-Tenant Entitlements Gating System. Review billing plans, create custom SaaS tenants, test the Stripe Webhook lifecycle, and inspect signature authorization flow.
          </p>
        </div>

        {/* Tab Selector */}
        <div className="flex bg-zinc-950 p-1 border border-zinc-850 rounded-md self-stretch md:self-auto shrink-0 font-mono text-[11px] font-bold gap-1">
          <button
            onClick={() => setActiveTab("billing")}
            className={`px-3.5 py-1.5 rounded transition-all cursor-pointer ${
              activeTab === "billing"
                ? "bg-zinc-850 text-emerald-400 border border-zinc-700"
                : "text-zinc-400 hover:text-zinc-200"
            }`}
          >
            <CreditCard className="w-3.5 h-3.5 inline mr-1.5" />
            Subscription Portal
          </button>
          <button
            onClick={() => setActiveTab("developer")}
            className={`px-3.5 py-1.5 rounded transition-all cursor-pointer flex items-center gap-1.5 ${
              activeTab === "developer"
                ? "bg-zinc-850 text-emerald-400 border border-zinc-700"
                : "text-zinc-400 hover:text-zinc-200"
            }`}
          >
            <Terminal className="w-3.5 h-3.5" />
            Developer Hub & Telemetry
          </button>
          <button
            onClick={() => setActiveTab("accuracy")}
            className={`px-3.5 py-1.5 rounded transition-all cursor-pointer flex items-center gap-1.5 ${
              activeTab === "accuracy"
                ? "bg-zinc-850 text-emerald-400 border border-zinc-700"
                : "text-zinc-400 hover:text-zinc-200"
            }`}
          >
            <Cpu className="w-3.5 h-3.5 text-blue-400" />
            Admin Accuracy & AI Optimizer
          </button>
        </div>
      </div>

      {/* Main Sandbox Grid */}
      {activeTab === "billing" ? (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          
          {/* Left Column: Plan Selection Grid */}
          <div className="lg:col-span-8 flex flex-col gap-5">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {planCards.map((plan) => {
                const isActive = entitlement.tier === plan.id;
                return (
                  <div 
                    key={plan.id} 
                    className={`border rounded-lg p-4 flex flex-col justify-between transition-all relative ${plan.color} ${
                      isActive ? "ring-2 ring-emerald-500 ring-offset-2 ring-offset-zinc-950 scale-[1.01]" : ""
                    }`}
                  >
                    {isActive && (
                      <span className="absolute top-2.5 right-2.5 bg-emerald-500 text-zinc-950 font-mono font-black text-[9px] px-2 py-0.5 rounded tracking-wide uppercase">
                        Active Plan
                      </span>
                    )}

                    <div>
                      <span className="text-[10px] font-mono text-zinc-500 font-bold uppercase block tracking-wider">{plan.description}</span>
                      <h3 className="text-base font-bold mt-1 text-zinc-100">{plan.name}</h3>
                      <div className="flex items-baseline gap-1 mt-3.5 mb-4">
                        <span className="text-2xl font-mono font-black text-zinc-100">{plan.price}</span>
                        {plan.id !== "free" && <span className="text-[10px] text-zinc-500">/ tenant</span>}
                      </div>

                      <ul className="space-y-2 mt-4 pt-4 border-t border-zinc-850/60 font-sans text-xs text-zinc-300">
                        {plan.features.map((feat, idx) => (
                          <li key={idx} className="flex items-start gap-2">
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                            <span>{feat}</span>
                          </li>
                        ))}
                        {plan.disabledFeatures.map((feat, idx) => (
                          <li key={idx} className="flex items-start gap-2 text-zinc-600">
                            <Lock className="w-3.5 h-3.5 text-zinc-700 shrink-0 mt-0.5" />
                            <span className="line-through">{feat}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <button
                      onClick={() => handleSimulateCheckout(plan.id)}
                      disabled={isActive || simulating}
                      className={`mt-6 w-full py-2 rounded text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                        isActive
                          ? "bg-zinc-800 text-zinc-500 border border-zinc-850 cursor-not-allowed"
                          : plan.id === "free"
                          ? "bg-zinc-800 hover:bg-zinc-700 text-zinc-200 border border-zinc-750"
                          : plan.id === "pro"
                          ? "bg-emerald-950 text-emerald-400 hover:bg-emerald-900 border border-emerald-800/40"
                          : "bg-blue-950 text-blue-400 hover:bg-blue-900 border border-blue-800/40"
                      }`}
                    >
                      {simulating ? (
                        <>
                          <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                          <span>Syncing Stripe...</span>
                        </>
                      ) : isActive ? (
                        <span>Currently Active</span>
                      ) : (
                        <>
                          <span>Activate {plan.name}</span>
                          <ArrowRight className="w-3 h-3" />
                        </>
                      )}
                    </button>
                  </div>
                );
              })}
            </div>

            {/* Simulated webhook operations quick triggers */}
            <div className="bg-zinc-950 border border-zinc-850 p-4 rounded-lg flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
              <div className="flex gap-3 items-start">
                <div className="bg-amber-950/40 border border-amber-900/30 p-2 rounded text-amber-400 mt-0.5">
                  <Zap className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-zinc-200 uppercase tracking-wide">Webhook Simulator Toolbox</h4>
                  <p className="text-[10px] text-zinc-500 mt-1 max-w-lg leading-relaxed">
                    Stripe triggers webhooks asynchronously. Use these simulation buttons to feed real payloads directly into the server subscription lifecycle router.
                  </p>
                </div>
              </div>

              <div className="flex flex-wrap gap-2.5 font-mono text-[10px] self-stretch md:self-auto shrink-0">
                <button
                  onClick={() => handleSimulateWebhookEvent("pro", "customer.subscription.updated")}
                  disabled={simulating}
                  className="bg-zinc-900 hover:bg-zinc-850 text-zinc-300 border border-zinc-800 px-3 py-1.5 rounded cursor-pointer transition-colors disabled:opacity-50"
                >
                  Trigger `subscription.updated` (Pro)
                </button>
                <button
                  onClick={() => handleSimulateWebhookEvent("free", "customer.subscription.deleted")}
                  disabled={simulating || entitlement.tier === "free"}
                  className="bg-zinc-900 hover:bg-rose-950/60 hover:text-rose-400 hover:border-rose-900/40 text-zinc-400 border border-zinc-800 px-3 py-1.5 rounded cursor-pointer transition-colors disabled:opacity-50"
                >
                  Trigger `subscription.deleted`
                </button>
              </div>
            </div>
          </div>

          {/* Right Column: Multi-Tenant Switcher */}
          <div className="lg:col-span-4 flex flex-col gap-4">
            
            {/* Active Context card */}
            <div className="bg-zinc-950 border border-zinc-850 p-4 rounded-lg">
              <span className="text-[9px] font-mono font-bold uppercase text-zinc-500 block tracking-wider">Active Tenant Metadata</span>
              <div className="flex items-center gap-2 mt-2">
                <Users className="w-4 h-4 text-emerald-400" />
                <span className="text-sm font-bold text-zinc-200 block font-mono">{tenantId}</span>
              </div>
              <div className="grid grid-cols-2 gap-2 mt-4 pt-3 border-t border-zinc-900 font-mono text-[10px]">
                <div>
                  <span className="text-zinc-500 block">TIER LEVEL:</span>
                  <span className={`font-black uppercase tracking-wider block mt-0.5 ${
                    entitlement.tier === "free" ? "text-zinc-400" : entitlement.tier === "pro" ? "text-emerald-400" : "text-blue-400"
                  }`}>{entitlement.tier}</span>
                </div>
                <div>
                  <span className="text-zinc-500 block">STATUS:</span>
                  <span className="text-emerald-500 font-bold block mt-0.5 uppercase">{entitlement.status}</span>
                </div>
              </div>
            </div>

            {/* Tenant switcher presets */}
            <div className="bg-zinc-950 border border-zinc-850 p-4 rounded-lg">
              <h4 className="text-xs font-bold text-zinc-300 mb-3 font-mono">SaaS Tenant Presets</h4>
              <div className="space-y-1.5">
                <button
                  onClick={() => handleSwitchTenant("default-tenant")}
                  className={`w-full text-left p-2 rounded text-xs font-mono flex items-center justify-between border cursor-pointer transition-all ${
                    tenantId === "default-tenant"
                      ? "bg-zinc-900 border-zinc-800 text-zinc-100 font-bold"
                      : "bg-transparent border-transparent hover:bg-zinc-900/40 text-zinc-400"
                  }`}
                >
                  <span>1. default-tenant (Free)</span>
                  <span className="text-[10px] text-zinc-500 bg-zinc-950 px-1.5 py-0.5 rounded">Free</span>
                </button>
                <button
                  onClick={() => handleSwitchTenant("alpha-funds")}
                  className={`w-full text-left p-2 rounded text-xs font-mono flex items-center justify-between border cursor-pointer transition-all ${
                    tenantId === "alpha-funds"
                      ? "bg-zinc-900 border-zinc-800 text-zinc-100 font-bold"
                      : "bg-transparent border-transparent hover:bg-zinc-900/40 text-zinc-400"
                  }`}
                >
                  <span>2. alpha-funds (Pro)</span>
                  <span className="text-[10px] text-emerald-500 bg-zinc-950 px-1.5 py-0.5 rounded font-black">Pro</span>
                </button>
                <button
                  onClick={() => handleSwitchTenant("apex-institutional")}
                  className={`w-full text-left p-2 rounded text-xs font-mono flex items-center justify-between border cursor-pointer transition-all ${
                    tenantId === "apex-institutional"
                      ? "bg-zinc-900 border-zinc-800 text-zinc-100 font-bold"
                      : "bg-transparent border-transparent hover:bg-zinc-900/40 text-zinc-400"
                  }`}
                >
                  <span>3. apex-institutional (Apex)</span>
                  <span className="text-[10px] text-blue-500 bg-zinc-950 px-1.5 py-0.5 rounded font-black">Sovereign</span>
                </button>
              </div>

              {/* Form to create and register custom tenant */}
              <form onSubmit={handleCreateTenant} className="mt-4 pt-4 border-t border-zinc-900">
                <label className="text-[10px] text-zinc-500 font-mono font-bold block mb-1.5 uppercase">Register New Tenant ID</label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={customTenant}
                    onChange={(e) => setCustomTenant(e.target.value)}
                    placeholder="e.g. zenith-quant"
                    className="flex-1 bg-zinc-900 border border-zinc-800 focus:border-emerald-500 rounded px-2.5 py-1.5 text-xs font-mono outline-none text-zinc-200"
                  />
                  <button
                    type="submit"
                    className="bg-zinc-850 hover:bg-zinc-800 text-zinc-300 font-bold px-3 py-1.5 border border-zinc-800 rounded text-xs cursor-pointer"
                  >
                    Load
                  </button>
                </div>
              </form>
            </div>

          </div>
        </div>
      ) : (
        /* Developer Hub & Telemetry Tab - Scaled SaaS Developer Portal */
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          
          {/* Left Column: API Documentation & Key, plus Interactive Playground Sandbox */}
          <div className="lg:col-span-6 flex flex-col gap-6">
            
            {/* API Credentials and Key Section */}
            <div className="bg-zinc-950 border border-zinc-850 p-5 rounded-lg flex flex-col gap-4 font-mono text-xs">
              <div className="flex items-center justify-between border-b border-zinc-900 pb-3">
                <h4 className="text-xs font-bold text-zinc-200 flex items-center gap-1.5 uppercase tracking-wide">
                  <Code className="w-4 h-4 text-emerald-400" />
                  B2B API Authentication
                </h4>
                <span className="text-[9px] bg-emerald-950 text-emerald-400 font-bold px-2 py-0.5 rounded uppercase tracking-wider">
                  Active Credential
                </span>
              </div>

              <div className="flex flex-col gap-2">
                <span className="text-zinc-500 text-[10px] uppercase font-bold block">Developer API Key (Scoped to current Tenant)</span>
                <div className="bg-zinc-900 border border-zinc-850 p-2.5 rounded flex items-center justify-between gap-4 select-all">
                  <span className="text-emerald-400 font-mono text-[11px] font-bold">
                    {tenantId === "default-tenant" 
                      ? "key_free_default_12345" 
                      : tenantId === "alpha-funds" 
                      ? "key_pro_alpha_funds_abc987" 
                      : tenantId === "apex-institutional"
                      ? "key_apex_institutional_xyz777"
                      : `key_custom_${tenantId.replace(/-/g, "_")}_abc888`
                    }
                  </span>
                  <Key className="w-3.5 h-3.5 text-zinc-500 shrink-0" />
                </div>
                <span className="text-[10px] text-zinc-500 mt-0.5 leading-relaxed font-sans">
                  Use this token in the custom request header: <code className="text-zinc-300 bg-zinc-900 px-1 py-0.5 rounded">x-api-key</code> to interact with the versioned standalone verification engine.
                </span>
              </div>

              <div className="bg-zinc-900 p-3 rounded border border-zinc-850 text-[10px] leading-relaxed text-zinc-400 font-sans">
                <span className="text-zinc-300 font-bold block mb-1">API Endpoint Information:</span>
                <ul className="space-y-1.5 list-disc list-inside">
                  <li><strong className="text-zinc-300 font-mono">POST /api/v1/verify</strong> - Main gateway</li>
                  <li>Isolates risk metrics automatically using database-level tenancy.</li>
                  <li><strong className="text-rose-400">Gating Constraint:</strong> Restricted to Pro or Sovereign tenants only. Free key throws 403.</li>
                </ul>
              </div>
            </div>

            {/* Interactive B2B API Playground Terminal */}
            <div className="bg-zinc-950 border border-zinc-850 p-5 rounded-lg flex flex-col gap-4">
              <div>
                <h4 className="text-xs font-bold text-zinc-200 uppercase tracking-wide font-mono flex items-center gap-1.5">
                  <Terminal className="w-4 h-4 text-emerald-400" />
                  B2B Endpoint Execution Sandbox
                </h4>
                <p className="text-[10px] text-zinc-500 mt-1 font-sans">
                  Simulate external API queries directly. Select custom parameters below and trigger a raw B2B client request using the active tenant's key.
                </p>
              </div>

              {/* Form Controls for API payload simulator */}
              <div className="grid grid-cols-2 gap-3.5 font-mono text-[11px]">
                <div>
                  <label className="text-zinc-500 uppercase font-bold block mb-1 text-[9px]">Select Target Asset</label>
                  <select 
                    value={playAsset} 
                    onChange={(e) => {
                      const ast = e.target.value;
                      setPlayAsset(ast);
                      if (ast === "GBP/JPY") { setPlayPrice(204.65); setPlaySL(205.15); }
                      else if (ast === "USD/ZAR") { setPlayPrice(18.42); setPlaySL(18.55); }
                      else if (ast === "Gold") { setPlayPrice(2384.50); setPlaySL(2375.00); }
                      else { setPlayPrice(68450); setPlaySL(67900); }
                    }}
                    className="w-full bg-zinc-900 border border-zinc-800 rounded px-2 py-1.5 text-zinc-200 outline-none focus:border-emerald-500 cursor-pointer"
                  >
                    <option value="GBP/JPY">GBP/JPY (Forex)</option>
                    <option value="USD/ZAR">USD/ZAR (Hedge Exotic)</option>
                    <option value="Gold">Gold (Commodity)</option>
                    <option value="Bitcoin">Bitcoin (Digital Asset)</option>
                  </select>
                </div>

                <div>
                  <label className="text-zinc-500 uppercase font-bold block mb-1 text-[9px]">Execution Action</label>
                  <select 
                    value={playAction} 
                    onChange={(e) => setPlayAction(e.target.value as any)}
                    className="w-full bg-zinc-900 border border-zinc-800 rounded px-2 py-1.5 text-zinc-200 outline-none focus:border-emerald-500 cursor-pointer"
                  >
                    <option value="BUY">BUY (Long)</option>
                    <option value="SELL">SELL (Short)</option>
                  </select>
                </div>

                <div>
                  <label className="text-zinc-500 uppercase font-bold block mb-1 text-[9px]">Entry Price</label>
                  <input 
                    type="number" 
                    step="any"
                    value={playPrice} 
                    onChange={(e) => setPlayPrice(Number(e.target.value))}
                    className="w-full bg-zinc-900 border border-zinc-800 rounded px-2 py-1 text-zinc-200 outline-none focus:border-emerald-500 font-mono"
                  />
                </div>

                <div>
                  <label className="text-zinc-500 uppercase font-bold block mb-1 text-[9px]">Stop Loss</label>
                  <input 
                    type="number" 
                    step="any"
                    value={playSL} 
                    onChange={(e) => setPlaySL(Number(e.target.value))}
                    className="w-full bg-zinc-900 border border-zinc-800 rounded px-2 py-1 text-zinc-200 outline-none focus:border-emerald-500 font-mono"
                  />
                </div>
              </div>

              <button
                onClick={handleQueryPlayground}
                disabled={queryingApi}
                className="w-full bg-emerald-950 hover:bg-emerald-900 text-emerald-400 font-bold py-2 border border-emerald-800/40 rounded text-xs transition-all flex items-center justify-center gap-1.5 cursor-pointer"
              >
                {queryingApi ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    <span>Executing B2B verification logic...</span>
                  </>
                ) : (
                  <>
                    <Zap className="w-3.5 h-3.5" />
                    <span>Execute Simulated API Request</span>
                  </>
                )}
              </button>

              {/* API Sandbox Output block */}
              <div className="flex flex-col gap-1.5">
                <span className="text-zinc-500 font-mono font-bold uppercase text-[9px] block">Live JSON Response Output</span>
                <pre className="bg-zinc-950 text-zinc-300 font-mono text-[10px] p-3 rounded border border-zinc-850 overflow-x-auto max-h-[175px] leading-relaxed select-text select-all">
                  {apiResponse}
                </pre>
              </div>
            </div>

          </div>

          {/* Right Column: Telemetry Metering Dashboard & Webhook Logs */}
          <div className="lg:col-span-6 flex flex-col gap-6">
            
            {/* Telemetry counters & Invoice Estimation */}
            <div className="bg-zinc-950 border border-zinc-850 p-5 rounded-lg flex flex-col gap-5">
              <div className="flex items-center justify-between border-b border-zinc-900 pb-3">
                <div>
                  <h4 className="text-xs font-bold text-zinc-200 flex items-center gap-1.5 uppercase tracking-wide font-mono">
                    <Activity className="w-4 h-4 text-emerald-400" />
                    Usage-Based Metering
                  </h4>
                  <span className="text-[10px] text-zinc-500 font-mono font-bold uppercase block mt-1">Tenant ID: {tenantId}</span>
                </div>

                <div className="flex gap-2">
                  <button
                    onClick={handleDownloadCSV}
                    className="bg-zinc-900 hover:bg-zinc-850 text-zinc-300 font-bold px-2.5 py-1 rounded border border-zinc-800 font-sans text-[10px] cursor-pointer flex items-center gap-1.5"
                  >
                    Export CSV
                  </button>
                  <button
                    onClick={handleResetTelemetry}
                    className="bg-transparent hover:bg-zinc-900 text-rose-500 font-bold px-2.5 py-1 rounded font-sans text-[10px] cursor-pointer border border-transparent hover:border-rose-950/20"
                  >
                    Reset
                  </button>
                </div>
              </div>

              {/* Grid of live usage meters */}
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-zinc-900 border border-zinc-850/60 p-3 rounded">
                  <div className="flex items-center justify-between text-zinc-500 font-mono text-[9px] uppercase font-bold">
                    <span>Trades Verified</span>
                    <span className="text-zinc-600 font-mono">$0.15/ea</span>
                  </div>
                  <span className="text-xl font-mono font-black text-zinc-100 block mt-1.5">{telemetry.trades_verified}</span>
                  <div className="text-[10px] text-zinc-500 mt-1">
                    Invoice: ${(telemetry.trades_verified * 0.15).toFixed(2)}
                  </div>
                </div>

                <div className="bg-zinc-900 border border-zinc-850/60 p-3 rounded">
                  <div className="flex items-center justify-between text-zinc-500 font-mono text-[9px] uppercase font-bold">
                    <span>AI Signals</span>
                    <span className="text-zinc-600 font-mono">$0.05/ea</span>
                  </div>
                  <span className="text-xl font-mono font-black text-zinc-100 block mt-1.5">{telemetry.ai_signals_generated}</span>
                  <div className="text-[10px] text-zinc-500 mt-1">
                    Invoice: ${(telemetry.ai_signals_generated * 0.05).toFixed(2)}
                  </div>
                </div>

                <div className="bg-zinc-900 border border-zinc-850/60 p-3 rounded">
                  <div className="flex items-center justify-between text-zinc-500 font-mono text-[9px] uppercase font-bold">
                    <span>FinRL Backtests</span>
                    <span className="text-zinc-600 font-mono">$1.50/ea</span>
                  </div>
                  <span className="text-xl font-mono font-black text-zinc-100 block mt-1.5">{telemetry.backtests_run}</span>
                  <div className="text-[10px] text-zinc-500 mt-1">
                    Invoice: ${(telemetry.backtests_run * 1.50).toFixed(2)}
                  </div>
                </div>

                <div className="bg-zinc-900 border border-zinc-850/60 p-3 rounded">
                  <div className="flex items-center justify-between text-zinc-500 font-mono text-[9px] uppercase font-bold">
                    <span>B2B API Calls</span>
                    <span className="text-zinc-600 font-mono">$0.02/ea</span>
                  </div>
                  <span className="text-xl font-mono font-black text-zinc-100 block mt-1.5">{telemetry.api_calls}</span>
                  <div className="text-[10px] text-zinc-500 mt-1">
                    Invoice: ${(telemetry.api_calls * 0.02).toFixed(2)}
                  </div>
                </div>
              </div>

              {/* Billing Summary projected invoice */}
              <div className="bg-zinc-900/60 border border-zinc-850 p-4 rounded flex items-center justify-between">
                <div>
                  <span className="text-[10px] font-mono text-zinc-500 font-bold uppercase tracking-wider block">Projected Usage Invoice</span>
                  <span className="text-xs text-zinc-400 font-sans block mt-0.5">Accruing in real-time under multi-tenant metering policy</span>
                </div>
                <div className="text-right">
                  <span className="text-2xl font-mono font-black text-emerald-400 block">${invoice.toFixed(2)}</span>
                  <span className="text-[9px] text-zinc-500 uppercase font-mono block">USD (Current Cycle)</span>
                </div>
              </div>
            </div>

            {/* Simulated webhook operations logs container */}
            <div className="bg-zinc-950 border border-zinc-850 rounded-lg p-4 flex-1 flex flex-col min-h-[220px]">
              <div className="flex items-center justify-between border-b border-zinc-900 pb-2 mb-3">
                <span className="text-xs font-mono font-bold text-zinc-300 flex items-center gap-1.5">
                  <Activity className="w-3.5 h-3.5 text-blue-400 animate-pulse" />
                  Real-time Stripe Webhook Logging Bus
                </span>
                <button
                  onClick={() => setWebhookLogs([])}
                  className="text-[9px] font-mono text-zinc-500 hover:text-zinc-300 underline cursor-pointer"
                >
                  Clear Logs
                </button>
              </div>

              {webhookLogs.length === 0 ? (
                <div className="flex-1 flex flex-col items-center justify-center text-center text-zinc-600 font-mono text-[10px] py-8">
                  <span>Waiting for incoming Stripe events...</span>
                </div>
              ) : (
                <div className="space-y-2.5 max-h-[175px] overflow-y-auto pr-1">
                  {webhookLogs.map((log) => (
                    <div key={log.id} className="border border-zinc-850 bg-zinc-900 p-2.5 rounded font-mono text-[10px] leading-relaxed">
                      <div className="flex justify-between items-start gap-2">
                        <span className="text-emerald-400 font-bold">[{log.status}]</span>
                        <span className="text-zinc-500 text-[9px]">{log.time}</span>
                      </div>
                      <div className="text-zinc-200 font-semibold mt-1 font-mono">
                        Event: <span className="text-blue-400">{log.event}</span>
                      </div>
                      <div className="text-zinc-400 mt-1.5 leading-normal text-[11px] font-sans border-t border-zinc-850/40 pt-1.5">
                        {log.detail}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

          </div>

        </div>
      )}

      {activeTab === "accuracy" && (
        <div className="flex flex-col gap-6">
          
          {/* Main Top Metrics Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="bg-zinc-950 border border-zinc-850 p-4 rounded-lg flex flex-col justify-between relative overflow-hidden">
              <div className="absolute top-0 right-0 p-3 opacity-10">
                <Gauge className="w-16 h-16 text-emerald-400" />
              </div>
              <span className="text-[10px] font-mono font-bold uppercase text-zinc-500 tracking-wider">Aggregated Signal Accuracy</span>
              <div className="flex items-baseline gap-2 mt-2">
                <span className="text-3xl font-mono font-black text-emerald-400">
                  {adminAccuracy ? `${adminAccuracy.summary.overallAccuracy}%` : "0.0%"}
                </span>
                <span className="text-xs text-zinc-500 font-mono">system-wide win rate</span>
              </div>
              <p className="text-[11px] text-zinc-500 mt-2">
                Overall ratio of profitable signals across all tenants.
              </p>
            </div>

            <div className="bg-zinc-950 border border-zinc-850 p-4 rounded-lg flex flex-col justify-between relative overflow-hidden">
              <div className="absolute top-0 right-0 p-3 opacity-10">
                <CheckCircle className="w-16 h-16 text-emerald-400" />
              </div>
              <span className="text-[10px] font-mono font-bold uppercase text-zinc-500 tracking-wider">Profitable Verified Trades</span>
              <div className="flex items-baseline gap-2 mt-2">
                <span className="text-3xl font-mono font-black text-zinc-100">
                  {adminAccuracy ? adminAccuracy.summary.totalProfitable : "0"}
                </span>
                <span className="text-xs text-zinc-500">completed runs</span>
              </div>
              <p className="text-[11px] text-zinc-500 mt-2">
                Total signals that successfully closed in profit.
              </p>
            </div>

            <div className="bg-zinc-950 border border-zinc-850 p-4 rounded-lg flex flex-col justify-between relative overflow-hidden">
              <div className="absolute top-0 right-0 p-3 opacity-10">
                <HelpCircle className="w-16 h-16 text-zinc-500" />
              </div>
              <span className="text-[10px] font-mono font-bold uppercase text-zinc-500 tracking-wider">Losing Trade Logs</span>
              <div className="flex items-baseline gap-2 mt-2">
                <span className="text-3xl font-mono font-black text-rose-400">
                  {adminAccuracy ? adminAccuracy.summary.totalLosses : "0"}
                </span>
                <span className="text-xs text-zinc-500">exit violations</span>
              </div>
              <p className="text-[11px] text-zinc-500 mt-2">
                Signals stopped out or exited at a net loss.
              </p>
            </div>

            <div className="bg-zinc-950 border border-zinc-850 p-4 rounded-lg flex flex-col justify-between relative overflow-hidden">
              <span className="text-[10px] font-mono font-bold uppercase text-zinc-500 tracking-wider">Streak Blocker Safety Status</span>
              <div className="flex items-baseline gap-2 mt-2">
                <span className="text-sm font-mono font-bold bg-amber-955/40 border border-amber-900/50 text-amber-400 px-2.5 py-1 rounded">
                  Mandatory 1.5% Enabled
                </span>
              </div>
              <p className="text-[11px] text-zinc-500 mt-2">
                Hard-coded risk limitation enforced successfully at compile-time on all tenants.
              </p>
            </div>
          </div>

          {/* Line Chart & Model Optimizer Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
            
            {/* Left: AI Model Optimizer Parameter Console */}
            <div className="lg:col-span-4 bg-zinc-950 border border-zinc-850 rounded-lg p-5 flex flex-col justify-between">
              <div>
                <div className="flex items-center gap-2 border-b border-zinc-900 pb-3 mb-4">
                  <Settings2 className="w-4 h-4 text-emerald-400" />
                  <h3 className="text-xs font-bold uppercase tracking-wider font-mono text-zinc-200">AI Model Optimizer</h3>
                </div>
                
                <p className="text-xs text-zinc-500 mb-5 leading-relaxed">
                  Adjust active filter parameters for the main quantitative backend neural network to optimize win rates and signal fidelity.
                </p>

                <div className="flex flex-col gap-4">
                  {/* Model Selector */}
                  <div>
                    <label className="text-zinc-400 uppercase font-bold block mb-1 text-[9px] font-mono">Active Inference Backend</label>
                    <select 
                      value={modelSettings.modelSelection}
                      onChange={(e) => setModelSettings(prev => ({ ...prev, modelSelection: e.target.value }))}
                      className="w-full bg-zinc-900 border border-zinc-800 rounded px-2.5 py-1.5 text-zinc-300 outline-none focus:border-emerald-500 cursor-pointer text-xs"
                    >
                      <option value="gemini-1.5-pro">Gemini 1.5 Pro (Low Latency)</option>
                      <option value="gemini-2.5-flash">Gemini 2.5 Flash (SaaS Core)</option>
                      <option value="deepseek-r1">DeepSeek R1 (Deep Thinking)</option>
                      <option value="custom-finrl">Custom FinRL Ensemble (Multi-Agent)</option>
                    </select>
                  </div>

                  {/* Min Confidence Threshold slider */}
                  <div>
                    <div className="flex justify-between items-center text-[9px] font-mono uppercase text-zinc-400 mb-1">
                      <span>Min Confidence Filter</span>
                      <span className="text-emerald-400 font-bold">{modelSettings.minConfidenceFilter}%</span>
                    </div>
                    <input 
                      type="range" 
                      min="50" 
                      max="90" 
                      value={modelSettings.minConfidenceFilter}
                      onChange={(e) => setModelSettings(prev => ({ ...prev, minConfidenceFilter: Number(e.target.value) }))}
                      className="w-full accent-emerald-500 cursor-pointer"
                    />
                  </div>

                  {/* Inter-market Correlation toggle */}
                  <div className="flex items-center justify-between bg-zinc-900/50 p-2 border border-zinc-850 rounded">
                    <div>
                      <span className="text-[10px] font-bold text-zinc-300 block">Correlation Overrides</span>
                      <span className="text-[9px] text-zinc-500 leading-none">Auto-block high correlation exposure</span>
                    </div>
                    <button
                      onClick={() => setModelSettings(prev => ({ ...prev, correlationFilter: !prev.correlationFilter }))}
                      className={`px-3 py-1 font-mono text-[10px] font-bold rounded cursor-pointer transition-all ${
                        modelSettings.correlationFilter 
                          ? "bg-emerald-950 border border-emerald-800/60 text-emerald-400" 
                          : "bg-zinc-800 border border-zinc-700 text-zinc-400"
                      }`}
                    >
                      {modelSettings.correlationFilter ? "ENABLED" : "DISABLED"}
                    </button>
                  </div>

                  {/* RSI filter slider */}
                  <div>
                    <div className="flex justify-between items-center text-[9px] font-mono uppercase text-zinc-400 mb-1">
                      <span>RSI Extreme Boundary Filter</span>
                      <span className="text-emerald-400 font-bold">RSI &lt; {modelSettings.rsiThreshold} / &gt; {100 - modelSettings.rsiThreshold}</span>
                    </div>
                    <input 
                      type="range" 
                      min="15" 
                      max="35" 
                      value={modelSettings.rsiThreshold}
                      onChange={(e) => setModelSettings(prev => ({ ...prev, rsiThreshold: Number(e.target.value) }))}
                      className="w-full accent-emerald-500 cursor-pointer"
                    />
                  </div>

                  {/* News Sentiment Slider */}
                  <div>
                    <div className="flex justify-between items-center text-[9px] font-mono uppercase text-zinc-400 mb-1">
                      <span>Macro News Sentiment Weight</span>
                      <span className="text-emerald-400 font-bold">{modelSettings.newsSentimentWeight}%</span>
                    </div>
                    <input 
                      type="range" 
                      min="10" 
                      max="80" 
                      value={modelSettings.newsSentimentWeight}
                      onChange={(e) => setModelSettings(prev => ({ ...prev, newsSentimentWeight: Number(e.target.value) }))}
                      className="w-full accent-emerald-500 cursor-pointer"
                    />
                  </div>
                </div>
              </div>

              <div className="mt-6">
                <button
                  onClick={handleSaveModelSettings}
                  disabled={savingSettings}
                  className="w-full bg-emerald-500 hover:bg-emerald-400 text-zinc-950 font-bold py-2 border border-emerald-400/20 rounded text-xs transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  {savingSettings ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      <span>Applying model optimizations...</span>
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>Optimize Backend Models</span>
                    </>
                  )}
                </button>
                {settingsMsg && (
                  <p className="text-[10px] text-emerald-400 font-mono text-center mt-2 animate-pulse">{settingsMsg}</p>
                )}
              </div>
            </div>

            {/* Right: Cumulative Accuracy Trend Chart */}
            <div className="lg:col-span-8 bg-zinc-950 border border-zinc-850 rounded-lg p-5 flex flex-col gap-4">
              <div className="flex items-center justify-between border-b border-zinc-900 pb-3">
                <div className="flex items-center gap-2">
                  <TrendingUp className="w-4 h-4 text-emerald-400" />
                  <h3 className="text-xs font-bold uppercase tracking-wider font-mono text-zinc-200">Chronological Cumulative Accuracy Score Trend</h3>
                </div>
                <span className="text-[9px] font-mono text-zinc-500 uppercase">Updates live after every trade close</span>
              </div>

              <div className="h-[275px] w-full font-mono text-[10px]">
                {adminAccuracy && adminAccuracy.recentTrend && adminAccuracy.recentTrend.length > 0 ? (
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={adminAccuracy.recentTrend} margin={{ top: 10, right: 10, left: -25, bottom: 5 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#27272a" />
                      <XAxis dataKey="tradeIndex" stroke="#71717a" />
                      <YAxis domain={[0, 100]} stroke="#71717a" unit="%" />
                      <Tooltip
                        contentStyle={{ backgroundColor: "#09090b", borderColor: "#27272a", borderRadius: "6px" }}
                        labelStyle={{ color: "#a1a1aa", fontFamily: "monospace" }}
                        itemStyle={{ color: "#10b981", fontFamily: "monospace" }}
                        formatter={(value: any, name: any, props: any) => [
                          `${value}%`,
                          `Accuracy (Asset: ${props.payload.asset} | ${props.payload.isProfit ? "PROFIT" : "LOSS"})`
                        ]}
                      />
                      <Line 
                        type="monotone" 
                        dataKey="accuracy" 
                        stroke="#10b981" 
                        strokeWidth={2} 
                        dot={{ r: 4, stroke: "#10b981", strokeWidth: 1, fill: "#09090b" }}
                        activeDot={{ r: 6 }} 
                      />
                    </LineChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-zinc-600">
                    No completed trades found. Set exit price on trades in the ledger to populate accurate chronological records.
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Bottom Grid: Asset Stats and Tenant Performance Tables */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            
            {/* Asset Performance Breakdown */}
            <div className="bg-zinc-950 border border-zinc-850 rounded-lg p-5 flex flex-col gap-4">
              <div className="flex items-center gap-2 border-b border-zinc-900 pb-3">
                <BarChart2 className="w-4 h-4 text-emerald-400" />
                <h3 className="text-xs font-bold uppercase tracking-wider font-mono text-zinc-200">Asset-by-Asset Accuracy Scorecard</h3>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="border-b border-zinc-900 text-zinc-500 font-mono text-[9px] uppercase">
                      <th className="py-2">Asset Symbol</th>
                      <th className="py-2 text-center">Completed Signals</th>
                      <th className="py-2 text-center">Profitable Signals</th>
                      <th className="py-2 text-right">Accuracy Rate</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-zinc-900 font-mono">
                    {adminAccuracy && adminAccuracy.assetStats.map((stat, idx) => (
                      <tr key={idx} className="hover:bg-zinc-900/30">
                        <td className="py-2.5 font-sans font-semibold text-zinc-300">{stat.asset}</td>
                        <td className="py-2.5 text-center text-zinc-400">{stat.total}</td>
                        <td className="py-2.5 text-center text-zinc-400">{stat.profitable}</td>
                        <td className="py-2.5 text-right font-bold">
                          <span className={stat.accuracy >= 60 ? "text-emerald-400" : stat.accuracy >= 40 ? "text-amber-400" : "text-rose-400"}>
                            {stat.accuracy.toFixed(1)}%
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Tenant-by-Tenant Isolation Metrics */}
            <div className="bg-zinc-950 border border-zinc-850 rounded-lg p-5 flex flex-col gap-4">
              <div className="flex items-center gap-2 border-b border-zinc-900 pb-3">
                <Users className="w-4 h-4 text-emerald-400" />
                <h3 className="text-xs font-bold uppercase tracking-wider font-mono text-zinc-200">SaaS Multi-Tenant Performance Metrics</h3>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="border-b border-zinc-900 text-zinc-500 font-mono text-[9px] uppercase">
                      <th className="py-2">Tenant Entity ID</th>
                      <th className="py-2 text-center">Signals Evaluated</th>
                      <th className="py-2 text-center">Profitable Ratio</th>
                      <th className="py-2 text-right">Tenant Accuracy</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-zinc-900 font-mono">
                    {adminAccuracy && adminAccuracy.tenantStats.map((stat, idx) => (
                      <tr key={idx} className="hover:bg-zinc-900/30">
                        <td className="py-2.5 font-sans font-bold text-zinc-300 flex items-center gap-1.5">
                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                          {stat.tenantId}
                        </td>
                        <td className="py-2.5 text-center text-zinc-400">{stat.total}</td>
                        <td className="py-2.5 text-center text-zinc-400">{stat.profitable} / {stat.total}</td>
                        <td className="py-2.5 text-right font-bold">
                          <span className={stat.accuracy >= 60 ? "text-emerald-400" : stat.accuracy >= 40 ? "text-amber-400" : "text-rose-400"}>
                            {stat.accuracy.toFixed(1)}%
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

          </div>

        </div>
      )}

    </div>
  );
}
