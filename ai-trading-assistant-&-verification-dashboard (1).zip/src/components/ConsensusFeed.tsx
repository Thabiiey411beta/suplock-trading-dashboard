import React, { useState } from "react";
import { AIConsensusSignal } from "../types";
import DrillDownChart from "./DrillDownChart";
import { TrendingUp, TrendingDown, ChevronDown, ChevronUp, Clock, AlertTriangle, Cpu, Layers } from "lucide-react";

interface ConsensusFeedProps {
  signals: AIConsensusSignal[];
  onSelectSignalForRisk?: (signal: AIConsensusSignal) => void;
  selectedSignalId?: string;
}

export default function ConsensusFeed({ signals, onSelectSignalForRisk, selectedSignalId }: ConsensusFeedProps) {
  const [expandedSignalId, setExpandedSignalId] = useState<string | null>("sig_btc_1");
  const [filter, setFilter] = useState<"ALL" | "LONG" | "SHORT">("ALL");

  const toggleExpand = (id: string) => {
    setExpandedSignalId(prev => (prev === id ? null : id));
  };

  const filteredSignals = signals.filter(sig => {
    if (filter === "ALL") return true;
    return sig.action === filter;
  });

  return (
    <div id="ai-consensus-feed-panel" className="bg-zinc-900 border border-zinc-850 p-5 rounded-xl flex flex-col gap-5 h-full shadow-lg">
      
      {/* Panel Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-zinc-800 pb-4">
        <div className="flex items-center gap-2">
          <Layers className="w-4 h-4 text-emerald-400" />
          <div>
            <h2 className="text-xs font-mono font-bold uppercase text-zinc-400 tracking-wider">
              II. SIGNAL COMMAND CENTER
            </h2>
            <p className="text-[10px] text-zinc-500 font-mono mt-0.5">
              CONSENSUS STREAM &bull; SUPERVISOR ROUTER
            </p>
          </div>
        </div>

        {/* Filters */}
        <div className="flex bg-zinc-950 border border-zinc-850 p-0.5 rounded-lg shrink-0 self-start sm:self-auto">
          {["ALL", "LONG", "SHORT"].map((type) => (
            <button
              key={type}
              onClick={() => setFilter(type as any)}
              className={`px-3 py-1 text-[10px] font-mono font-bold rounded-md transition-all cursor-pointer ${
                filter === type
                  ? "bg-zinc-800 text-zinc-100 shadow"
                  : "text-zinc-500 hover:text-zinc-300"
              }`}
            >
              {type}
            </button>
          ))}
        </div>
      </div>

      {/* Signals Feed List */}
      <div className="flex flex-col gap-3 overflow-y-auto max-h-[640px] pr-1 scrollbar-thin">
        {filteredSignals.length === 0 ? (
          <div className="text-center py-12 border border-dashed border-zinc-800 rounded-lg bg-zinc-950/20">
            <Cpu className="w-8 h-8 text-zinc-600 animate-pulse mx-auto mb-3" />
            <span className="text-xs font-mono font-bold text-zinc-500">
              No matching consensus signals found in queue.
            </span>
          </div>
        ) : (
          filteredSignals.map((sig) => {
            const isExpanded = expandedSignalId === sig.id;
            const isLong = sig.action === "LONG";
            const isSelectedForRisk = selectedSignalId === sig.id;

            return (
              <div
                key={sig.id}
                className={`border rounded-xl transition-all overflow-hidden ${
                  isExpanded 
                    ? "bg-zinc-950/40 border-zinc-700/80 shadow-md" 
                    : "bg-zinc-900/50 border-zinc-850 hover:border-zinc-800 hover:bg-zinc-950/20"
                } ${isSelectedForRisk ? "ring-1 ring-emerald-500/50" : ""}`}
              >
                {/* Card Main Block */}
                <div
                  onClick={() => toggleExpand(sig.id)}
                  className="p-4 flex items-center justify-between gap-4 cursor-pointer select-none"
                >
                  <div className="flex items-center gap-3.5 min-w-0">
                    {/* Action Indicator Icon */}
                    <div className={`p-2.5 rounded-lg border shrink-0 ${
                      isLong 
                        ? "bg-emerald-950/35 border-emerald-900/35 text-emerald-400" 
                        : "bg-rose-950/35 border-rose-900/35 text-rose-400"
                    }`}>
                      {isLong ? (
                        <TrendingUp className="w-5 h-5" />
                      ) : (
                        <TrendingDown className="w-5 h-5" />
                      )}
                    </div>

                    {/* Ticker and Setup Type */}
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-extrabold text-zinc-100 tracking-tight">
                          ${sig.asset.replace("-USD", "")}
                        </span>
                        <span className={`text-[9px] font-mono font-extrabold px-2 py-0.5 rounded ${
                          isLong ? "bg-emerald-950 text-emerald-400" : "bg-rose-950 text-rose-400"
                        }`}>
                          {sig.action}
                        </span>
                      </div>
                      <span className="text-xs text-zinc-400 mt-0.5 block truncate">
                        {sig.setupType}
                      </span>
                    </div>
                  </div>

                  {/* Confidence Gauge and Interactive Chevron */}
                  <div className="flex items-center gap-4 shrink-0">
                    <div className="text-right hidden sm:block">
                      <div className="flex items-center justify-end gap-1">
                        <Cpu className="w-3.5 h-3.5 text-teal-400" />
                        <span className="text-xs font-mono font-bold text-zinc-300">
                          {sig.confidenceScore}% Match
                        </span>
                      </div>
                      {/* confidence mini-bar */}
                      <div className="w-24 h-1.5 bg-zinc-800 rounded-full overflow-hidden mt-1 ml-auto">
                        <div
                          className={`h-full rounded-full transition-all duration-1000 ${
                            sig.confidenceScore >= 85 ? "bg-emerald-500" : "bg-teal-500"
                          }`}
                          style={{ width: `${sig.confidenceScore}%` }}
                        />
                      </div>
                    </div>

                    <div className="text-zinc-500 p-1 hover:text-zinc-300">
                      {isExpanded ? (
                        <ChevronUp className="w-4 h-4" />
                      ) : (
                        <ChevronDown className="w-4 h-4" />
                      )}
                    </div>
                  </div>
                </div>

                {/* Expanded Details / Drill Down */}
                {isExpanded && (
                  <div className="border-t border-zinc-850 p-4 bg-zinc-950/20 flex flex-col gap-4 animate-fadeIn">
                    
                    {/* Sentence Justification from Supervisor Router */}
                    <div className="bg-zinc-900/60 border border-zinc-850 p-3 rounded-lg flex gap-2.5 items-start">
                      <AlertTriangle className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                      <div className="text-xs text-zinc-300 leading-relaxed font-sans">
                        <strong className="text-zinc-400 block font-mono text-[10px] uppercase mb-0.5">
                          Consensus Justification
                        </strong>
                        {sig.justification}
                      </div>
                    </div>

                    {/* Drill Down Chart Container */}
                    <DrillDownChart
                      asset={sig.asset}
                      entryZone={sig.entryZone}
                      takeProfit={sig.takeProfit}
                      stopLoss={sig.stopLoss}
                      action={sig.action}
                    />

                    {/* Quick Risk Management Activation Button */}
                    {onSelectSignalForRisk && (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onSelectSignalForRisk(sig);
                        }}
                        className={`w-full py-2.5 px-4 font-mono font-bold text-xs uppercase rounded-lg border cursor-pointer transition-all flex items-center justify-center gap-2 ${
                          isSelectedForRisk
                            ? "bg-emerald-950 border-emerald-500/40 text-emerald-400"
                            : "bg-zinc-900 hover:bg-zinc-850 border-zinc-800 text-zinc-300 hover:text-zinc-100"
                        }`}
                      >
                        <Cpu className="w-4 h-4" />
                        <span>
                          {isSelectedForRisk ? "Selected in Position Sizer" : "Load into Risk Manager"}
                        </span>
                      </button>
                    )}

                  </div>
                )}
              </div>
            );
          })
        )}
      </div>

    </div>
  );
}
