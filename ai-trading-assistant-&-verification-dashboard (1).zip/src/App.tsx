import React, { useState, useEffect } from "react";
import { Signal, MarketQuote, VerificationState } from "./types";
import MarketTicker from "./components/MarketTicker";
import SignalTerminal from "./components/SignalTerminal";
import { wsManager, ConnectionStatus } from "./lib/websocket";
import VerificationChecklist from "./components/VerificationChecklist";
import ConfirmationSandbox from "./components/ConfirmationSandbox";
import TradingLog, { TradingLogEntry } from "./components/TradingLog";
import D3Heatmap from "./components/D3Heatmap";
import CorrelationMatrix from "./components/CorrelationMatrix";
import { SubscriptionProvider, useSubscription } from "./SubscriptionContext";
import SubscriptionPanel from "./components/SubscriptionPanel";
import AISignalDashboard from "./components/AISignalDashboard";
import { TradingDashboard } from "../apps/trading-dashboard/src/components/TradingDashboard";
import { 
  Terminal, 
  TrendingUp, 
  ShieldAlert, 
  Activity, 
  HelpCircle,
  TrendingDown,
  Coins,
  RefreshCw,
  Sliders,
  CheckCircle,
  FileCheck,
  Cpu
} from "lucide-react";

export default function App() {
  return (
    <SubscriptionProvider>
      <Dashboard />
    </SubscriptionProvider>
  );
}

function Dashboard() {
  const { tenantId } = useSubscription();
  const [activeTab, setActiveTab] = useState<"commandCenter" | "verifier" | "telemetry">("telemetry");
  const [quotes, setQuotes] = useState<MarketQuote[]>([]);
  const [signals, setSignals] = useState<Signal[]>([]);
  const [selectedSignal, setSelectedSignal] = useState<Signal | null>(null);
  
  // Volatility rolling averages and active warning overlay state
  const [volatilityAverages, setVolatilityAverages] = useState<Record<string, { count: number; ema: number }>>({});
  const [activeVolatilityAlert, setActiveVolatilityAlert] = useState<any>(null);
  
  // Verification states for each signal stored by signal ID
  const [verifications, setVerifications] = useState<Record<string, VerificationState>>({});
  
  const [verifiedSignals, setVerifiedSignals] = useState<Record<string, boolean>>({});
  const [discardedSignals, setDiscardedSignals] = useState<Record<string, boolean>>({});

  // Trading Log State backed by multi-tenant backend
  const [tradingLog, setTradingLog] = useState<TradingLogEntry[]>([]);
  const [loadingLog, setLoadingLog] = useState<boolean>(false);

  // Fetch tenant-specific trade journal from backend
  const fetchTradingLog = async () => {
    setLoadingLog(true);
    try {
      const res = await fetch(`/api/trades?tenantId=${encodeURIComponent(tenantId)}`, {
        headers: { "x-tenant-id": tenantId }
      });
      const data = await res.json();
      if (data.success && Array.isArray(data.entries)) {
        setTradingLog(data.entries);
      }
    } catch (err) {
      console.error("Error loading multi-tenant trading log:", err);
    } finally {
      setLoadingLog(false);
    }
  };

  const [loadingRates, setLoadingRates] = useState<boolean>(true);
  const [loadingSignals, setLoadingSignals] = useState<boolean>(true);
  const [engine, setEngine] = useState<string>("Local Quantitative Engine");
  const [aiGenerated, setAiGenerated] = useState<boolean>(false);
  const [wsStatus, setWsStatus] = useState<ConnectionStatus>("DISCONNECTED");
  const [latencyMetrics, setLatencyMetrics] = useState<any>(null);

  // Keep manual triggers as backup, but WebSockets handle the bulk of real-time ingestion
  const fetchMarketRates = async () => {
    setLoadingRates(true);
    try {
      const res = await fetch(`/api/market-data?tenantId=${encodeURIComponent(tenantId)}`, {
        headers: { "x-tenant-id": tenantId }
      });
      const data = await res.json();
      if (data.success && Array.isArray(data.quotes)) {
        setQuotes(data.quotes);
      }
    } catch (err) {
      console.error("Error loading live rates:", err);
    } finally {
      setLoadingRates(false);
    }
  };

  // Fetch signals
  const fetchSignals = async () => {
    setLoadingSignals(true);
    try {
      const res = await fetch(`/api/signals?tenantId=${encodeURIComponent(tenantId)}`, {
        headers: { "x-tenant-id": tenantId }
      });
      const data = await res.json();
      if (data.success && Array.isArray(data.signals)) {
        setSignals(data.signals);
        setEngine(data.engine || "Gemini 3.5 Multi-Agent Model");
        setAiGenerated(!!data.aiGenerated);
        if (data.metrics) {
          setLatencyMetrics(data.metrics);
        }

        // Pre-initialize empty verification states for the loaded signals
        const initialStates: Record<string, VerificationState> = {};
        data.signals.forEach((sig: Signal) => {
          initialStates[sig.id] = {
            sentimentChecked: false,
            correlationChecked: false,
            probabilityChecked: false,
            riskCalculated: false,
            accountBalance: 10000,
            calculatedPositionSize: 0,
            riskAmount: 150,
            riskPercent: 1.5,
            pipsRisked: 0
          };
        });
        setVerifications(initialStates);
      }
    } catch (err) {
      console.error("Error loading AI signals:", err);
    } finally {
      setLoadingSignals(false);
    }
  };

  useEffect(() => {
    // 1. Initial REST fetch for trading log
    fetchTradingLog();

    // 2. Start WebSocket client manager
    wsManager.connect();

    // 3. Register subscriptions
    const unsubscribeStatus = wsManager.onStatusChange((status) => {
      setWsStatus(status);
    });

    const unsubscribeInitialQuotes = wsManager.onInitialQuotes((initialQuotes) => {
      setQuotes(initialQuotes);
      setLoadingRates(false);
    });

    const unsubscribeTick = wsManager.onTick((tick) => {
      setQuotes(prevQuotes => {
        const index = prevQuotes.findIndex(q => q.symbol === tick.symbol);
        if (index !== -1) {
          const updated = [...prevQuotes];
          updated[index] = {
            ...updated[index],
            price: tick.price,
            change: tick.change,
            changePercent: tick.changePercent,
            rsi: tick.rsi,
            sma5: tick.sma5,
            sma10: tick.sma10,
            volatility: tick.volatility
          };
          return updated;
        } else {
          return [...prevQuotes, tick];
        }
      });

      // Track volatility moving averages and find significant deviations!
      if (tick && tick.symbol && typeof tick.volatility === "number") {
        setVolatilityAverages(prev => {
          const prevRecord = prev[tick.symbol] || { count: 0, ema: tick.volatility };
          const count = prevRecord.count + 1;
          
          // Exponential moving average: slowly adjusts (simulating a 24-hour moving baseline)
          const alpha = count < 5 ? 1 / count : 0.03;
          const newEma = prevRecord.ema * (1 - alpha) + tick.volatility * alpha;

          // Compute deviation
          const deviation = Math.abs(tick.volatility - prevRecord.ema) / (prevRecord.ema || 0.01);

          // Trigger warning overlay if deviation is greater than 30% and we have some historical data
          if (count > 3 && deviation > 0.30) {
            const assetName = tick.name || tick.symbol;
            setActiveVolatilityAlert({
              id: `${tick.symbol}-${Date.now()}`,
              asset: assetName,
              symbol: tick.symbol,
              currentVol: tick.volatility,
              baselineVol: prevRecord.ema,
              deviationPercent: Math.round(deviation * 100),
              timestamp: Date.now()
            });
          }

          return {
            ...prev,
            [tick.symbol]: { count, ema: newEma }
          };
        });
      }
    });

    const unsubscribeSignals = wsManager.onSignals((payload) => {
      if (payload.signals && Array.isArray(payload.signals)) {
        setSignals(payload.signals);
        setEngine(payload.engine);
        setAiGenerated(!!payload.aiGenerated);
        if (payload.metrics) {
          setLatencyMetrics(payload.metrics);
        }
        setLoadingSignals(false);

        setVerifications(prev => {
          const next = { ...prev };
          payload.signals.forEach((sig: Signal) => {
            if (!next[sig.id]) {
              next[sig.id] = {
                sentimentChecked: false,
                correlationChecked: false,
                probabilityChecked: false,
                riskCalculated: false,
                accountBalance: 10000,
                calculatedPositionSize: 0,
                riskAmount: 150,
                riskPercent: 1.5,
                pipsRisked: 0
              };
            }
          });
          return next;
        });
      }
    });

    // Initial signals fetch
    fetchSignals();

    return () => {
      unsubscribeStatus();
      unsubscribeInitialQuotes();
      unsubscribeTick();
      unsubscribeSignals();
      wsManager.disconnect();
    };
  }, [tenantId]);

  // Set selected signal and reset / read its verification parameters
  const handleSelectSignal = (sig: Signal) => {
    setSelectedSignal(sig);
  };

  // Update verification parameters for current active signal
  const handleUpdateVerification = (updatedState: Partial<VerificationState>) => {
    if (!selectedSignal) return;
    setVerifications(prev => ({
      ...prev,
      [selectedSignal.id]: {
        ...prev[selectedSignal.id],
        ...updatedState
      }
    }));
  };

  // Confirm signal verification, mark as confirmed, and close
  const handleConfirmSignal = () => {
    if (!selectedSignal) return;
    setVerifiedSignals(prev => ({ ...prev, [selectedSignal.id]: true }));

    const activeVer = verifications[selectedSignal.id] || {
      calculatedPositionSize: 0,
      riskAmount: 150,
    };
    const exitPricePlaceholder = selectedSignal.takeProfit ? String(selectedSignal.takeProfit) : "Exit price";

    const newEntry = {
      id: `${selectedSignal.id}_${Date.now()}`,
      asset: selectedSignal.asset,
      action: selectedSignal.action,
      entryPrice: selectedSignal.price,
      exitPricePlaceholder,
      timestamp: new Date().toISOString(),
      positionSize: activeVer.calculatedPositionSize || 0.1,
      riskAmount: activeVer.riskAmount || 150
    };

    // Save to tenant-isolated database (encrypted at rest)
    fetch("/api/trades", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-tenant-id": tenantId
      },
      body: JSON.stringify({ tenantId, entry: newEntry })
    })
    .then(res => res.json())
    .then(data => {
      if (data.success && data.entry) {
        setTradingLog(prev => [data.entry, ...prev]);
      }
    })
    .catch(err => console.error("Failed to commit trade:", err));

    // Deselect signal after successfully copying execution data
    setTimeout(() => {
      setSelectedSignal(null);
    }, 1500);
  };

  const handleUpdateExitPrice = (id: string, exitPrice: number) => {
    fetch(`/api/trades/${id}`, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
        "x-tenant-id": tenantId
      },
      body: JSON.stringify({ tenantId, exitPrice })
    })
    .then(res => res.json())
    .then(data => {
      if (data.success) {
        setTradingLog(prev => prev.map(entry => {
          if (entry.id === id) {
            return { ...entry, exitPrice };
          }
          return entry;
        }));
      }
    })
    .catch(err => console.error("Failed to update exit price:", err));
  };

  const handleUpdateNotes = (id: string, notes: string) => {
    fetch(`/api/trades/${id}`, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
        "x-tenant-id": tenantId
      },
      body: JSON.stringify({ tenantId, notes })
    })
    .then(res => res.json())
    .then(data => {
      if (data.success) {
        setTradingLog(prev => prev.map(entry => {
          if (entry.id === id) {
            return { ...entry, notes };
          }
          return entry;
        }));
      }
    })
    .catch(err => console.error("Failed to update notes:", err));
  };

  const handleClearLog = () => {
    fetch("/api/trades/clear", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-tenant-id": tenantId
      },
      body: JSON.stringify({ tenantId })
    })
    .then(res => res.json())
    .then(data => {
      if (data.success) {
        setTradingLog([]);
      }
    })
    .catch(err => console.error("Failed to clear trades:", err));
  };

  // Discard signal
  const handleDiscardSignal = () => {
    if (!selectedSignal) return;
    setDiscardedSignals(prev => ({ ...prev, [selectedSignal.id]: true }));
    setSelectedSignal(null);
  };

  // Get current active verification state
  const activeVerification = selectedSignal 
    ? verifications[selectedSignal.id] 
    : {
        sentimentChecked: false,
        correlationChecked: false,
        probabilityChecked: false,
        riskCalculated: false,
        accountBalance: 10000,
        calculatedPositionSize: 0,
        riskAmount: 150,
        riskPercent: 1.5,
        pipsRisked: 0
      };

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100 flex flex-col font-sans selection:bg-emerald-500/30">
      {/* 1. TOP TICKER BAR */}
      <MarketTicker 
        quotes={quotes} 
        loading={loadingRates} 
        onRefresh={fetchMarketRates} 
        engine={engine}
        wsStatus={wsStatus}
        latencyMetrics={latencyMetrics}
      />

      {/* Tab Navigation Switcher */}
      <div id="dashboard-tab-navigator" className="max-w-7xl w-full mx-auto px-4 md:px-6 pt-5 flex items-center justify-between border-b border-zinc-900 pb-3 gap-4">
        <div className="flex items-center gap-1 bg-zinc-900/80 border border-zinc-850 p-1 rounded-xl shadow-inner">
          <button
            onClick={() => setActiveTab("commandCenter")}
            className={`px-4 py-2 rounded-lg text-xs font-mono font-bold transition-all flex items-center gap-2 cursor-pointer ${
              activeTab === "commandCenter"
                ? "bg-zinc-800 text-zinc-100 shadow-md border border-zinc-700/40"
                : "text-zinc-400 hover:text-zinc-200"
            }`}
          >
            <Cpu className="w-4 h-4 text-emerald-400 animate-pulse" />
            <span>AI Signal Command Center</span>
          </button>
          
          <button
            onClick={() => setActiveTab("verifier")}
            className={`px-4 py-2 rounded-lg text-xs font-mono font-bold transition-all flex items-center gap-2 cursor-pointer ${
              activeTab === "verifier"
                ? "bg-zinc-800 text-zinc-100 shadow-md border border-zinc-700/40"
                : "text-zinc-400 hover:text-zinc-200"
            }`}
          >
            <Sliders className="w-4 h-4 text-rose-400" />
            <span>Manual Verification Sandbox</span>
          </button>
          
          <button
            onClick={() => setActiveTab("telemetry")}
            className={`px-4 py-2 rounded-lg text-xs font-mono font-bold transition-all flex items-center gap-2 cursor-pointer ${
              activeTab === "telemetry"
                ? "bg-zinc-800 text-zinc-100 shadow-md border border-zinc-700/40"
                : "text-zinc-400 hover:text-zinc-200"
            }`}
          >
            <Activity className="w-4 h-4 text-blue-400" />
            <span>Phase 3 Cockpit</span>
          </button>
        </div>

        <div className="hidden sm:flex items-center gap-2 text-[11px] font-mono font-bold text-zinc-500">
          <span>Active Pipeline:</span>
          <span className="text-emerald-400 bg-emerald-950/25 px-2.5 py-1 rounded border border-emerald-900/30">
            {engine}
          </span>
        </div>
      </div>

      {activeTab === "telemetry" ? (
        <div className="flex-1 w-full flex flex-col">
          <TradingDashboard />
        </div>
      ) : activeTab === "commandCenter" ? (
        <div className="max-w-7xl w-full mx-auto p-4 md:p-6 flex flex-col gap-6">
          {/* Multi-Tenant SaaS Billing and Webhook Control Panel */}
          <SubscriptionPanel />
          
          <AISignalDashboard />
        </div>
      ) : (
        <main className="flex-1 max-w-7xl w-full mx-auto p-4 md:p-6 grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          
          {/* Multi-Tenant SaaS Billing and Webhook Control Panel */}
          <SubscriptionPanel />
          
          {/* Left column: Signal Feed Terminal (takes 7 cols when selected, full-width otherwise) */}
          <div className={`${selectedSignal ? "lg:col-span-7" : "lg:col-span-12"} flex flex-col gap-6 transition-all`}>
            
            {/* Streak Blocker Info Banner */}
            <div className="bg-zinc-900 border border-zinc-850 p-5 rounded-lg flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
              <div className="flex gap-3.5 items-start">
                <div className="bg-rose-950/50 border border-rose-900/30 p-2.5 rounded text-rose-400">
                  <ShieldAlert className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="text-sm font-bold text-zinc-200 uppercase tracking-wide">Manual Trade Execution Verifier</h2>
                  <p className="text-xs text-zinc-400 mt-1 max-w-lg leading-relaxed">
                    Losing streaks are caused by over-leveraging and emotional, unhedged entries. This sandboxed validator acts as your ultimate execution roadblock—ensuring exact 1.5% capital protection and macro alignment.
                  </p>
                </div>
              </div>
              
              <button 
                onClick={fetchSignals} 
                disabled={loadingSignals}
                className="flex items-center gap-1.5 bg-emerald-950/60 hover:bg-emerald-900 text-emerald-400 font-bold text-xs px-3.5 py-2 rounded border border-emerald-900/40 transition-all disabled:opacity-50 cursor-pointer self-start md:self-auto shrink-0"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${loadingSignals ? "animate-spin" : ""}`} />
                <span>Regenerate AI Signals</span>
              </button>
            </div>

            {/* Core Signal Terminal */}
            {loadingSignals && signals.length === 0 ? (
              <div className="bg-zinc-900 border border-zinc-850 rounded-lg p-12 text-center flex flex-col items-center justify-center gap-4">
                <RefreshCw className="w-8 h-8 text-emerald-400 animate-spin" />
                <p className="text-sm text-zinc-400 font-mono">Running FinRobot and FinRL quantitative multi-agent models to formulate entry boundaries...</p>
              </div>
            ) : (
              <SignalTerminal
                signals={signals}
                selectedSignal={selectedSignal}
                onSelectSignal={handleSelectSignal}
                verifiedSignals={verifiedSignals}
                discardedSignals={discardedSignals}
                activeVolatilityAlert={activeVolatilityAlert}
                onDismissVolatilityAlert={() => setActiveVolatilityAlert(null)}
              />
            )}

            {/* Quick Stats Panel */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="bg-zinc-900/40 border border-zinc-850 p-4 rounded-lg flex items-center justify-between">
                <div>
                  <span className="text-zinc-500 uppercase text-[10px] tracking-wider font-mono font-bold block">Active Signals</span>
                  <span className="text-lg font-bold text-zinc-200 mt-1 block font-mono">
                    {signals.filter(s => !verifiedSignals[s.id] && !discardedSignals[s.id]).length}
                  </span>
                </div>
                <Activity className="w-5 h-5 text-blue-400" />
              </div>

              <div className="bg-zinc-900/40 border border-zinc-850 p-4 rounded-lg flex items-center justify-between">
                <div>
                  <span className="text-zinc-500 uppercase text-[10px] tracking-wider font-mono font-bold block">Signals Verified</span>
                  <span className="text-lg font-bold text-emerald-400 mt-1 block font-mono">
                    {Object.keys(verifiedSignals).length}
                  </span>
                </div>
                <CheckCircle className="w-5 h-5 text-emerald-400" />
              </div>

              <div className="bg-zinc-900/40 border border-zinc-850 p-4 rounded-lg flex items-center justify-between">
                <div>
                  <span className="text-zinc-500 uppercase text-[10px] tracking-wider font-mono font-bold block">Losing Streaks Stopped</span>
                  <span className="text-lg font-bold text-rose-400 mt-1 block font-mono">
                    {Object.keys(discardedSignals).length + Object.keys(verifiedSignals).length}
                  </span>
                </div>
                <FileCheck className="w-5 h-5 text-rose-400" />
              </div>
            </div>

            {/* Multi-Timeframe Signal Heatmap */}
            <D3Heatmap signals={signals} quotes={quotes} />

            {/* Multi-Asset Correlation Matrix */}
            <CorrelationMatrix quotes={quotes} />

            {/* Persistent Live Trading Log */}
            <TradingLog
              entries={tradingLog}
              onUpdateExitPrice={handleUpdateExitPrice}
              onUpdateNotes={handleUpdateNotes}
              onClearLog={handleClearLog}
            />
          </div>

          {/* Right column: Interactive Verification Checklist & Sandbox */}
          {selectedSignal ? (
            <div className="lg:col-span-5 flex flex-col gap-6 sticky top-6">
              
              {/* Active Checklist State Card */}
              <div className="bg-zinc-950 border border-zinc-850 p-4 rounded-lg flex items-center justify-between">
                <div>
                  <span className="text-[10px] font-mono text-zinc-500 font-bold uppercase tracking-wider">Verifying active signal</span>
                  <h3 className="text-base font-bold text-zinc-100 flex items-center gap-1.5 mt-0.5">
                    {selectedSignal.asset}
                    <span className={`text-[10px] px-2 py-0.5 rounded font-mono font-bold ${
                      selectedSignal.action === "BUY" ? "bg-emerald-950 text-emerald-400" : "bg-rose-950 text-rose-400"
                    }`}>
                      {selectedSignal.action} @ {selectedSignal.price}
                    </span>
                  </h3>
                </div>
                
                <button 
                  onClick={() => setSelectedSignal(null)}
                  className="text-xs text-zinc-500 hover:text-zinc-300 font-mono transition-colors border border-zinc-850 hover:border-zinc-800 px-2.5 py-1 rounded cursor-pointer"
                >
                  Cancel Verify
                </button>
              </div>

              {/* Checklist */}
              <VerificationChecklist
                signal={selectedSignal}
                verification={activeVerification}
                onUpdateVerification={handleUpdateVerification}
              />

              {/* Sandbox Confirmation Button Controls */}
              <ConfirmationSandbox
                signal={selectedSignal}
                verification={activeVerification}
                onConfirm={handleConfirmSignal}
                onDiscard={handleDiscardSignal}
              />

            </div>
          ) : (
            <div className="lg:col-span-5 hidden lg:flex flex-col gap-5 justify-center items-center h-full min-h-[450px] border border-dashed border-zinc-800 rounded-lg text-center p-8 bg-zinc-900/10 select-none">
              <div className="bg-zinc-900 border border-zinc-800 p-4 rounded-full text-zinc-500 animate-pulse">
                <Terminal className="w-8 h-8" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-zinc-300">No Signal Selected For Verification</h3>
                <p className="text-xs text-zinc-500 mt-2 max-w-xs leading-relaxed font-sans mx-auto">
                  Select any active trade signal from the feed terminal. This will launch the multi-agent macro and probability hedging verification flow.
                </p>
              </div>
            </div>
          )}

        </main>
      )}

      {/* Footer */}
      <footer className="w-full bg-zinc-950 border-t border-zinc-900 p-4 text-center text-[11px] font-mono text-zinc-500">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2.5">
          <span>AI Trading Assistant & Verification Dashboard &copy; {new Date().getFullYear()}</span>
          <span className="text-zinc-600">Built using FinRobot Multi-Agent and FinRL Confidence Models</span>
        </div>
      </footer>
    </div>
  );
}
