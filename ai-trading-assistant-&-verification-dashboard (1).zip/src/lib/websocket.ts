/**
 * WebSocketManager
 * High-performance, resilient WebSocket client manager for real-time market data streaming.
 * Handles auto-reconnect, status notifications, and sub-100ms tick updates.
 */

export type ConnectionStatus = "CONNECTING" | "CONNECTED" | "DISCONNECTED";

export class WebSocketManager {
  private socket: WebSocket | null = null;
  private statusListeners: Set<(status: ConnectionStatus) => void> = new Set();
  private tickListeners: Set<(tick: any) => void> = new Set();
  private signalsListeners: Set<(payload: any) => void> = new Set();
  private initialQuotesListeners: Set<(quotes: any[]) => void> = new Set();

  private status: ConnectionStatus = "DISCONNECTED";
  private reconnectAttempts = 0;
  private maxReconnectAttempts = 10;
  private reconnectDelay = 1000; // ms
  private forcedClose = false;
  private pingInterval: any = null;
  
  // Resilient Polling Fallback variables
  private pollingInterval: any = null;
  private isPollingActive = false;

  constructor() {
    // Lazy instantiation or eager instantiation is fine. We will connect when asked.
  }

  private startFallbackPolling() {
    if (this.isPollingActive) return;
    this.isPollingActive = true;
    console.log("[WS MANAGER] WebSocket connection is down/unreachable. Activating high-performance HTTP polling fallback.");

    const poll = async () => {
      try {
        // 1. Pull market data
        const quotesRes = await fetch("/api/market-data");
        if (quotesRes.ok) {
          const quotesData = await quotesRes.json();
          if (quotesData.success && Array.isArray(quotesData.quotes)) {
            // Propagate initial quotes to bootstrap components
            this.initialQuotesListeners.forEach(listener => listener(quotesData.quotes));

            // Push individual market ticks down to active listeners (mini charts, alerts)
            quotesData.quotes.forEach((q: any) => {
              this.tickListeners.forEach(listener => listener(q));
            });
          }
        }

        // 2. Pull live signals
        const signalsRes = await fetch("/api/signals");
        if (signalsRes.ok) {
          const signalsData = await signalsRes.json();
          if (signalsData.success && Array.isArray(signalsData.signals)) {
            this.signalsListeners.forEach(listener => listener({
              type: "signals_update",
              signals: signalsData.signals,
              engine: signalsData.engine || "Quantitative HTTP Engine",
              metrics: signalsData.metrics
            }));
          }
        }
      } catch (err) {
        console.warn("[WS MANAGER] HTTP Polling fallback error during sync:", err);
      }
    };

    // Run first sync immediately
    poll();

    // Refresh every 4.5 seconds for robust real-time updates
    this.pollingInterval = setInterval(poll, 4500);
  }

  private stopFallbackPolling() {
    this.isPollingActive = false;
    if (this.pollingInterval) {
      clearInterval(this.pollingInterval);
      this.pollingInterval = null;
    }
  }

  public connect() {
    if (this.socket && (this.socket.readyState === WebSocket.CONNECTING || this.socket.readyState === WebSocket.OPEN)) {
      return;
    }

    this.forcedClose = false;
    this.setStatus("CONNECTING");

    // Dynamic resolution of ws vs wss based on window location
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const host = window.location.host;
    const url = `${protocol}//${host}/api/ws`;

    console.log(`[WS MANAGER] Connecting to real-time high-frequency stream at ${url}...`);

    try {
      this.socket = new WebSocket(url);

      this.socket.onopen = () => {
        console.log("[WS MANAGER] Connection established successfully.");
        this.setStatus("CONNECTED");
        this.reconnectAttempts = 0;
        this.reconnectDelay = 1000;
        
        // Disable polling fallback since real-time socket is active
        this.stopFallbackPolling();

        // Send a ping every 30 seconds to keep connection alive
        this.pingInterval = setInterval(() => {
          this.send({ type: "ping" });
        }, 30000);
      };

      this.socket.onmessage = (event) => {
        try {
          const payload = JSON.parse(event.data);
          
          if (payload.type === "market_tick") {
            this.tickListeners.forEach(listener => listener(payload.data));
          } else if (payload.type === "signals_update") {
            this.signalsListeners.forEach(listener => listener(payload));
          } else if (payload.type === "initial_quotes") {
            this.initialQuotesListeners.forEach(listener => listener(payload.quotes));
          } else if (payload.type === "system_status") {
            console.log(`[WS SYSTEM MESSAGE]: ${payload.message}`);
          }
        } catch (err) {
          console.warn("[WS MANAGER] Error parsing socket payload:", err);
        }
      };

      this.socket.onclose = () => {
        console.warn("[WS MANAGER] Connection closed. Activating fallback polling.");
        this.cleanup();
        this.setStatus("DISCONNECTED");
        
        // Start polling fallback
        this.startFallbackPolling();

        if (!this.forcedClose) {
          this.attemptReconnect();
        }
      };

      this.socket.onerror = (err) => {
        console.warn("[WS MANAGER] Socket encountered an error:", err);
        // Start fallback immediately upon any socket error
        this.startFallbackPolling();
      };
    } catch (err) {
      console.warn("[WS MANAGER] Failed to construct WebSocket:", err);
      this.setStatus("DISCONNECTED");
      this.startFallbackPolling();
      this.attemptReconnect();
    }
  }

  public disconnect() {
    this.forcedClose = true;
    this.cleanup();
    this.stopFallbackPolling();
    if (this.socket) {
      this.socket.close();
      this.socket = null;
    }
    this.setStatus("DISCONNECTED");
  }

  public send(data: any) {
    if (this.socket && this.socket.readyState === WebSocket.OPEN) {
      this.socket.send(JSON.stringify(data));
    } else {
      console.warn("[WS MANAGER] Cannot send message, socket is closed:", data);
    }
  }

  public requestRefresh() {
    this.send({ type: "request_refresh" });
  }

  // Listener subscriptions
  public onStatusChange(callback: (status: ConnectionStatus) => void) {
    this.statusListeners.add(callback);
    callback(this.status);
    return () => this.statusListeners.delete(callback);
  }

  public onTick(callback: (tick: any) => void) {
    this.tickListeners.add(callback);
    return () => this.tickListeners.delete(callback);
  }

  public onSignals(callback: (payload: any) => void) {
    this.signalsListeners.add(callback);
    return () => this.signalsListeners.delete(callback);
  }

  public onInitialQuotes(callback: (quotes: any[]) => void) {
    this.initialQuotesListeners.add(callback);
    return () => this.initialQuotesListeners.delete(callback);
  }

  private setStatus(newStatus: ConnectionStatus) {
    this.status = newStatus;
    this.statusListeners.forEach(listener => listener(newStatus));
  }

  private cleanup() {
    if (this.pingInterval) {
      clearInterval(this.pingInterval);
      this.pingInterval = null;
    }
  }

  private attemptReconnect() {
    if (this.reconnectAttempts >= this.maxReconnectAttempts) {
      console.error("[WS MANAGER] Max reconnection attempts reached. Please connect manually.");
      return;
    }

    this.reconnectAttempts++;
    console.log(`[WS MANAGER] Reconnecting attempt ${this.reconnectAttempts}/${this.maxReconnectAttempts} in ${this.reconnectDelay}ms...`);
    
    setTimeout(() => {
      this.connect();
      // Exponential backoff
      this.reconnectDelay = Math.min(this.reconnectDelay * 1.5, 30000);
    }, this.reconnectDelay);
  }

  public getStatus(): ConnectionStatus {
    return this.status;
  }
}

// Global Singleton Instance
export const wsManager = new WebSocketManager();
