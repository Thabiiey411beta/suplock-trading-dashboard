export interface MarketQuote {
  symbol: string;
  name: string;
  price: number;
  change: number;
  changePercent: number;
  category: 'forex' | 'commodity' | 'crypto' | 'equity';
  rsi?: number;
  sma5?: number;
  sma10?: number;
  volatility?: number;
}

export interface CentralBankNotes {
  boe: string; // Bank of England
  boj: string; // Bank of Japan
  sarb: string; // South African Reserve Bank
  fed: string; // Federal Reserve (US)
}

export interface ProbabilityBands {
  upper: number;
  lower: number;
  mean: number;
  currentProb: number; // probability score for trend continuation or reversal
  heatmapData: Array<{ price: number; probability: number }>;
}

export interface Signal {
  id: string;
  asset: string;
  action: 'BUY' | 'SELL';
  price: number;
  stopLoss: number;
  takeProfit: number;
  timestamp: string;
  confidence: number; // 0 - 100%
  riskLevel: 'LOW' | 'MEDIUM' | 'HIGH';
  timeframe: string;
  reasoning: string[];
  macroSentiment: 'BULLISH' | 'BEARISH' | 'NEUTRAL';
  centralBankNotes: CentralBankNotes;
  probabilityBands: ProbabilityBands;
  correlationAsset?: string;
  correlationChart?: Array<{ time: string; assetPrice: number; correlPrice: number }>;
}

export interface VerificationState {
  sentimentChecked: boolean;
  correlationChecked: boolean;
  probabilityChecked: boolean;
  riskCalculated: boolean;
  accountBalance: number;
  calculatedPositionSize: number;
  riskAmount: number;
  riskPercent: number;
  pipsRisked: number;
}

export type SubscriptionTier = "free" | "pro" | "institutional";

export interface TenantEntitlement {
  tenantId: string;
  tier: SubscriptionTier;
  status: "active" | "canceled" | "past_due" | "trialing";
  stripeCustomerId?: string;
  stripeSubscriptionId?: string;
  expiresAt?: string;
}

export interface AIConsensusSignal {
  id: string;
  asset: string;
  action: 'LONG' | 'SHORT';
  setupType: string;
  confidenceScore: number; // 0 - 100
  justification: string;
  entryZone: number;
  takeProfit: number;
  stopLoss: number;
  stopLossDistance: number; // e.g. 1.5 (%)
  timestamp: string;
}

export interface MacroEvent {
  id: string;
  title: string;
  secondsRemaining: number;
  dateStr: string;
  importance: 'HIGH' | 'MEDIUM' | 'LOW';
}

export interface SectorFlow {
  name: string;
  volumeFlow: 'INFLOW' | 'OUTFLOW' | 'STABLE';
  percentageChange: number;
}

export interface MacroContextPayload {
  globalSentimentIndex: number; // 0 - 100
  liveFundingRate: number; // percentage
  events: MacroEvent[];
  sectors: SectorFlow[];
}


