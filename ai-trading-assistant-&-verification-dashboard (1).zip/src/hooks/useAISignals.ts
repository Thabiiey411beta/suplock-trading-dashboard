import { useState, useEffect } from "react";
import { AIConsensusSignal, MacroContextPayload, MacroEvent, SectorFlow } from "../types";
import { wsManager } from "../lib/websocket";

const INITIAL_SIGNALS: AIConsensusSignal[] = [
  {
    id: "sig_btc_1",
    asset: "BTC-USD",
    action: "LONG",
    setupType: "Support Bounce",
    confidenceScore: 89,
    justification: "Strong support bounce at $91,200 backed by heavy spot orderbook bids and bullish MACD crossover on 4H.",
    entryZone: 91650,
    takeProfit: 95400,
    stopLoss: 90200,
    stopLossDistance: 1.58,
    timestamp: new Date().toISOString()
  },
  {
    id: "sig_sol_2",
    asset: "SOL-USD",
    action: "LONG",
    setupType: "Breakout Re-test",
    confidenceScore: 81,
    justification: "Failing to fall back into range after breakout. Confirmed re-test of $194.50 support zone with expanding buyer liquidity.",
    entryZone: 194.80,
    takeProfit: 212.00,
    stopLoss: 189.50,
    stopLossDistance: 2.72,
    timestamp: new Date(Date.now() - 300000).toISOString()
  },
  {
    id: "sig_eth_3",
    asset: "ETH-USD",
    action: "SHORT",
    setupType: "Resistance Rejection",
    confidenceScore: 74,
    justification: "Exhaustion candle near $3,450. Declining spot volume and elevated funding rates signal a high probability squeeze lower.",
    entryZone: 3415,
    takeProfit: 3250,
    stopLoss: 3485,
    stopLossDistance: 2.05,
    timestamp: new Date(Date.now() - 600000).toISOString()
  },
  {
    id: "sig_eurusd_4",
    asset: "EURUSD=X",
    action: "SHORT",
    setupType: "Range Deviation",
    confidenceScore: 78,
    justification: "Deviation above the 1.0920 range high. Bearish engulfing on 1H signals reversion to the mean of 1.0850.",
    entryZone: 1.0910,
    takeProfit: 1.0835,
    stopLoss: 1.0945,
    stopLossDistance: 0.32,
    timestamp: new Date(Date.now() - 900000).toISOString()
  }
];

const INITIAL_EVENTS: MacroEvent[] = [
  {
    id: "evt_fomc",
    title: "FOMC Rate Announcement",
    secondsRemaining: 4200, // 1h 10m
    dateStr: "Today, 14:00 EST",
    importance: "HIGH"
  },
  {
    id: "evt_cpi",
    title: "US Core CPI Release",
    secondsRemaining: 28800, // 8h
    dateStr: "Tomorrow, 08:30 EST",
    importance: "HIGH"
  },
  {
    id: "evt_boe",
    title: "BOJ Rate Decision",
    secondsRemaining: 57600, // 16h
    dateStr: "Fri, 23:00 GMT",
    importance: "MEDIUM"
  }
];

const INITIAL_SECTORS: SectorFlow[] = [
  { name: "Layer 1s", volumeFlow: "INFLOW", percentageChange: 4.8 },
  { name: "AI Tokens", volumeFlow: "INFLOW", percentageChange: 12.3 },
  { name: "DeFi", volumeFlow: "OUTFLOW", percentageChange: -1.6 },
  { name: "RWA / Oracles", volumeFlow: "STABLE", percentageChange: 0.2 },
  { name: "Meme Assets", volumeFlow: "OUTFLOW", percentageChange: -5.4 }
];

export function useAISignals() {
  const [signals, setSignals] = useState<AIConsensusSignal[]>(INITIAL_SIGNALS);
  const [macroContext, setMacroContext] = useState<MacroContextPayload>({
    globalSentimentIndex: 68,
    liveFundingRate: 0.0125,
    events: INITIAL_EVENTS,
    sectors: INITIAL_SECTORS
  });

  useEffect(() => {
    // 1. Tick event countdowns every second
    const countdownInterval = setInterval(() => {
      setMacroContext(prev => ({
        ...prev,
        events: prev.events.map(evt => ({
          ...evt,
          secondsRemaining: Math.max(0, evt.secondsRemaining - 1)
        }))
      }));
    }, 1000);

    // 2. Micro fluctuations on funding rates and sentiment index to reflect live streaming values
    const fluctuationInterval = setInterval(() => {
      setMacroContext(prev => {
        // Shift sentiment between 40 and 90
        const sentimentDelta = (Math.random() - 0.5) * 1.5;
        const nextSentiment = Math.max(30, Math.min(95, Math.round(prev.globalSentimentIndex + sentimentDelta)));

        // Shift funding rate slightly
        const fundingDelta = (Math.random() - 0.5) * 0.0005;
        const nextFunding = Number(Math.max(-0.01, Math.min(0.08, prev.liveFundingRate + fundingDelta)).toFixed(6));

        // Adjust sector percentages slightly
        const nextSectors = prev.sectors.map(sec => {
          const delta = (Math.random() - 0.5) * 0.4;
          const pct = Number((sec.percentageChange + delta).toFixed(2));
          const flow = pct > 1 ? "INFLOW" : pct < -1 ? "OUTFLOW" : "STABLE";
          return { ...sec, percentageChange: pct, volumeFlow: flow as any };
        });

        return {
          ...prev,
          globalSentimentIndex: nextSentiment,
          liveFundingRate: nextFunding,
          sectors: nextSectors
        };
      });
    }, 3000);

    // 3. Subscribe to existing websocket tick to align assets with active market data prices
    const unsubscribeTick = wsManager.onTick((tick) => {
      if (!tick) return;
      // Find matching signals and slightly adjust their confidence scores or entry levels depending on live volatility
      setSignals(prevSignals => {
        return prevSignals.map(sig => {
          if (sig.asset === tick.symbol) {
            const pctDiff = (Math.random() - 0.5) * 0.1; // small wiggle
            const newConfidence = Math.max(40, Math.min(99, Math.round(sig.confidenceScore + pctDiff * 5)));
            return {
              ...sig,
              confidenceScore: newConfidence
            };
          }
          return sig;
        });
      });
    });

    // 4. Periodically insert or rotate a new signal to simulate "consensus feed updates"
    const newsSignalInterval = setInterval(() => {
      const assets = ["SOL-USD", "BTC-USD", "ETH-USD", "GBPJPY=X", "EURUSD=X"];
      const asset = assets[Math.floor(Math.random() * assets.length)];
      const action = Math.random() > 0.4 ? "LONG" : "SHORT";
      const setups = ["Support Bounce", "Breakout Re-test", "Resistance Rejection", "EMA Golden Cross", "FVG Gap Fill"];
      const setup = setups[Math.floor(Math.random() * setups.length)];
      
      let basePrice = 100;
      if (asset === "BTC-USD") basePrice = 92000;
      else if (asset === "ETH-USD") basePrice = 3350;
      else if (asset === "SOL-USD") basePrice = 195;
      else if (asset === "GBPJPY=X") basePrice = 204;
      else if (asset === "EURUSD=X") basePrice = 1.09;

      const randomDiff = (Math.random() - 0.5) * 0.02 * basePrice;
      const entryZone = Number((basePrice + randomDiff).toFixed(asset.includes("=X") ? 4 : 2));
      const tpDiff = action === "LONG" ? basePrice * 0.04 : -basePrice * 0.04;
      const slDiff = action === "LONG" ? -basePrice * 0.015 : basePrice * 0.015;

      const takeProfit = Number((entryZone + tpDiff).toFixed(asset.includes("=X") ? 4 : 2));
      const stopLoss = Number((entryZone + slDiff).toFixed(asset.includes("=X") ? 4 : 2));
      const slDistance = Number((Math.abs(entryZone - stopLoss) / entryZone * 100).toFixed(2));
      const confidence = Math.floor(Math.random() * 25) + 70; // 70 to 95

      const justifications = [
        `High precision routing signals multi-agent alignment for ${asset} setup.`,
        `Favorable liquidations sweep completed on ${asset} with strong derivative support.`,
        `Supervisor node confirms cluster consolidation on ${asset} under low selling pressure.`,
        `Macro hedge flow index triggers a fast deviation pullback on ${asset}.`
      ];
      const justification = justifications[Math.floor(Math.random() * justifications.length)];

      const newSignal: AIConsensusSignal = {
        id: `sig_${Date.now()}`,
        asset,
        action,
        setupType: setup,
        confidenceScore: confidence,
        justification,
        entryZone,
        takeProfit,
        stopLoss,
        stopLossDistance: slDistance,
        timestamp: new Date().toISOString()
      };

      setSignals(prev => {
        // keep maximum of 6 signals, insert at front
        const filtered = prev.filter(s => s.asset !== asset);
        return [newSignal, ...filtered].slice(0, 6);
      });
    }, 20000); // Add/Update signal every 20 seconds

    return () => {
      clearInterval(countdownInterval);
      clearInterval(fluctuationInterval);
      clearInterval(newsSignalInterval);
      unsubscribeTick();
    };
  }, []);

  return {
    signals,
    macroContext,
    setSignals
  };
}
