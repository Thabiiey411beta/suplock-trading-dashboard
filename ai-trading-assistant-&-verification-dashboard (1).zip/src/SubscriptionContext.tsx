import React, { createContext, useContext, useState, useEffect } from "react";
import { SubscriptionTier, TenantEntitlement } from "./types";

interface SubscriptionContextType {
  tenantId: string;
  entitlement: TenantEntitlement;
  loading: boolean;
  setTenantId: (id: string) => void;
  upgradeTier: (tier: SubscriptionTier) => Promise<boolean>;
  simulateStripeWebhook: (tier: SubscriptionTier, eventType: string) => Promise<boolean>;
  isFeatureUnlocked: (feature: "correlation" | "post_trade_review") => boolean;
}

const defaultEntitlement: TenantEntitlement = {
  tenantId: "default-tenant",
  tier: "free",
  status: "active",
};

const SubscriptionContext = createContext<SubscriptionContextType | undefined>(undefined);

export function SubscriptionProvider({ children }: { children: React.ReactNode }) {
  const [tenantId, setTenantIdState] = useState<string>(() => {
    return localStorage.getItem("saas_tenant_id") || "default-tenant";
  });
  const [entitlement, setEntitlement] = useState<TenantEntitlement>(defaultEntitlement);
  const [loading, setLoading] = useState<boolean>(true);

  // Sync tenantId to localStorage
  const setTenantId = (id: string) => {
    setTenantIdState(id);
    localStorage.setItem("saas_tenant_id", id);
  };

  // Fetch subscription status from the backend in real-time
  const fetchSubscription = async () => {
    setLoading(true);
    try {
      const res = await fetch(`/api/subscription?tenantId=${encodeURIComponent(tenantId)}`);
      if (res.ok) {
        const data = await res.json();
        if (data.success && data.entitlement) {
          setEntitlement(data.entitlement);
          setLoading(false);
          return;
        }
      }
    } catch (err) {
      console.warn("Could not connect to subscription backend, falling back to client-side state:", err);
    }

    // Fallback: local simulation if server fails or is being restarted
    const stored = localStorage.getItem(`saas_entitlement_${tenantId}`);
    if (stored) {
      try {
        setEntitlement(JSON.parse(stored));
      } catch {
        setEntitlement({ tenantId, tier: "free", status: "active" });
      }
    } else {
      // Default presets
      if (tenantId === "alpha-funds") {
        setEntitlement({ tenantId, tier: "pro", status: "active" });
      } else if (tenantId === "apex-institutional") {
        setEntitlement({ tenantId, tier: "institutional", status: "active" });
      } else {
        setEntitlement({ tenantId, tier: "free", status: "active" });
      }
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchSubscription();
  }, [tenantId]);

  // Upgrade tier via API (simulated subscription portal action or direct webhook)
  const upgradeTier = async (tier: SubscriptionTier): Promise<boolean> => {
    try {
      const res = await fetch("/api/subscription/upgrade", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ tenantId, tier }),
      });
      if (res.ok) {
        const data = await res.json();
        if (data.success && data.entitlement) {
          setEntitlement(data.entitlement);
          localStorage.setItem(`saas_entitlement_${tenantId}`, JSON.stringify(data.entitlement));
          return true;
        }
      }
    } catch (err) {
      console.error("Failed to upgrade subscription tier on server:", err);
    }

    // Client-side fallback if server api is unreachable
    const updated: TenantEntitlement = {
      tenantId,
      tier,
      status: "active",
      expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
    };
    setEntitlement(updated);
    localStorage.setItem(`saas_entitlement_${tenantId}`, JSON.stringify(updated));
    return true;
  };

  // Simulate a standard Stripe Webhook event to show entitlement updates in real-time
  const simulateStripeWebhook = async (tier: SubscriptionTier, eventType: string): Promise<boolean> => {
    try {
      const res = await fetch("/api/webhooks/stripe-simulation", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ tenantId, tier, eventType }),
      });
      if (res.ok) {
        const data = await res.json();
        if (data.success && data.entitlement) {
          setEntitlement(data.entitlement);
          localStorage.setItem(`saas_entitlement_${tenantId}`, JSON.stringify(data.entitlement));
          return true;
        }
      }
    } catch (err) {
      console.error("Failed to post simulation webhook to server:", err);
    }
    return false;
  };

  // Core authorization gating logic
  const isFeatureUnlocked = (feature: "correlation" | "post_trade_review"): boolean => {
    const tier = entitlement.tier;
    if (tier === "institutional") return true;
    if (tier === "pro") return true;

    // Free users do not have access to correlation matrix or post_trade_review
    return false;
  };

  return (
    <SubscriptionContext.Provider
      value={{
        tenantId,
        entitlement,
        loading,
        setTenantId,
        upgradeTier,
        simulateStripeWebhook,
        isFeatureUnlocked,
      }}
    >
      {children}
    </SubscriptionContext.Provider>
  );
}

export function useSubscription() {
  const context = useContext(SubscriptionContext);
  if (!context) {
    throw new Error("useSubscription must be used within a SubscriptionProvider");
  }
  return context;
}
